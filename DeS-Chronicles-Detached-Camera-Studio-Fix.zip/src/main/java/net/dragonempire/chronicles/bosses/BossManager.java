package net.dragonempire.chronicles.bosses;

import net.dragonempire.chronicles.actions.ActionExecutor;
import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.objectives.ObjectiveEvent;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Vanilla-entity boss encounters. Quests never depend on a boss plugin: they listen for the KILL_BOSS objective,
 * which this manager fires only for players who dealt at least min_damage and were inside the arena at the kill.
 * Other boss plugins can fire the same ObjectiveEvent through their own adapter (no MythicMobs adapter is built).
 */
public final class BossManager {
    private static final class Active {
        final BossDefinition def;
        final UUID entity;
        final ContributionTracker tracker = new ContributionTracker();
        final Set<Integer> firedPhases = new HashSet<>();
        BukkitTask timeout;

        Active(BossDefinition def, UUID entity) {
            this.def = def;
            this.entity = entity;
        }
    }

    private final JavaPlugin plugin;
    private final ContentManager content;
    private final QuestService quests;
    private final ActionExecutor actions;
    private final NamespacedKey key;
    private final Map<String, Active> active = new HashMap<>();

    public BossManager(JavaPlugin plugin, ContentManager content, QuestService quests, ActionExecutor actions) {
        this.plugin = plugin;
        this.content = content;
        this.quests = quests;
        this.actions = actions;
        this.key = new NamespacedKey(plugin, "boss_id");
    }

    public NamespacedKey key() { return key; }

    /** Returns null on success or a reason it could not spawn. */
    public String spawn(String id, Player starter) {
        BossDefinition def = content.bosses().get(id);
        if (def == null) return "Unknown boss: " + id;
        if (!def.configured()) return "This encounter has not been set up on the server yet (boss '" + id + "' is unconfigured).";
        World w = Bukkit.getWorld(def.world());
        if (w == null) return "Boss world '" + def.world() + "' is not loaded.";
        Active existing = active.get(id);
        if (existing != null) {
            Entity e = Bukkit.getEntity(existing.entity);
            if (e != null && e.isValid()) return "That encounter is already in progress.";
            cancelTimeout(existing); // stale: entity was lost (e.g. chunk unloaded)
            active.remove(id);
        }
        Entity e = w.spawnEntity(new Location(w, def.x(), def.y(), def.z()), EntityType.valueOf(def.entity()));
        e.setPersistent(false);
        e.customName(MiniMessage.miniMessage().deserialize(def.name()));
        e.setCustomNameVisible(true);
        e.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
        if (e instanceof LivingEntity le) {
            AttributeInstance max = le.getAttribute(Attribute.MAX_HEALTH);
            if (max != null) max.setBaseValue(def.health());
            le.setHealth(Math.min(def.health(), max == null ? def.health() : max.getValue()));
            AttributeInstance attack = le.getAttribute(Attribute.ATTACK_DAMAGE);
            if (attack != null) attack.setBaseValue(def.damage());
            le.setRemoveWhenFarAway(false);
        }
        Active a = new Active(def, e.getUniqueId());
        if (def.timeLimitSeconds() > 0) {
            a.timeout = plugin.getServer().getScheduler().runTaskLater(plugin, () -> expire(id), def.timeLimitSeconds() * 20L);
        }
        active.put(id, a);
        return null;
    }

    public void onDamage(Entity victim, Player attacker, double finalDamage) {
        String id = victim.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        Active a = id == null ? null : active.get(id);
        if (a == null || !victim.getUniqueId().equals(a.entity)) return;
        a.tracker.add(attacker.getUniqueId(), finalDamage);
        if (!(victim instanceof LivingEntity le)) return;
        AttributeInstance max = le.getAttribute(Attribute.MAX_HEALTH);
        double fraction = Math.max(0, le.getHealth() - finalDamage) / (max == null ? a.def.health() : max.getValue());
        for (int i = 0; i < a.def.phases().size(); i++) {
            BossPhase phase = a.def.phases().get(i);
            if (fraction <= phase.below() && a.firedPhases.add(i)) {
                for (UUID u : a.tracker.all()) {
                    Player p = Bukkit.getPlayer(u);
                    if (p != null && p.getWorld().equals(victim.getWorld())
                            && p.getLocation().distanceSquared(victim.getLocation()) <= a.def.arenaRadius() * a.def.arenaRadius()) {
                        actions.run(p, phase.actions());
                    }
                }
            }
        }
    }

    public void onDeath(Entity victim) {
        String id = victim.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        Active a = id == null ? null : active.get(id);
        if (a == null || !victim.getUniqueId().equals(a.entity)) return;
        active.remove(id);
        cancelTimeout(a);
        Location at = victim.getLocation();
        for (UUID u : a.tracker.qualified(a.def.minDamage())) {
            Player p = Bukkit.getPlayer(u);
            if (p == null || !p.getWorld().equals(at.getWorld())) continue;
            if (p.getLocation().distanceSquared(at) > a.def.arenaRadius() * a.def.arenaRadius()) continue; // left the arena
            quests.addFlag(p, "boss:" + id);
            quests.handle(p, new ObjectiveEvent("KILL_BOSS", id));
            p.sendMessage(Component.text("You helped defeat ", NamedTextColor.GOLD)
                    .append(MiniMessage.miniMessage().deserialize(a.def.name())));
        }
    }

    /**
     * For external boss plugins (for example a MythicMobs skill running "/desquests boss credit <id> <player>"):
     * grants the same credit as a normal kill. The external system is responsible for judging participation.
     */
    public String credit(Player p, String id) {
        if (!content.bosses().containsKey(id)) return "Unknown boss: " + id;
        quests.addFlag(p, "boss:" + id);
        quests.handle(p, new ObjectiveEvent("KILL_BOSS", id));
        return null;
    }

    private void expire(String id) {
        Active a = active.remove(id);
        if (a == null) return;
        Entity e = Bukkit.getEntity(a.entity);
        if (e != null) e.remove();
        for (UUID u : a.tracker.all()) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) p.sendMessage(Component.text("The encounter timed out.", NamedTextColor.GRAY));
        }
    }

    private static void cancelTimeout(Active a) {
        if (a.timeout != null) a.timeout.cancel();
    }

    public void despawnAll() {
        for (Active a : new ArrayList<>(active.values())) {
            cancelTimeout(a);
            Entity e = Bukkit.getEntity(a.entity);
            if (e != null) e.remove();
        }
        active.clear();
    }
}
