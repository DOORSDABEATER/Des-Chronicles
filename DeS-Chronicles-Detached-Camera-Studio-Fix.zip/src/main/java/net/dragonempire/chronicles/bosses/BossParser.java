package net.dragonempire.chronicles.bosses;

import net.dragonempire.chronicles.dialogue.DialogueParser;
import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

public final class BossParser {
    private BossParser() {}

    public static BossDefinition parse(String id, Map<String, Object> root, String file, Set<String> knownActions,
                                       List<ValidationIssue> issues) {
        int before = issues.size();
        String name = root.get("name") instanceof String s && !s.isBlank() ? s : id;
        String entity = root.get("entity") instanceof String s ? s.toUpperCase(Locale.ROOT) : "";
        if (entity.isBlank()) issues.add(new ValidationIssue(file, "entity", "required"));
        if (!(root.get("location") instanceof Map<?, ?> l) || !(l.get("world") instanceof String w)
                || !(l.get("x") instanceof Number x) || !(l.get("y") instanceof Number y) || !(l.get("z") instanceof Number z)) {
            issues.add(new ValidationIssue(file, "location", "needs world, x, y, z"));
            return null;
        }
        double health = root.get("health") instanceof Number n ? n.doubleValue() : 100;
        if (health <= 0 || health > 1024) issues.add(new ValidationIssue(file, "health", "must be in (0, 1024]"));
        double damage = root.get("damage") instanceof Number n ? n.doubleValue() : 10;
        if (damage < 0 || damage > 2048) issues.add(new ValidationIssue(file, "damage", "must be between 0 and 2048"));
        double arena = root.get("arena_radius") instanceof Number n ? n.doubleValue() : 40;
        if (arena <= 0) issues.add(new ValidationIssue(file, "arena_radius", "must be > 0"));
        int limit = root.get("time_limit_seconds") instanceof Number n ? n.intValue() : 0;
        if (limit < 0) issues.add(new ValidationIssue(file, "time_limit_seconds", "must be >= 0 (0 = no limit)"));
        double minDamage = root.get("min_damage") instanceof Number n ? n.doubleValue() : 1;
        if (minDamage < 0) issues.add(new ValidationIssue(file, "min_damage", "must be >= 0"));

        List<BossPhase> phases = new ArrayList<>();
        if (root.get("phases") instanceof List<?> pl) {
            for (int i = 0; i < pl.size(); i++) {
                String p = "phases[" + i + "]";
                if (!(pl.get(i) instanceof Map<?, ?> m) || !(m.get("below") instanceof Number b) || b.doubleValue() <= 0 || b.doubleValue() >= 1) {
                    issues.add(new ValidationIssue(file, p + ".below", "required, a fraction between 0 and 1 (exclusive)"));
                    continue;
                }
                phases.add(new BossPhase(b.doubleValue(), DialogueParser.parseActions(m.get("actions"), file, p + ".actions", knownActions, issues)));
            }
        }
        if (issues.size() > before) return null;
        phases.sort(Comparator.comparingDouble(BossPhase::below).reversed());
        return new BossDefinition(id, name, entity, !Boolean.FALSE.equals(root.get("configured")), w,
                x.doubleValue(), y.doubleValue(), z.doubleValue(), health, damage, arena, limit, minDamage, List.copyOf(phases));
    }
}
