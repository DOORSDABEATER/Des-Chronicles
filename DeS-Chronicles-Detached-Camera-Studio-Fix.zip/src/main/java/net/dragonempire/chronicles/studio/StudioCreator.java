package net.dragonempire.chronicles.studio;

import net.dragonempire.chronicles.ChroniclesPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** In-game authoring screens for boss and cutscene YAML content. */
public final class StudioCreator implements Listener {
    private enum Screen { HUB, BOSSES, BOSS_EDIT, SCENES, SCENE_EDIT }
    private static final class Holder implements InventoryHolder {
        final Screen screen; final String id; final int page; final List<String> ids=new ArrayList<>(); Inventory inv;
        Holder(Screen screen, String id) { this(screen,id,0); }
        Holder(Screen screen, String id, int page) { this.screen=screen; this.id=id; this.page=page; }
        @Override public Inventory getInventory() { return inv; }
    }
    private record Prompt(String id, String kind, int index) {}
    private final ChroniclesPlugin plugin;
    private final Map<UUID, Prompt> prompts = new HashMap<>();

    public StudioCreator(ChroniclesPlugin plugin) { this.plugin=plugin; }


    public void openContentHub(Player p) {
        Holder h=new Holder(Screen.HUB, ""); h.inv=Bukkit.createInventory(h,27,Component.text("Studio • Content Workshop"));
        h.inv.setItem(10,item(Material.WRITABLE_BOOK,"Create quest",List.of("Create a draft quest in-game")));
        h.inv.setItem(11,item(Material.WRITABLE_BOOK,"Create dialogue",List.of("Create speaker + opening node")));
        h.inv.setItem(12,item(Material.VILLAGER_SPAWN_EGG,"Create NPC",List.of("Spawn an NPC at your location")));
        h.inv.setItem(14,item(Material.BOOK,"Edit quest",List.of("Title, description, objective")));
        h.inv.setItem(15,item(Material.PAPER,"Edit dialogue",List.of("Speaker, node text, choices")));
        h.inv.setItem(16,item(Material.ARMOR_STAND,"Design NPC",List.of("Name, entity, dialogue, glow, baby, color, equipment")));
        h.inv.setItem(22,item(Material.ARROW,"Back to Studio",List.of())); p.openInventory(h.inv);
    }

    public void openBosses(Player p) {
        Holder h=new Holder(Screen.BOSSES, ""); h.inv=Bukkit.createInventory(h,54,Component.text("Studio • Boss Creator"));
        int slot=0;
        for (String id : sorted(files("bosses"))) { if(slot>=45) break; h.ids.add(id); h.inv.setItem(slot++, item(Material.WITHER_SKELETON_SKULL,id, List.of("Left-click: edit", "Right-click: spawn test"))); }
        h.inv.setItem(49,item(Material.ANVIL,"Create boss",List.of("Creates at your current location")));
        h.inv.setItem(53,item(Material.ARROW,"Back to Studio",List.of())); p.openInventory(h.inv);
    }
    public void openScenes(Player p) {
        Holder h=new Holder(Screen.SCENES, ""); h.inv=Bukkit.createInventory(h,54,Component.text("Studio • Cutscene Creator"));
        int slot=0; for(String id:sorted(files("cutscenes"))){if(slot>=45)break;h.ids.add(id);h.inv.setItem(slot++,item(Material.MAP,id,List.of("Left-click: edit timeline", "Right-click: play test")));}
        h.inv.setItem(49,item(Material.WRITABLE_BOOK,"Create cutscene",List.of("Start a blank timeline")));
        h.inv.setItem(53,item(Material.ARROW,"Back to Studio",List.of()));p.openInventory(h.inv);
    }
    private void openBoss(Player p,String id) {
        YamlConfiguration y=load("bosses",id); if(y==null){p.sendMessage("§cBoss file not found.");return;}
        Holder h=new Holder(Screen.BOSS_EDIT,id);h.inv=Bukkit.createInventory(h,27,Component.text("Boss • "+id));
        h.inv.setItem(10,item(Material.NAME_TAG,"Name",List.of(String.valueOf(y.get("name",id)),"Click to edit")));
        h.inv.setItem(11,item(Material.ZOMBIE_HEAD,"Entity",List.of(y.getString("entity","ZOMBIE"),"Click to edit")));
        h.inv.setItem(12,item(Material.REDSTONE,"Health",List.of(String.valueOf(y.getDouble("health",200)),"Click to edit")));
        h.inv.setItem(13,item(Material.IRON_SWORD,"Arena / damage",List.of("Radius: "+y.getDouble("arena_radius",40),"Minimum damage: "+y.getDouble("min_damage",1),"Click to edit both")));
        h.inv.setItem(14,item(Material.CLOCK,"Time limit",List.of(y.getInt("time_limit_seconds",0)+" seconds (0 = none)","Click to edit")));
        h.inv.setItem(15,item(Material.COMPASS,"Spawn location",List.of("World: "+y.getString("location.world"),"Click to set to your current location")));
        h.inv.setItem(16,item(Material.BLAZE_POWDER,"Add phase",List.of("Add a health threshold, e.g. 0.5")));
        h.inv.setItem(17,item(Material.FIRE_CHARGE,"Add phase ability",List.of("Adds an action to the latest phase", "message, sound, title, spawn_boss, etc.")));
        h.inv.setItem(18,item(Material.IRON_AXE,"Attack damage",List.of("Current: "+y.getDouble("damage",10),"Click to edit")));
        h.inv.setItem(22,item(Material.LIME_DYE,"Save & validate",List.of("Writes the boss file and reloads content")));
        h.inv.setItem(26,item(Material.ARROW,"Back",List.of()));p.openInventory(h.inv);
    }
    private void openScene(Player p,String id) { openScene(p,id,0); }
    private void openScene(Player p,String id,int page) {
        YamlConfiguration y=load("cutscenes",id);if(y==null){p.sendMessage("§cCutscene file not found.");return;}
        Holder h=new Holder(Screen.SCENE_EDIT,id,Math.max(0,page));h.inv=Bukkit.createInventory(h,54,Component.text("Timeline • "+id));
        h.inv.setItem(45,item(Material.NAME_TAG,"Scene settings",List.of("Skippable: "+y.getBoolean("skippable",true),"Shared: "+y.getBoolean("shared",false),"Click to edit")));
        h.inv.setItem(46,item(Material.ARROW,"Previous page",List.of("Page "+(h.page+1))));
        h.inv.setItem(47,item(Material.CLOCK,"Add timeline step",List.of("Enter: type at=0 key=value ...","Supports every engine step type")));
        h.inv.setItem(48,item(Material.ARROW,"Next page",List.of("Page "+(h.page+1))));
        h.inv.setItem(49,item(Material.LIME_DYE,"Save & validate",List.of("Writes and reloads content")));
        h.inv.setItem(53,item(Material.ARROW,"Back",List.of()));
        List<Map<?,?>> steps=(List<Map<?,?>>)(List<?>)y.getMapList("steps");
        for(int i=0;i<45;i++) {int index=h.page*45+i;if(index>=steps.size())break;Map<?,?> s=steps.get(index);String type=String.valueOf(s.get("type"));int at=s.get("at") instanceof Number n?n.intValue():0;
            h.inv.setItem(i,item(Material.PAPER,"#"+(index+1)+" • "+type,List.of("At tick "+at,"Left-click: edit step","Right-click: delete step")));}
        p.openInventory(h.inv);
    }
    public void click(Player p, Holder h, int slot, ClickType click) {
        if(!p.hasPermission("desquests.admin")){p.closeInventory();return;}
        switch(h.screen){
            case HUB -> {
                if(slot==22){plugin.studioMenu().open(p,StudioMenu.Kind.MAIN,0);return;}
                switch(slot){
                    case 10 -> prompt(p,"","create-quest",-1,"Enter a new quest id (lowercase letters, numbers, underscores):");
                    case 11 -> prompt(p,"","create-dialogue",-1,"Enter a new dialogue id:");
                    case 12 -> prompt(p,"","create-npc",-1,"Enter a new NPC id:");
                    case 14 -> prompt(p,"","edit-quest",-1,"Enter: quest_id title=New title OR description=Text OR objective TYPE TARGET AMOUNT");
                    case 15 -> prompt(p,"","edit-dialogue",-1,"Enter: id speaker NAME | id page NODE TEXT | id choice NODE CHOICE_ID TEXT NEXT_NODE");
                    case 16 -> prompt(p,"","edit-npc",-1,"Enter: id name TEXT | entity ZOMBIE | dialogue ID | glowing true | baby true | color RED | equip helmet DIAMOND_HELMET");
                    default -> { }
                }
            }
            case BOSSES -> { if(slot==53){plugin.studioMenu().open(p,StudioMenu.Kind.MAIN,0);return;} if(slot==49){String id="boss_"+Long.toString(System.currentTimeMillis(),36);YamlConfiguration y=new YamlConfiguration();y.set("configured",true);y.set("name",id);y.set("entity","WITHER_SKELETON");y.set("health",200);y.set("damage",10);y.set("arena_radius",40);y.set("time_limit_seconds",900);y.set("min_damage",1);var l=p.getLocation();y.set("location.world",l.getWorld().getName());y.set("location.x",l.getX());y.set("location.y",l.getY());y.set("location.z",l.getZ());y.set("phases",new ArrayList<>());save("bosses",id,y,p);openBoss(p,id);return;} ItemStack it=h.inv.getItem(slot);if(it!=null&&slot<h.ids.size()){String id=h.ids.get(slot);if(click.isRightClick()){p.closeInventory();p.performCommand("desquests boss spawn "+id);}else openBoss(p,id);} }
            case BOSS_EDIT -> { if(slot==26){openBosses(p);return;} if(slot==22){save("bosses",h.id,load("bosses",h.id),p);plugin.reloadContent();p.sendMessage("§aBoss saved. Check /desquests validate for any content issues.");openBoss(p,h.id);return;}
                switch(slot){case 10->prompt(p,h.id,"boss-name",-1,"Enter the boss display name (MiniMessage supported):");case 11->prompt(p,h.id,"boss-entity",-1,"Enter a spawnable Bukkit entity type, e.g. WITHER_SKELETON:");case 12->prompt(p,h.id,"boss-health",-1,"Enter max health (1–1024):");case 13->prompt(p,h.id,"boss-arena",-1,"Enter arena radius and minimum damage separated by a space:");case 14->prompt(p,h.id,"boss-time",-1,"Enter time limit in seconds (0 = no limit):");case 15->{var l=p.getLocation();YamlConfiguration y=load("bosses",h.id);y.set("location.world",l.getWorld().getName());y.set("location.x",l.getX());y.set("location.y",l.getY());y.set("location.z",l.getZ());y.set("configured",true);save("bosses",h.id,y,p);openBoss(p,h.id);}case 16->prompt(p,h.id,"boss-phase",-1,"Enter phase threshold from 0 to 1 (example 0.5):");case 18->prompt(p,h.id,"boss-damage",-1,"Enter the boss attack damage (0–2048):");case 17->prompt(p,h.id,"boss-phase-action",-1,"Enter action: type key=value ... (example message text=<red>Enraged!). Known: start_quest complete_quest set_flag clear_flag message sound title play_cutscene spawn_boss add_counter start_escort open_shop");default->{}} }
            case SCENES -> {if(slot==53){plugin.studioMenu().open(p,StudioMenu.Kind.MAIN,0);return;}if(slot==49){String id="scene_"+Long.toString(System.currentTimeMillis(),36);YamlConfiguration y=new YamlConfiguration();y.set("skippable",true);y.set("shared",false);y.set("steps",new ArrayList<>());save("cutscenes",id,y,p);openScene(p,id);return;}ItemStack it=h.inv.getItem(slot);if(it!=null&&slot<h.ids.size()){String id=h.ids.get(slot);if(click.isRightClick()){p.closeInventory();p.performCommand("desquests cutscene play "+id+" "+p.getName());}else openScene(p,id);}}
            case SCENE_EDIT -> {if(slot==53){openScenes(p);return;}if(slot==49){save("cutscenes",h.id,load("cutscenes",h.id),p);plugin.reloadContent();p.sendMessage("§aCutscene saved and content reloaded.");openScene(p,h.id);return;}if(slot==46){openScene(p,h.id,Math.max(0,h.page-1));return;}if(slot==48){openScene(p,h.id,h.page+1);return;}if(slot==45){prompt(p,h.id,"scene-settings",-1,"Enter: skippable=true shared=false radius=30");return;}if(slot==47){prompt(p,h.id,"scene-add",-1,"Enter: type at=0 key=value ... (example title at=20 title=<gold>HELLO subtitle=<gray>WORLD stay=60). For camera: camera at=0 ticks=80 easing=smooth from=x,y,z,yaw,pitch to=x,y,z,yaw,pitch; or path=x,y,z,yaw,pitch;x,y,z,yaw,pitch;...");return;}if(slot>=0&&slot<45&&h.inv.getItem(slot)!=null){int index=h.page*45+slot;if(click.isRightClick()){YamlConfiguration y=load("cutscenes",h.id);List<Map<?,?>> steps=(List<Map<?,?>>)(List<?>)y.getMapList("steps");if(index<steps.size()){steps.remove(index);y.set("steps",steps);save("cutscenes",h.id,y,p);openScene(p,h.id,h.page);}}else prompt(p,h.id,"scene-edit",index,"Enter replacement step: type at=0 key=value ... (or CANCEL)");}}
        }
    }
    private void prompt(Player p,String id,String kind,int index,String message){prompts.put(p.getUniqueId(),new Prompt(id,kind,index));p.closeInventory();p.sendMessage("§e[Studio] "+message+" Type CANCEL to stop.");}
    @EventHandler public void onChat(AsyncPlayerChatEvent e){Prompt pr=prompts.remove(e.getPlayer().getUniqueId());if(pr==null)return;e.setCancelled(true);String input=e.getMessage();Player p=e.getPlayer();Bukkit.getScheduler().runTask(plugin,()->{if(input.equalsIgnoreCase("cancel")){p.sendMessage("§7Cancelled.");return;}try{applyPrompt(p,pr,input);}catch(Exception ex){p.sendMessage("§cInvalid input: "+ex.getMessage());p.sendMessage("§7No changes were saved. Reopen the editor and try again.");}});}
    private void applyPrompt(Player p,Prompt pr,String in){
        if (pr.kind.startsWith("create-")) { createContent(p, pr.kind.substring(7), in); return; }
        if (pr.kind.startsWith("edit-")) { editContent(p, pr.kind.substring(5), in); return; }
        YamlConfiguration y=load(pr.kind.startsWith("boss-")?"bosses":"cutscenes",pr.id);if(y==null)return;
        switch(pr.kind){case "boss-name"->y.set("name",in);case "boss-entity"->{EntityType t=EntityType.valueOf(in.toUpperCase(Locale.ROOT));if(!t.isSpawnable()||!t.isAlive())throw new IllegalArgumentException("Entity must be spawnable and alive");y.set("entity",t.name());}case "boss-health"->{double v=Double.parseDouble(in);if(v<=0||v>1024)throw new IllegalArgumentException("Health must be >0 and <=1024");y.set("health",v);}case "boss-damage"->{double v=Double.parseDouble(in);if(v<0||v>2048)throw new IllegalArgumentException("Damage must be between 0 and 2048");y.set("damage",v);}case "boss-arena"->{String[] a=in.trim().split("\\s+");if(a.length!=2)throw new IllegalArgumentException("Use: radius minDamage");y.set("arena_radius",Double.parseDouble(a[0]));y.set("min_damage",Double.parseDouble(a[1]));}case "boss-time"->y.set("time_limit_seconds",Math.max(0,Integer.parseInt(in)));case "boss-phase"->{double v=Double.parseDouble(in);if(v<=0||v>=1)throw new IllegalArgumentException("Threshold must be between 0 and 1");List<Map<String,Object>> phases=(List<Map<String,Object>>)(List<?>)y.getMapList("phases");Map<String,Object> phase=new LinkedHashMap<>();phase.put("below",v);phase.put("actions",new ArrayList<>());phases.add(phase);y.set("phases",phases);}
            case "boss-phase-action"->{List<Map<String,Object>> phases=(List<Map<String,Object>>)(List<?>)y.getMapList("phases");if(phases.isEmpty())throw new IllegalArgumentException("Add a phase first");List<String> parts=tokenize(in);if(parts.isEmpty())throw new IllegalArgumentException("Action type required");String type=parts.get(0).toLowerCase(Locale.ROOT);Set<String> allowed=net.dragonempire.chronicles.actions.ActionExecutor.KNOWN;if(!allowed.contains(type))throw new IllegalArgumentException("Unknown action type");Map<String,Object> action=new LinkedHashMap<>();action.put("type",type);for(int i=1;i<parts.size();i++){String[] kv=parts.get(i).split("=",2);if(kv.length==2)action.put(kv[0],coerce(kv[1]));}Map<String,Object> last=phases.get(phases.size()-1);List<Map<String,Object>> acts=(List<Map<String,Object>>)(List<?>)last.getOrDefault("actions",new ArrayList<>());acts.add(action);last.put("actions",acts);y.set("phases",phases);}
            case "scene-settings"->{for(String token:in.split("\\s+")){String[] kv=token.split("=",2);if(kv.length!=2)continue;String k=kv[0].toLowerCase(Locale.ROOT);if(k.equals("skippable")||k.equals("shared"))y.set(k,Boolean.parseBoolean(kv[1]));else if(k.equals("radius"))y.set(k,Double.parseDouble(kv[1]));}}
            case "scene-add","scene-edit"->{Map<String,Object> step=parseStep(in);List<Map<String,Object>> steps=(List<Map<String,Object>>)(List<?>)y.getMapList("steps");if(pr.kind.equals("scene-edit")){if(pr.index<0||pr.index>=steps.size())throw new IllegalArgumentException("Step no longer exists");steps.set(pr.index,step);}else steps.add(step);y.set("steps",steps);}
            default->throw new IllegalArgumentException("Unknown editor action");}
        save(pr.kind.startsWith("boss-")?"bosses":"cutscenes",pr.id,y,p);if(pr.kind.startsWith("boss-"))openBoss(p,pr.id);else openScene(p,pr.id,Math.max(0,pr.index/45));
    }
    private void createContent(Player p, String type, String rawId) {
        String id=rawId.toLowerCase(Locale.ROOT);
        if(!id.matches("[a-z0-9_]{2,32}")){p.sendMessage("§cID must match [a-z0-9_]{2,32}.");openContentHub(p);return;}
        String folder=type.equals("quest")?"quests":type.equals("dialogue")?"dialogues":"npc";
        File f=new File(dir(folder),id+".yml");
        if(f.exists()){p.sendMessage("§cThat id already exists.");openContentHub(p);return;}
        YamlConfiguration y=new YamlConfiguration();
        if(type.equals("quest")){
            y.set("title",id); y.set("description","Describe this quest."); y.set("status","draft"); y.set("category","side");
            y.set("objectives",List.of(Map.of("id","o1","type","TALK_NPC","target","any","amount",1)));
        } else if(type.equals("dialogue")){
            y.set("speaker",id); y.set("color","#ffffff"); y.set("start","intro");
            Map<String,Object> node=new LinkedHashMap<>(); node.put("pages",List.of("Hello there.")); node.put("choices",new ArrayList<>());
            y.set("nodes.intro",node);
        } else if(type.equals("npc")){
            var l=p.getLocation(); y.set("name",id); y.set("entity","VILLAGER"); y.set("world",l.getWorld().getName());
            y.set("x",l.getX());y.set("y",l.getY());y.set("z",l.getZ());y.set("yaw",l.getYaw());y.set("pitch",l.getPitch());
            y.set("dialogue","");y.set("appearance.glowing",false);y.set("appearance.baby",false);
        } else { p.sendMessage("§cUnknown content type."); return; }
        save(folder,id,y,p); plugin.reloadContent();
        p.sendMessage("§aCreated "+type+" '"+id+"'. Changes are saved and reloaded immediately.");
        if(type.equals("npc")) p.sendMessage("§7NPC design options: /quests studio → Content Workshop → Design NPC.");
        openContentHub(p);
    }

    private void editContent(Player p, String type, String input) {
        List<String> t=tokenize(input);
        if(t.size()<3){p.sendMessage("§cNot enough arguments.");openContentHub(p);return;}
        String id=t.get(0), folder=type.equals("quest")?"quests":type.equals("dialogue")?"dialogues":"npc";
        YamlConfiguration y=load(folder,id);
        if(y==null){p.sendMessage("§cUnknown "+type+" id: "+id);openContentHub(p);return;}
        try {
            if(type.equals("quest")){
                if(t.get(1).equalsIgnoreCase("objective")){
                    if(t.size()<5)throw new IllegalArgumentException("Use objective TYPE TARGET AMOUNT");
                    String err=plugin.questEditor().addObjective(id,t.get(2),t.get(3),Integer.parseInt(t.get(4)));
                    if(err!=null)throw new IllegalArgumentException(err);
                } else if(t.get(1).equalsIgnoreCase("reward")) {
                    if(t.size()<3)throw new IllegalArgumentException("Use reward TYPE key=value...");
                    String err=plugin.questEditor().addReward(id,t.get(2),t.subList(3,t.size()));
                    if(err!=null)throw new IllegalArgumentException(err);
                } else {
                    String field=t.get(1); int eq=field.indexOf('=');
                    if(eq<1)throw new IllegalArgumentException("Use key=value for quest fields");
                    String key=field.substring(0,eq).toLowerCase(Locale.ROOT);
                    String value=field.substring(eq+1);
                    if(t.size()>2)value += " " + String.join(" ",t.subList(2,t.size()));
                    String err=plugin.questEditor().set(id,key,value.trim()); if(err!=null)throw new IllegalArgumentException(err);
                }
            } else if(type.equals("dialogue")){
                String action=t.get(1).toLowerCase(Locale.ROOT);
                if(action.equals("speaker")){y.set("speaker",String.join(" ",t.subList(2,t.size())));}
                else if(action.equals("start")){if(!y.isConfigurationSection("nodes."+t.get(2)))throw new IllegalArgumentException("Unknown node");y.set("start",t.get(2));}
                else if(action.equals("node")){
                    if(t.size()<4)throw new IllegalArgumentException("Use id node NODE_ID TEXT");
                    String node=t.get(2);if(y.isConfigurationSection("nodes."+node))throw new IllegalArgumentException("Node already exists");
                    Map<String,Object> newNode=new LinkedHashMap<>();newNode.put("pages",List.of(String.join(" ",t.subList(3,t.size()))));newNode.put("choices",new ArrayList<>());y.set("nodes."+node,newNode);
                }
                else if(action.equals("page")){
                    if(t.size()<4)throw new IllegalArgumentException("Use id page NODE TEXT");
                    String node=t.get(2); if(!y.isConfigurationSection("nodes."+node))throw new IllegalArgumentException("Unknown node "+node);
                    List<String> pages=y.getStringList("nodes."+node+".pages");
                    pages.add(String.join(" ",t.subList(3,t.size()))); y.set("nodes."+node+".pages",pages);
                } else if(action.equals("choice")){
                    if(t.size()<6)throw new IllegalArgumentException("Use id choice NODE CHOICE_ID TEXT NEXT_NODE");
                    String node=t.get(2); if(!y.isConfigurationSection("nodes."+node))throw new IllegalArgumentException("Unknown node "+node);
                    List<Map<?,?>> choices=new ArrayList<>(y.getMapList("nodes."+node+".choices"));
                    String choiceId=t.get(3), next=t.get(t.size()-1); String text=String.join(" ",t.subList(4,t.size()-1));
                    Map<String,Object> c=new LinkedHashMap<>();c.put("id",choiceId);c.put("text",text);if(!next.equalsIgnoreCase("end"))c.put("next",next);choices.add(c);y.set("nodes."+node+".choices",choices);
                } else throw new IllegalArgumentException("Actions: speaker, start, node, page, choice");
                save(folder,id,y,p);plugin.reloadContent();
            } else if(type.equals("npc")){
                String action=t.get(1).toLowerCase(Locale.ROOT);
                switch(action){
                    case "name" -> y.set("name",String.join(" ",t.subList(2,t.size())));
                    case "entity" -> {EntityType et=EntityType.valueOf(t.get(2).toUpperCase(Locale.ROOT));if(!et.isAlive()||!et.isSpawnable())throw new IllegalArgumentException("Entity must be spawnable and alive");y.set("entity",et.name());}
                    case "dialogue" -> y.set("dialogue",t.get(2));
                    case "glowing","baby" -> y.set("appearance."+action,Boolean.parseBoolean(t.get(2)));
                    case "color" -> y.set("appearance.color",org.bukkit.DyeColor.valueOf(t.get(2).toUpperCase(Locale.ROOT)).name());
                    case "equip" -> {if(t.size()<4)throw new IllegalArgumentException("Use equip SLOT MATERIAL");Material mat=Material.matchMaterial(t.get(3));if(mat==null||!mat.isItem())throw new IllegalArgumentException("Unknown item material");y.set("appearance.equipment."+t.get(2).toLowerCase(Locale.ROOT),mat.name());}
                    default -> throw new IllegalArgumentException("Actions: name, entity, dialogue, glowing, baby, color, equip");
                }
                save(folder,id,y,p);plugin.reloadContent();
            }
            p.sendMessage("§aSaved and reloaded "+type+" '"+id+"'.");
        } catch(Exception ex){p.sendMessage("§cEdit failed: "+ex.getMessage());}
        openContentHub(p);
    }

    private List<String> tokenize(String input) {
        List<String> out=new ArrayList<>();
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("\\\"([^\\\"]*)\\\"|'([^']*)'|(\\S+)").matcher(input);
        while(matcher.find()) out.add(matcher.group(1)!=null?matcher.group(1):matcher.group(2)!=null?matcher.group(2):matcher.group(3));
        return out;
    }
    private Object coerce(String v){if(v.equalsIgnoreCase("true")||v.equalsIgnoreCase("false"))return Boolean.parseBoolean(v);try{return v.contains(".")?Double.parseDouble(v):Integer.parseInt(v);}catch(NumberFormatException ex){return v;}}
    private Map<String,Object> parseStep(String in) {
        List<String> tokens = tokenize(in);
        if (tokens.size() < 2) throw new IllegalArgumentException("Step needs a type and at= tick");
        String type = tokens.get(0).toLowerCase(Locale.ROOT);
        if (!net.dragonempire.chronicles.cutscenes.CutsceneParser.TYPES.contains(type)) throw new IllegalArgumentException("Unsupported step type");
        Map<String,Object> m = new LinkedHashMap<>();
        m.put("type", type);
        m.put("essential", type.equals("spawn_boss"));
        String cameraWorld = tokens.stream().filter(t -> t.startsWith("world=")).map(t -> t.substring(6)).findFirst().orElse(Bukkit.getWorlds().get(0).getName());
        for (int i=1; i<tokens.size(); i++) {
            String[] kv=tokens.get(i).split("=",2);
            if (kv.length!=2) continue;
            String k=kv[0], v=kv[1];
            if (k.equals("path")) {
                List<Map<String,Object>> points = new ArrayList<>();
                for (String encoded : v.split(";")) {
                    String[] xyz = encoded.split(",");
                    if (xyz.length < 3) throw new IllegalArgumentException("path points use x,y,z[,yaw,pitch]");
                    Map<String,Object> point = new LinkedHashMap<>();
                    point.put("world", cameraWorld);
                    point.put("x", Double.parseDouble(xyz[0])); point.put("y", Double.parseDouble(xyz[1])); point.put("z", Double.parseDouble(xyz[2]));
                    if (xyz.length > 3) point.put("yaw", Float.parseFloat(xyz[3]));
                    if (xyz.length > 4) point.put("pitch", Float.parseFloat(xyz[4]));
                    points.add(point);
                }
                if (points.size() < 2) throw new IllegalArgumentException("path needs at least two points");
                m.put("points", points);
            } else if (k.equals("from") || k.equals("to")) {
                String[] xyz=v.split(",");
                if (xyz.length<3) throw new IllegalArgumentException(k+" needs x,y,z[,yaw,pitch]");
                Map<String,Object> point=new LinkedHashMap<>();
                point.put("world", cameraWorld);
                point.put("x",Double.parseDouble(xyz[0])); point.put("y",Double.parseDouble(xyz[1])); point.put("z",Double.parseDouble(xyz[2]));
                if(xyz.length>3) point.put("yaw",Float.parseFloat(xyz[3]));
                if(xyz.length>4) point.put("pitch",Float.parseFloat(xyz[4]));
                m.put(k,point);
            } else m.put(k,coerce(v));
        }
        if(!m.containsKey("at")) throw new IllegalArgumentException("Missing at= tick offset");
        return m;
    }
    private List<String> sorted(File dir){File[] fs=dir.listFiles((d,n)->n.endsWith(".yml"));if(fs==null)return List.of();return Arrays.stream(fs).map(f->f.getName().replaceFirst("\\.yml$","")).sorted().toList();}
    private File dir(String name){File f=new File(plugin.getDataFolder(),name);if(!f.exists())f.mkdirs();return f;}
    private YamlConfiguration load(String folder,String id){File f=new File(dir(folder),id+".yml");return f.exists()?YamlConfiguration.loadConfiguration(f):null;}
    private void save(String folder,String id,YamlConfiguration y,Player p){try{File f=new File(dir(folder),id+".yml");y.save(f);}catch(IOException ex){p.sendMessage("§cCould not save: "+ex.getMessage());}}
    private static String plain(ItemStack it){return it.getItemMeta().getDisplayName().replaceAll("§[0-9a-fk-or]","").replaceAll("[\\u00A7].","").replaceAll("^[#0-9]+ • ","");}
    private static ItemStack item(Material mat,String name,List<String> lore){ItemStack it=new ItemStack(mat);ItemMeta m=it.getItemMeta();m.displayName(Component.text(name,NamedTextColor.GOLD).decoration(TextDecoration.ITALIC,false));m.lore(lore.stream().map(s->Component.text(s,NamedTextColor.GRAY).decoration(TextDecoration.ITALIC,false)).toList());it.setItemMeta(m);return it;}
    @EventHandler public void onClick(InventoryClickEvent e){if(!(e.getInventory().getHolder() instanceof Holder h))return;e.setCancelled(true);if(e.getClickedInventory()!=null&&e.getClickedInventory().equals(e.getInventory())&&e.getWhoClicked() instanceof Player p)click(p,h,e.getSlot(),e.getClick());}
    @EventHandler public void onDrag(InventoryDragEvent e){if(e.getInventory().getHolder() instanceof Holder)e.setCancelled(true);}
}
