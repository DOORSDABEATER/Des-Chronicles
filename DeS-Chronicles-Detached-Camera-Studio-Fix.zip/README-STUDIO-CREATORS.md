# DeS-Chronicles in-game Boss & Cutscene Creator

Open `/desquests studio` as an admin. The main menu now contains **Boss Creator** and **Cutscene Creator**.

## Boss Creator
- Create a boss at your current location.
- Edit display name (MiniMessage), entity type, health, arena radius, minimum contribution damage, and time limit.
- Reset the spawn location to your current location.
- Add health-threshold phases and attach supported action types to the latest phase.
- Save/reload and right-click a boss in the list to test-spawn it.

Phase ability chat format: `message text=<red>Enraged!` (quote values containing spaces). Supported actions are the existing DeS-Chronicles action set: `start_quest`, `complete_quest`, `set_flag`, `clear_flag`, `message`, `sound`, `title`, `play_cutscene`, `spawn_boss`, `add_counter`, `start_escort`, `open_shop`.

## Cutscene Creator
- Create blank cutscenes and edit skippable/shared/radius settings.
- Add, replace, and remove timeline steps.
- Steps are stored as ordered YAML data with arbitrary supported parameters and tick offsets.
- Supported step types are the existing engine types: `title`, `actionbar`, `message`, `sound`, `particle`, `lightning`, `fade`, `teleport`, `camera`, `restrict`, `dialogue`, `spawn_boss`.
- Save/reload and right-click a scene in the list to play-test it.

Step format: `type at=0 key=value key=value`. For camera steps, use `camera at=0 ticks=80 from=x,y,z,yaw,pitch to=x,y,z,yaw,pitch`. Text containing spaces should be quoted. The camera engine now creates an invisible, invulnerable marker ArmorStand as a separate spectator target. Scripted keyframes move that camera entity independently of the player body, and cleanup restores the player's original game mode/location and removes the camera entity. This is a server-side detached spectator camera; it does not require a resource pack or client mod.

The editors write to `plugins/DeS-Chronicles/bosses/` and `cutscenes/`. Existing quest, NPC, event, boss-spawn, and cutscene-playback systems are retained.

## In-game Content Workshop (Paper 26.2)

Admins can open the complete studio with `/quests studio` (or `/desquests studio`). Select **Content Workshop** to create and edit content without manually changing YAML files. Each successful edit is written to the plugin data folder and immediately reloaded.

- **Quests:** create draft quests; edit title/description and add objectives or rewards.
- **Dialogues:** create a speaker and opening node; edit speaker names, add nodes/pages, choose a start node, and add branching choices.
- **NPC designs:** create an NPC at your current location; edit its name, entity type, linked dialogue, glowing/baby state, supported entity color, and equipment slots (`helmet`, `chestplate`, `leggings`, `boots`, `hand`).

The workshop asks for a short chat entry after selecting an action. Use `CANCEL` to abandon a prompt. For multi-word text, quote it where supported. All edits are saved immediately and reloaded. A malformed edit is rejected where the underlying quest/dialogue validator detects it.

NPC appearance is plugin-only: it uses vanilla entity types, colors, equipment and visual flags. A genuinely new 3D model, custom geometry or custom texture still requires a compatible resource pack/client model system; a Paper server plugin cannot make a new model render on an unmodified client.

## Camera paths

Camera steps now support ordered keyframe paths and easing. Example:

```yaml
- type: camera
  at: 0
  ticks: 100
  easing: smooth
  points:
    - {world: world, x: 0, y: 80, z: 0, yaw: 0, pitch: 20, duration: 30}
    - {world: world, x: 15, y: 85, z: 10, yaw: 90, pitch: 10, duration: 35}
    - {world: world, x: 30, y: 75, z: 0, yaw: 180, pitch: 25, duration: 35}
```

Supported easing values: `linear`, `smooth`/`smoothstep`, `ease_in`, `ease_out`, and `hold`. The editor also accepts `path=x,y,z,yaw,pitch;x,y,z,yaw,pitch;...` plus `world=<world_name>` for a quick path in the selected world. This uses a separate invisible marker entity as the spectator target. The player body stays at its original position while the camera entity follows the keyframe path; the original mode/location are restored and the entity is removed when the scene ends.
