package net.dragonempire.chronicles.cutscenes;

import net.dragonempire.chronicles.bosses.BossManager;
import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.dialogue.DialogueManager;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.*;

/**
 * Plays data-driven cutscenes. Timing uses one cancellable scheduler task per step; every task of a run is
 * cancelled on finish, skip, quit, death or shutdown. "camera" steps move the player in spectator mode by
 * teleporting along a path (Bukkit API only: this is NOT packet-level camera control). The original game mode is
 * also stored as a player flag so a crash mid-scene is repaired on the next login.
 */
public final class CutsceneManager {
    private static final String GM_FLAG = "cutscene:gm:";

    private static final class Run {
        final Player player;
        final CutsceneDefinition def;
        final List<BukkitTask> tasks = new ArrayList<>();
        final Set<Integer> done = new HashSet<>();
        GameMode originalMode;
        Location origin;
        boolean cameraUsed;

        Run(Player player, CutsceneDefinition def) {
            this.player = player;
            this.def = def;
        }
    }

    private final JavaPlugin plugin;
    private final ContentManager content;
    private final QuestService quests;
    private final Map<UUID, Run> runs = new HashMap<>();
    private final Set<UUID> frozen = new HashSet<>();
    private DialogueManager dialogues;
    private BossManager bosses;

    public CutsceneManager(JavaPlugin plugin, ContentManager content, QuestService quests) {
        this.plugin = plugin;
        this.content = content;
        this.quests = quests;
    }

    public void setDialogues(DialogueManager d) { this.dialogues = d; }
    public void setBosses(BossManager b) { this.bosses = b; }

    public boolean isActive(UUID id) { return runs.containsKey(id); }
    public boolean isFrozen(UUID id) { return frozen.contains(id); }
    public boolean cameraActive(UUID id) { Run r = runs.get(id); return r != null && r.cameraUsed; }

    /** Returns null on success or an error message. Shared scenes also include eligible players in range. */
    public String play(String id, Player trigger) {
        CutsceneDefinition def = content.cutscenes().get(id);
        if (def == null) return "Unknown cutscene: " + id;
        if (runs.containsKey(trigger.getUniqueId())) return "A cutscene is already playing for you.";
        List<Player> audience = new ArrayList<>();
        audience.add(trigger);
        if (def.shared()) {
            for (Player other : trigger.getWorld().getPlayers()) {
                if (other.equals(trigger) || runs.containsKey(other.getUniqueId()) || !other.hasPermission("desquests.use")) continue;
                if (other.getLocation().distanceSquared(trigger.getLocation()) <= def.radius() * def.radius()) audience.add(other);
            }
        }
        for (Player p : audience) begin(p, def);
        return null;
    }

    private void begin(Player p, CutsceneDefinition def) {
        Run run = new Run(p, def);
        runs.put(p.getUniqueId(), run);
        for (int i = 0; i < def.steps().size(); i++) {
            final int index = i;
            CutsceneStep step = def.steps().get(i);
            run.tasks.add(plugin.getServer().getScheduler().runTaskLater(plugin, () -> exec(run, index, step), step.at()));
        }
        run.tasks.add(plugin.getServer().getScheduler().runTaskLater(plugin, () -> finish(run, true), def.duration()));
        if (def.skippable()) p.sendMessage(Component.text("Type /quests skip to skip this scene.", net.kyori.adventure.text.format.NamedTextColor.GRAY));
    }

    /** Runs the remaining essential steps, then ends the scene. Returns false if nothing skippable is playing. */
    public boolean skip(Player p) {
        Run run = runs.get(p.getUniqueId());
        if (run == null || !run.def.skippable()) return false;
        for (int i = 0; i < run.def.steps().size(); i++) {
            CutsceneStep s = run.def.steps().get(i);
            if (s.essential() && !run.done.contains(i)) exec(run, i, s);
        }
        finish(run, true);
        return true;
    }

    private void exec(Run run, int index, CutsceneStep step) {
        if (!runs.containsKey(run.player.getUniqueId()) || !run.player.isOnline()) return;
        run.done.add(index);
        Player p = run.player;
        Map<String, Object> m = step.params();
        try {
            switch (step.type()) {
                case "title" -> {
                    long in = ticks(m.get("fade_in"), 10), stay = ticks(m.get("stay"), 60), out = ticks(m.get("fade_out"), 10);
                    p.showTitle(Title.title(mm(str(m, "title")), mm(str(m, "subtitle")),
                            Title.Times.times(Duration.ofMillis(in * 50), Duration.ofMillis(stay * 50), Duration.ofMillis(out * 50))));
                }
                case "actionbar" -> p.sendActionBar(mm(str(m, "text")));
                case "message" -> p.sendMessage(mm(str(m, "text")));
                case "sound" -> p.playSound(Sound.sound(Key.key(str(m, "sound")), Sound.Source.MASTER,
                        m.get("volume") instanceof Number n ? n.floatValue() : 1f, m.get("pitch") instanceof Number n ? n.floatValue() : 1f));
                case "particle" -> {
                    Location at = m.get("at") instanceof Map<?, ?> pt ? point(pt) : p.getLocation().add(0, 1, 0);
                    int count = m.get("count") instanceof Number n ? n.intValue() : 20;
                    double spread = m.get("spread") instanceof Number n ? n.doubleValue() : 0.5;
                    p.spawnParticle(Particle.valueOf(str(m, "particle").toUpperCase(Locale.ROOT)), at, count, spread, spread, spread, 0.01);
                }
                case "lightning" -> {
                    Location at = m.get("at") instanceof Map<?, ?> pt ? point(pt) : p.getLocation();
                    at.getWorld().strikeLightningEffect(at); // visual only, no damage or fire
                }
                case "fade" -> p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, ((Number) m.get("ticks")).intValue(), 0, false, false, false));
                case "teleport" -> p.teleport(point((Map<?, ?>) m.get("to")));
                case "restrict" -> {
                    frozen.add(p.getUniqueId());
                    int t = ((Number) m.get("ticks")).intValue();
                    run.tasks.add(plugin.getServer().getScheduler().runTaskLater(plugin, () -> frozen.remove(p.getUniqueId()), t));
                }
                case "camera" -> camera(run, m);
                case "dialogue" -> { if (dialogues != null) dialogues.start(p, str(m, "dialogue")); }
                case "spawn_boss" -> {
                    String err = bosses == null ? "bosses unavailable" : bosses.spawn(str(m, "boss"), p);
                    if (err != null) plugin.getLogger().info("Cutscene '" + run.def.id() + "' could not spawn boss: " + err);
                }
                default -> plugin.getLogger().warning("Cutscene '" + run.def.id() + "': unhandled step type " + step.type());
            }
        } catch (RuntimeException e) {
            plugin.getLogger().severe("Cutscene '" + run.def.id() + "' step " + index + " (" + step.type() + ") failed: " + e);
        }
    }

    /** Camera paths support either from/to or an ordered points list. Each point may specify its own duration. */
    private void camera(Run run, Map<?, ?> params) {
        Player p = run.player;
        if (!run.cameraUsed) {
            run.cameraUsed = true;
            run.originalMode = p.getGameMode();
            run.origin = p.getLocation();
            quests.addFlag(p, GM_FLAG + run.originalMode.name());
            p.setGameMode(GameMode.SPECTATOR);
        }
        List<Location> points = new ArrayList<>();
        List<Integer> durations = new ArrayList<>();
        Object raw = params.get("points");
        if (raw instanceof List<?> list && list.size() >= 2) {
            int defaultSegmentTicks = params.get("ticks") instanceof Number total ? Math.max(1, total.intValue() / (list.size() - 1)) : 20;
            for (Object value : list) {
                if (!(value instanceof Map<?, ?> point)) throw new IllegalArgumentException("camera points must be maps");
                points.add(point(point));
                Object d = point.get("duration");
                durations.add(d instanceof Number n ? Math.max(1, n.intValue()) : defaultSegmentTicks);
            }
        } else {
            points.add(point((Map<?, ?>) params.get("from")));
            points.add(point((Map<?, ?>) params.get("to")));
            durations.add(Math.max(1, ((Number) params.get("ticks")).intValue()));
        }
        for (int i = 1; i < points.size(); i++) {
            if (!Objects.equals(points.get(i - 1).getWorld(), points.get(i).getWorld()))
                throw new IllegalArgumentException("camera path points must be in the same world");
        }
        String easing = String.valueOf(params.containsKey("easing") ? params.get("easing") : "linear").toLowerCase(Locale.ROOT);
        for (int segment = 0; segment < points.size() - 1; segment++) {
            final Location a = points.get(segment).clone();
            final Location b = points.get(segment + 1).clone();
            final int ticks = durations.get(segment);
            BukkitTask[] self = new BukkitTask[1];
            final int[] t = {0};
            long delay = segment == 0 ? 0L : durations.subList(0, segment).stream().mapToLong(Integer::longValue).sum();
            BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                BukkitTask mover = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
                    if (!p.isOnline() || !runs.containsKey(p.getUniqueId())) { moverCancel(self); return; }
                    double f = Math.min(1.0, (double) t[0] / ticks);
                    f = switch (easing) {
                        case "smooth", "smoothstep" -> f * f * (3.0 - 2.0 * f);
                        case "ease_in" -> f * f;
                        case "ease_out" -> 1.0 - (1.0 - f) * (1.0 - f);
                        case "hold" -> t[0] >= ticks ? 1.0 : 0.0;
                        default -> f;
                    };
                    float dyaw = ((b.getYaw() - a.getYaw() + 540) % 360) - 180;
                    Location l = new Location(a.getWorld(), a.getX() + (b.getX() - a.getX()) * f,
                            a.getY() + (b.getY() - a.getY()) * f, a.getZ() + (b.getZ() - a.getZ()) * f,
                            a.getYaw() + dyaw * (float) f, a.getPitch() + (b.getPitch() - a.getPitch()) * (float) f);
                    p.teleport(l);
                    if (++t[0] > ticks) self[0].cancel();
                }, 0L, 1L);
                self[0] = mover;
                run.tasks.add(mover);
            }, delay);
            run.tasks.add(task);
        }
    }

    private static void moverCancel(BukkitTask[] task) { if (task[0] != null) task[0].cancel(); }

    /** Ends a scene and restores the player. */
    private void finish(Run run, boolean restoreLocation) {
        if (runs.get(run.player.getUniqueId()) != run) return;
        for (BukkitTask t : run.tasks) t.cancel();
        run.tasks.clear();
        runs.remove(run.player.getUniqueId());
        frozen.remove(run.player.getUniqueId());
        if (run.cameraUsed) {
            Player p = run.player;
            p.setGameMode(run.originalMode);
            if (restoreLocation && run.origin != null) p.teleport(run.origin);
            quests.removeFlag(p, GM_FLAG + run.originalMode.name());
        }
    }

    /** Quit, death or world change: stop immediately, restoring game mode (and position unless dead). */
    public void cleanup(Player p, boolean restoreLocation) {
        Run run = runs.get(p.getUniqueId());
        if (run != null) finish(run, restoreLocation);
        frozen.remove(p.getUniqueId());
    }

    public void cleanupAll() {
        for (Run run : new ArrayList<>(runs.values())) finish(run, true);
        frozen.clear();
    }

    /** Called after login: repairs a game mode left behind by a crash or forced shutdown mid-camera. */
    public void restoreIfNeeded(Player p, PlayerState s) {
        for (String flag : new ArrayList<>(s.flags)) {
            if (!flag.startsWith(GM_FLAG)) continue;
            try {
                p.setGameMode(GameMode.valueOf(flag.substring(GM_FLAG.length())));
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Unknown stored game mode in flag '" + flag + "'");
            }
            quests.removeFlag(p, flag);
        }
    }

    private static Location point(Map<?, ?> m) {
        World w = Bukkit.getWorld(String.valueOf(m.get("world")));
        if (w == null) throw new IllegalStateException("world '" + m.get("world") + "' is not loaded");
        return new Location(w, ((Number) m.get("x")).doubleValue(), ((Number) m.get("y")).doubleValue(), ((Number) m.get("z")).doubleValue(),
                m.get("yaw") instanceof Number n ? n.floatValue() : 0f, m.get("pitch") instanceof Number n ? n.floatValue() : 0f);
    }

    private static long ticks(Object o, long def) { return o instanceof Number n ? n.longValue() : def; }
    private static String str(Map<String, Object> m, String k) { Object v = m.get(k); return v == null ? "" : String.valueOf(v); }
    private static Component mm(String s) { return MiniMessage.miniMessage().deserialize(s); }
}
