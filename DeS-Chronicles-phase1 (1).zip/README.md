# DeS-Chronicles

Quest / NPC / dialogue / campaign framework for Dragon Empire SMP (Paper 26.2, Java 25).
Content (quests, dialogues, NPCs, questlines, cutscenes, bosses, events, locations, achievements) lives in YAML files;
no Java changes are needed to add stories.

## Honest status

Verified by CI earlier (revision 1): storage, conditions, dialogue logic, objective logic, rewards.
Verified offline since: 45 pure-logic tests pass on JDK 21; every sample file parses with 0 issues; samples were checked
against the code (every objective type is emitted by a listener, every published quest can be started by a player);
and all 101 source files type-check with 0 errors against hand-written stand-ins for the Paper/Adventure APIs.
**That last check proves internal consistency only.** The stand-ins were written from memory of the API, so a signature
that differs in the real Paper 26.2 will still show up as a compile error on the first real build. Spots most likely to
need a one-line fix: `Particle.valueOf` (CutsceneManager), `Attribute.MAX_HEALTH` (BossManager and EscortManager),
`Mob#getPathfinder` (EscortManager), scoreboard calls (SidebarService). Nothing has run on a server.

### Working (once it compiles and loads)
- **Quests:** stages, sequential/parallel objectives, optional objectives, "N of M" completion, prerequisites, mutually
  exclusive quests, repeatable / daily / weekly quests, hidden quests, event-gated quests, `on_start`/`on_complete` actions,
  per-player persistence, shared party progress (distance-limited), draft/published/disabled status
- **Objectives** (event-driven, no per-tick scanning): KILL_MOB, KILL_BOSS, COLLECT_ITEM, CRAFT_ITEM, SMELT_ITEM, FISH_ITEM,
  VISIT_LOCATION, ENTER_WORLD, TALK_NPC, INTERACT_NPC, COMPLETE_QUEST, TRAVEL_DISTANCE, SURVIVE (`reset_on_death`),
  plus any type you define through configured blocks (ACTIVATE_BLOCK, ACTIVATE_RITUAL, INTERACT_OBJECT, SOLVE_PUZZLE ...)
- **Questlines:** chapters, chapter prerequisites, alternative routes, optional/hidden chapters, endings, chapter and
  campaign rewards (paid once), cycle detection, quests locked until their chapter unlocks
- **Dialogue:** pages, clickable choices, AND/OR/NOT conditions, start variants, actions, remembered choices
- **Conditions:** quest done/active, item, permission, level, achievement, visited, boss defeated, previous choice,
  questline stage, event active, counter (reputation/morality/relationship), global (community) total
- **Reputation / morality / decisions:** numeric counters via reward `counter` or action `add_counter`; `/quests reputation`
- **Community goals:** server-wide counters and goals (`community.yml`), reward type `global`, `/quests community`
- **Rewards:** item, xp, money (optional Vault, via reflection), command, flag, achievement, counter, global; chances;
  atomic claim so a reward can never be duplicated
- **Achievements**, **leaderboards** (`/quests top <quest>`), **recommendations** (`/quests recommend`)
- **Cutscenes:** timed steps (title, actionbar, message, sound, particle, lightning, fade, teleport, restrict, dialogue,
  spawn_boss, camera), individual or shared, skippable, cleanup on quit/death/shutdown, crash repair of game mode
- **Bosses:** vanilla-entity bosses with phases, arena, time limit, contribution tracking; only real participants get credit
- **Events:** schedule window plus persisted manual start/stop, announcements, no restart needed
- **Parties:** create/invite/accept/leave/list (in memory)
- **NPCs:** persistent definitions, respawn on chunk load, permission + distance checks, `look_at_players`, `patrol`,
  per-player visibility (`visible_if`), external NPCs (e.g. Citizens) through `/desquests npc talk`
- **HUD:** action-bar tracker, boss-bar distance marker to the next location (`/quests markers on|off`),
  optional sidebar (`/quests sidebar on|off`)
- **Admin studio:** `/desquests studio` menu (draft/publish/disable quests with validation and rollback, preview, NPC
  teleport/move, event toggles, diagnostics, reload) plus `quest publish|disable|draft|validate` commands
- **Escort / protect quests:** a mob follows the player to a destination; fails if it dies, time runs out, or the player
  dies/leaves; fires ESCORT and PROTECT_NPC on arrival (`escorts.yml`, action `start_escort`)
- **Merchant NPCs:** `shop:` offers on an NPC (or action `open_shop`), paid through the optional Vault economy
- **Animated dialogue:** typewriter text with a per-speaker voice blip on the action bar, then full text and clickable
  choices in chat (`dialogue.animate`, `chars_per_tick`, `blip_sound` in config)
- **Localisation:** `language:` in config and `lang/<code>.yml`; English is bundled as the fallback. Covers the main
  player-facing messages (quest start/complete/stage/reward/requirement messages, dialogue and NPC prompts, shops, escorts);
  command output, journal/studio menus and cutscene text are still English or content-defined
- **In-game quest authoring:** `quest create|set|addobjective|addreward|delete`; every change is validated by a reload
  and rolled back if it would make the quest invalid
- Quest journal GUI, validation with file + field messages, safe reloads (progress never touched)

### NOT implemented
Deep Citizens and MythicMobs API adapters (only command bridges: `npc talk`, `boss credit`),
real player skins without Citizens, guard/hostile NPC profiles, in-game editors for dialogue, staged objectives and
cutscenes (edit YAML, then reload), resource pack (needs audio/texture assets and the exact 26.2 pack format), full
localisation coverage, procedural quest templates, difficulty scaling, player-specific story instances, party persistence, packet-level camera (the camera step uses
spectator teleporting). COLLECT_ITEM counts pickups (farmable by drop and re-pickup); CRAFT_ITEM under-counts shift-click.

## Build
JDK 25 + Gradle 9.1+: `gradle build`. Jar: `build/libs/DeS-Chronicles-<version>.jar`.

## First-time setup
1. Start the server once. Sample files are copied (once) into `plugins/DeS-Chronicles/`. Delete what you do not want;
   it is not recreated.
2. Edit `locations.yml` (real world/coordinates, remove `enabled: false`).
3. Stand where the Ancient One should be: `/desquests npc create ancient_one`, then
   `/desquests npc dialogue ancient_one ancient_one_intro`. `/desquests validate` must report 0 issues.
4. Boss: edit `bosses/archive_guardian.yml` (coordinates, `configured: true`), reload, test with `/desquests boss spawn archive_guardian`.
5. Winter demo: `/desquests event start winter_festival`, ask the Ancient One about the festival, craft snow blocks.
6. Puzzle demo: configure `interactables.yml`, then publish `fa_puzzle_runes` from `/desquests studio`.
7. Escort demo: configure `escorts.yml` (`configured: true`), then publish `fa_escort_archivist`.
8. Merchant: add to an NPC file `shop: [{item: BREAD, amount: 4, price: 10}]` (needs Vault + an economy plugin); with no
   dialogue set, right-clicking opens the shop.

## Commands
Player (`desquests.use`, default true): `/quests` (journal), `active|available|completed`, `track|untrack|abandon <quest>`,
`questlines`, `achievements`, `reputation`, `community`, `recommend`, `top <quest>`, `markers on|off`, `sidebar on|off`,
`party create|invite <player>|accept|leave|list`, `skip`, `help`.
Admin: `/desquests studio | reload | validate | diagnostics`, `npc create|move|delete|list|dialogue|talk`,
`quest give|complete|reset <player> <id>`, `quest publish|disable|draft|validate|delete <id>`,
`quest create <id>`, `quest set <id> <title|description|giver|category|repeatable|hidden|reset|event|party> <value>`,
`quest addobjective <id> <TYPE> <target|-> <amount>`, `quest addreward <id> <type> [key=value ...]`, `progress <player>`,
`cutscene play <id> [player]`, `event start|stop|list [id]`, `boss spawn <id>` / `boss credit <id> <player>`, `questline`.

## Permissions
`desquests.use` (default true) - `desquests.admin` (op; grants all below) - `desquests.reload` - `desquests.npc.create` -
`desquests.npc.edit` - `desquests.quest.edit` (also the studio and publish/disable) - `desquests.dialogue.manage` -
`desquests.progress.manage` - `desquests.debug` - `desquests.cutscene.manage` - `desquests.event.manage` -
`desquests.boss.manage` - `desquests.questline.manage` - `desquests.quest.create` - `desquests.quest.delete` - `desquests.quest.publish`. The studio menu itself requires `desquests.admin`.

## Citizens and MythicMobs (command bridges)
Citizens (real player skins): create the NPC in Citizens, give it a skin, then
`/npc cmd add desquests npc talk <id> <p>` (runs as console). Define `npc/<id>.yml` with `provider: external` and a `dialogue`;
quest `TALK_NPC` objectives and dialogue then work for it. MythicMobs: in a skill, run console command
`desquests boss credit <bossId> <player>` for each participant to fire the same KILL_BOSS objective.

## Authoring
Quest `quests/<id>.yml`:
```yaml
title: "Lost Memories"
description: "..."
status: published        # draft | published | disabled  (the studio and commands edit only this line)
giver: "The Ancient One"
category: main           # main | side | daily | secret | ... (used by /quests recommend)
repeatable: false
hidden: false            # hidden quests never appear under Available
reset: none              # daily | weekly (timezone: config reset.timezone)
event: winter_festival   # optional: only startable while this event is active
party: shared            # optional: members within party_distance (default 30) share progress
prerequisites: [other_quest]
excludes: [quest_that_blocks_this]
on_start:   [{type: play_cutscene, cutscene: guardian_awakens}]
on_complete: []
stages:                  # or a flat "objectives:" list = one stage
  - mode: sequential     # or parallel
    required: 2          # optional: how many non-optional objectives finish the stage
    objectives:
      - {id: shards, type: COLLECT_ITEM, target: AMETHYST_SHARD, amount: 8, optional: false, hidden: false, reset_on_death: false, description: "..."}
rewards:
  - {type: xp, amount: 100}
  - {type: item, item: DIAMOND, amount: 1, chance: 0.25, key: rare}
  - {type: money, amount: 250}                         # Vault + an economy plugin
  - {type: command, command: "give {player} apple 1"}  # console command: admin-authored only
  - {type: flag, flag: "ending:restore"}
  - {type: achievement, id: guardian_slayer}           # must exist in achievements.yml
  - {type: counter, key: "rep:archivists", amount: 5}  # reputation / morality / relationship points
  - {type: global, key: snow_blocks, amount: 4}        # community counter
```
Dialogue `dialogues/<id>.yml`: `speaker`, `color`, `start`, optional `start_variants` (`if` + `node`), `nodes` with `pages`,
`choices` (`id`, `text`, `if`, `next`, `actions`), `on_enter`. `next: end` ends it. Conditions combine as lists (AND), `any:`,
`all:`, `not:`. Actions: `start_quest`, `complete_quest`, `set_flag`, `clear_flag`, `add_counter`, `message`, `sound`, `title`,
`play_cutscene`, `spawn_boss`, `start_escort`, `open_shop`. Text is MiniMessage; `{player}` is replaced.
Conditions: `completed_quest`, `not_completed_quest`, `active_quest`, `has_item`, `permission`, `level`, `achievement`, `visited`,
`defeated_boss`, `chose`, `questline_stage`, `event_active`, `counter` (`key`, `min`/`max`), `global` (`key`, `min`).
Flags used by conditions are plain strings: `ach:<id>`, `boss:<id>`, `stage:<line>:<chapter>`, `stage:<line>:complete`.
NPC `npc/<id>.yml`: `name`, `entity`, `location`, `dialogue`, `interact_distance`, `permission`, `provider: entity|external`,
`look_at_players: true`, `behavior: stationary|patrol` (+ `patrol: [{x,y,z},...]`, `patrol_speed`), `visible_if:` (condition).
Other folders: `questlines/`, `cutscenes/`, `bosses/`, `events/`, `lang/`, plus `locations.yml`, `achievements.yml`,
`community.yml`, `escorts.yml`, `interactables.yml` (configured blocks and ordered puzzles). See the samples for full examples.
Edit content, then `/desquests reload`; player progress is never touched by reloads.
