package net.dragonempire.chronicles.messages;

import java.util.Map;

/** Message lookup with language fallback and {placeholder} substitution. Pure logic; Messages adds Bukkit/Adventure on top. */
public final class MessageCatalog {
    private final Map<String, String> primary;
    private final Map<String, String> fallback;

    public MessageCatalog(Map<String, String> primary, Map<String, String> fallback) {
        this.primary = primary;
        this.fallback = fallback;
    }

    public boolean has(String key) { return primary.containsKey(key) || fallback.containsKey(key); }

    public String raw(String key) {
        String v = primary.get(key);
        if (v == null) v = fallback.get(key);
        return v == null ? "<red>[missing message: " + key + "]</red>" : v;
    }

    /** kv alternates placeholder name and value: format("k", "quest", "Lost Memories"). */
    public String format(String key, String... kv) {
        if (kv.length % 2 != 0) throw new IllegalArgumentException("placeholders must come in name/value pairs");
        String s = raw(key);
        for (int i = 0; i < kv.length; i += 2) s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        return s;
    }
}
