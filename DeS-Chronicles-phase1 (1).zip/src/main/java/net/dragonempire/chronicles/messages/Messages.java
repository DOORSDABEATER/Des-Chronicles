package net.dragonempire.chronicles.messages;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Localised player messages. English is bundled in the jar as the fallback; plugins/DeS-Chronicles/lang/&lt;code&gt;.yml
 * (chosen with "language" in config.yml) overrides it key by key. Placeholder values are escaped so player names or
 * quest titles can never inject formatting. Only the main player-facing messages go through here (see README).
 */
public final class Messages {
    private static volatile MessageCatalog catalog = new MessageCatalog(Map.of(), Map.of());

    private Messages() {}

    public static void init(JavaPlugin plugin) {
        Map<String, String> fallback = new LinkedHashMap<>();
        try (InputStream in = plugin.getResource("lang/en.yml")) {
            if (in != null) flatten(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)), fallback);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not read bundled English messages: " + e);
        }
        Map<String, String> primary = new LinkedHashMap<>();
        String lang = plugin.getConfig().getString("language", "en");
        File file = new File(plugin.getDataFolder(), "lang/" + lang + ".yml");
        if (file.isFile()) {
            flatten(YamlConfiguration.loadConfiguration(file), primary);
        } else if (!lang.equals("en")) {
            plugin.getLogger().warning("Language file lang/" + lang + ".yml not found; using English.");
        }
        catalog = new MessageCatalog(primary, fallback);
    }

    private static void flatten(YamlConfiguration y, Map<String, String> out) {
        for (String key : y.getKeys(true)) {
            if (y.isString(key)) out.put(key, y.getString(key));
        }
    }

    public static Component get(String key, String... kv) {
        return MiniMessage.miniMessage().deserialize(catalog.format(key, escape(kv)));
    }

    /** Same text without formatting, for APIs that take plain strings. */
    public static String plain(String key, String... kv) {
        return PlainTextComponentSerializer.plainText().serialize(get(key, kv));
    }

    private static String[] escape(String[] kv) {
        String[] out = kv.clone();
        for (int i = 1; i < out.length; i += 2) out[i] = MiniMessage.miniMessage().escapeTags(out[i]);
        return out;
    }
}
