package net.dragonempire.chronicles.objectives;

public record ObjectiveSpec(String id, String type, String target, int amount, boolean optional,
                            boolean hidden, String description, boolean resetOnDeath) {
    public boolean matches(ObjectiveEvent e) {
        if (!type.equalsIgnoreCase(e.type())) return false;
        return target == null || target.equals("*") || target.equalsIgnoreCase(e.target());
    }
}
