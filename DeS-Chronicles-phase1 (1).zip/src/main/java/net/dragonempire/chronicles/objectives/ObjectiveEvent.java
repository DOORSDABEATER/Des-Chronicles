package net.dragonempire.chronicles.objectives;

/** Something a player did, reported by listeners. type e.g. KILL_MOB, target e.g. ZOMBIE. */
public record ObjectiveEvent(String type, String target, int amount) {
    public ObjectiveEvent(String type, String target) { this(type, target, 1); }
}
