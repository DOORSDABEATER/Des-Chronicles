package net.dragonempire.chronicles.objectives;

import java.util.List;

/** requiredCount = how many non-optional objectives must be done to finish the stage. */
public record StageSpec(String title, boolean sequential, int requiredCount, List<ObjectiveSpec> objectives) {}
