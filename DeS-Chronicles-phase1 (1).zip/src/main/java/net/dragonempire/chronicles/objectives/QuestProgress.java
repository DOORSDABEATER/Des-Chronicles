package net.dragonempire.chronicles.objectives;

import java.util.*;

/** Mutable per-player progress for one quest. Not thread-safe: use on the main thread. */
public final class QuestProgress {
    private int stage;
    private boolean complete;
    private final Map<String, Integer> counts = new LinkedHashMap<>();

    public int stage() { return stage; }
    public boolean complete() { return complete; }
    public int count(String objectiveId) { return counts.getOrDefault(objectiveId, 0); }

    public boolean isDone(ObjectiveSpec o) { return count(o.id()) >= o.amount(); }

    public int optionalCompleted(QuestPlan plan) {
        int n = 0;
        for (StageSpec st : plan.stages()) for (ObjectiveSpec o : st.objectives()) if (o.optional() && isDone(o)) n++;
        return n;
    }

    public ProgressResult apply(QuestPlan plan, ObjectiveEvent ev) {
        if (complete || ev.amount() < 1) return ProgressResult.NONE;
        StageSpec st = plan.stages().get(stage);
        List<String> changed = new ArrayList<>();
        boolean gateTaken = false;
        for (ObjectiveSpec o : st.objectives()) {
            if (isDone(o)) continue;
            if (st.sequential() && !o.optional()) {
                if (gateTaken) continue; // only the first pending required objective may progress
                gateTaken = true;
            }
            if (!o.matches(ev)) continue;
            counts.put(o.id(), Math.min(o.amount(), count(o.id()) + ev.amount()));
            changed.add(o.id());
        }
        if (changed.isEmpty()) return ProgressResult.NONE;

        boolean advanced = false;
        long done = st.objectives().stream().filter(o -> !o.optional() && isDone(o)).count();
        if (done >= st.requiredCount()) {
            stage++;
            advanced = true;
            if (stage >= plan.stages().size()) {
                complete = true;
                stage = plan.stages().size() - 1;
            }
        }
        return new ProgressResult(List.copyOf(changed), advanced, complete);
    }

    /** Zeroes unfinished objectives of the current stage that are marked reset_on_death. True if anything changed. */
    public boolean resetOnDeath(QuestPlan plan) {
        if (complete || stage >= plan.stages().size()) return false;
        boolean changed = false;
        for (ObjectiveSpec o : plan.stages().get(stage).objectives()) {
            if (o.resetOnDeath() && !isDone(o) && count(o.id()) > 0) {
                counts.put(o.id(), 0);
                changed = true;
            }
        }
        return changed;
    }

    /** Compact storable form: "stage;complete;id=count,id=count". */
    public String encode() {
        StringBuilder sb = new StringBuilder().append(stage).append(';').append(complete ? 1 : 0).append(';');
        boolean first = true;
        for (Map.Entry<String, Integer> e : counts.entrySet()) {
            if (!first) sb.append(',');
            sb.append(e.getKey()).append('=').append(e.getValue());
            first = false;
        }
        return sb.toString();
    }

    /** Throws IllegalArgumentException on corrupt input so callers can log and recover. */
    public static QuestProgress decode(String s) {
        String[] parts = s.split(";", -1);
        if (parts.length != 3) throw new IllegalArgumentException("bad progress string: " + s);
        QuestProgress p = new QuestProgress();
        try {
            p.stage = Integer.parseInt(parts[0]);
            p.complete = parts[1].equals("1");
            if (!parts[2].isEmpty()) {
                for (String kv : parts[2].split(",")) {
                    int eq = kv.indexOf('=');
                    if (eq < 1) throw new IllegalArgumentException("bad entry: " + kv);
                    p.counts.put(kv.substring(0, eq), Integer.parseInt(kv.substring(eq + 1)));
                }
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("bad progress string: " + s, e);
        }
        return p;
    }
}
