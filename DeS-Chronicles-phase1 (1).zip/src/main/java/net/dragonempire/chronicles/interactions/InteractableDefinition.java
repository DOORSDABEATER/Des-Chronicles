package net.dragonempire.chronicles.interactions;

/** A configured block. Right-clicking it fires an ObjectiveEvent of type `event` with target = id. */
public record InteractableDefinition(String id, String world, int x, int y, int z, String event) {
    public String key() { return world + ":" + x + ":" + y + ":" + z; }
}
