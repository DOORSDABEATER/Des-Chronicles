package net.dragonempire.chronicles.interactions;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Per-player progress through ordered-step puzzles. Main thread only. */
public final class PuzzleTracker {
    public enum Result { PROGRESS, SOLVED, WRONG }

    private final Map<UUID, Map<String, Integer>> index = new HashMap<>();

    public Result advance(UUID player, PuzzleDefinition puzzle, String stepId) {
        Map<String, Integer> mine = index.computeIfAbsent(player, k -> new HashMap<>());
        int i = mine.getOrDefault(puzzle.id(), 0);
        if (puzzle.steps().get(i).equals(stepId)) {
            if (i + 1 == puzzle.steps().size()) {
                mine.put(puzzle.id(), 0);
                return Result.SOLVED;
            }
            mine.put(puzzle.id(), i + 1);
            return Result.PROGRESS;
        }
        // A wrong step restarts the puzzle, but it may itself be a valid first step.
        mine.put(puzzle.id(), puzzle.steps().get(0).equals(stepId) ? 1 : 0);
        return Result.WRONG;
    }

    public void forget(UUID player) { index.remove(player); }
}
