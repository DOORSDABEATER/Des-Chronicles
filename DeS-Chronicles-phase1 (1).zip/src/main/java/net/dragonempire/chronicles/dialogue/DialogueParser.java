package net.dragonempire.chronicles.dialogue;

import net.dragonempire.chronicles.condition.Condition;
import net.dragonempire.chronicles.condition.ConditionParser;
import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

/** Parses and validates a dialogue document. Returns null (with issues) if it is unusable. */
public final class DialogueParser {
    private DialogueParser() {}

    public static DialogueDefinition parse(String id, Map<String, Object> root, String file,
                                           Set<String> knownActions, List<ValidationIssue> issues) {
        int before = issues.size();
        String speaker = root.get("speaker") instanceof String s ? s : id;
        String color = root.get("color") instanceof String s ? s : "#ffffff";

        if (!(root.get("nodes") instanceof Map<?, ?> rawNodes) || rawNodes.isEmpty()) {
            issues.add(new ValidationIssue(file, "nodes", "required, at least one node"));
            return null;
        }

        Map<String, DialogueNode> nodes = new LinkedHashMap<>();
        for (Map.Entry<?, ?> e : rawNodes.entrySet()) {
            String nid = String.valueOf(e.getKey());
            String p = "nodes." + nid;
            if (!(e.getValue() instanceof Map<?, ?> nm)) {
                issues.add(new ValidationIssue(file, p, "must be a map"));
                continue;
            }
            List<String> pages = new ArrayList<>();
            if (nm.get("pages") instanceof List<?> pl) {
                for (Object o : pl) pages.add(String.valueOf(o));
            } else if (nm.get("text") instanceof String t) {
                pages.add(t);
            }
            if (pages.isEmpty()) {
                issues.add(new ValidationIssue(file, p + ".pages", "at least one page of text required"));
                continue;
            }
            List<DialogueChoice> choices = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            if (nm.get("choices") instanceof List<?> cl) {
                for (int i = 0; i < cl.size(); i++) {
                    String cp = p + ".choices[" + i + "]";
                    if (!(cl.get(i) instanceof Map<?, ?> cm)) {
                        issues.add(new ValidationIssue(file, cp, "must be a map"));
                        continue;
                    }
                    String cid = cm.get("id") instanceof String s ? s : null;
                    String text = cm.get("text") instanceof String s ? s : null;
                    if (cid == null || cid.isBlank()) { issues.add(new ValidationIssue(file, cp + ".id", "required")); continue; }
                    if (text == null || text.isBlank()) { issues.add(new ValidationIssue(file, cp + ".text", "required")); continue; }
                    if (!seen.add(cid)) { issues.add(new ValidationIssue(file, cp + ".id", "duplicate choice id '" + cid + "'")); continue; }
                    String next = cm.get("next") instanceof String s && !s.equalsIgnoreCase("end") ? s : null;
                    Condition cond = ConditionParser.parse(cm.get("if"), file, cp + ".if", issues);
                    choices.add(new DialogueChoice(cid, text, cond, next, parseActions(cm.get("actions"), file, cp + ".actions", knownActions, issues)));
                }
            }
            nodes.put(nid, new DialogueNode(nid, List.copyOf(pages), List.copyOf(choices),
                    parseActions(nm.get("on_enter"), file, p + ".on_enter", knownActions, issues)));
        }

        String start = root.get("start") instanceof String s ? s : null;
        if (start == null || !nodes.containsKey(start)) {
            issues.add(new ValidationIssue(file, "start", "must name an existing node"));
        }

        List<DialogueDefinition.StartVariant> variants = new ArrayList<>();
        if (root.get("start_variants") instanceof List<?> vl) {
            for (int i = 0; i < vl.size(); i++) {
                String vp = "start_variants[" + i + "]";
                if (vl.get(i) instanceof Map<?, ?> vm && vm.get("node") instanceof String n && nodes.containsKey(n)) {
                    variants.add(new DialogueDefinition.StartVariant(ConditionParser.parse(vm.get("if"), file, vp + ".if", issues), n));
                } else {
                    issues.add(new ValidationIssue(file, vp + ".node", "must name an existing node"));
                }
            }
        }

        for (DialogueNode n : nodes.values()) {
            for (DialogueChoice c : n.choices()) {
                if (c.next() != null && !nodes.containsKey(c.next())) {
                    issues.add(new ValidationIssue(file, "nodes." + n.id() + ".choices." + c.id() + ".next",
                            "unknown node '" + c.next() + "'"));
                }
            }
        }

        if (issues.size() > before) {
            // Any error in this document makes it unusable; callers keep the previous version if any.
            return null;
        }

        // Unreachable nodes are reported as issues too, but are not fatal; check after success.
        Set<String> reach = new HashSet<>();
        Deque<String> q = new ArrayDeque<>();
        q.add(start);
        variants.forEach(v -> q.add(v.node()));
        while (!q.isEmpty()) {
            String n = q.poll();
            if (!reach.add(n)) continue;
            for (DialogueChoice c : nodes.get(n).choices()) if (c.next() != null) q.add(c.next());
        }
        for (String n : nodes.keySet()) {
            if (!reach.contains(n)) issues.add(new ValidationIssue(file, "nodes." + n, "warning: unreachable node"));
        }
        return new DialogueDefinition(id, speaker, color, start, List.copyOf(variants), Collections.unmodifiableMap(nodes));
    }

    @SuppressWarnings("unchecked")
    public static List<DialogueAction> parseActions(Object raw, String file, String path, Set<String> known,
                                                List<ValidationIssue> issues) {
        List<DialogueAction> out = new ArrayList<>();
        if (raw == null) return out;
        if (!(raw instanceof List<?> l)) {
            issues.add(new ValidationIssue(file, path, "must be a list"));
            return out;
        }
        for (int i = 0; i < l.size(); i++) {
            String ap = path + "[" + i + "]";
            if (l.get(i) instanceof Map<?, ?> m && m.get("type") instanceof String t) {
                if (!known.contains(t.toLowerCase(Locale.ROOT))) {
                    issues.add(new ValidationIssue(file, ap + ".type", "unknown action '" + t + "'"));
                    continue;
                }
                out.add(new DialogueAction(t.toLowerCase(Locale.ROOT), (Map<String, Object>) m));
            } else {
                issues.add(new ValidationIssue(file, ap, "must be a map with a type"));
            }
        }
        return out;
    }
}
