package net.dragonempire.chronicles.dialogue;

import net.dragonempire.chronicles.condition.Condition;
import net.dragonempire.chronicles.condition.ConditionContext;

import java.util.List;
import java.util.Map;

public record DialogueDefinition(String id, String speaker, String color, String defaultStart,
                                 List<StartVariant> variants, Map<String, DialogueNode> nodes) {

    /** First variant whose condition passes, else the default start node. */
    public record StartVariant(Condition condition, String node) {}

    public String resolveStart(ConditionContext ctx) {
        for (StartVariant v : variants) if (v.condition().test(ctx)) return v.node();
        return defaultStart;
    }
}
