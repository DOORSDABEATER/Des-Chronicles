package net.dragonempire.chronicles.dialogue;

import java.util.List;

public record DialogueNode(String id, List<String> pages, List<DialogueChoice> choices, List<DialogueAction> onEnter) {}
