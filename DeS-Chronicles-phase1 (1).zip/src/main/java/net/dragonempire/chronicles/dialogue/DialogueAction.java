package net.dragonempire.chronicles.dialogue;

import java.util.Map;

/** A validated, data-only action (no scripts). Executed by registered handlers. */
public record DialogueAction(String type, Map<String, Object> params) {}
