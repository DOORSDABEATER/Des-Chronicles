package net.dragonempire.chronicles.dialogue;

import net.dragonempire.chronicles.actions.ActionExecutor;
import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.player.PlayerContext;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Chat-based dialogue runtime. Pages and choices are clickable; clicks run /quests dialogue ... */
public final class DialogueManager {
    private final ContentManager content;
    private final QuestService quests;
    private final ActionExecutor actions;
    private final Map<UUID, DialogueSession> sessions = new HashMap<>();
    private final net.dragonempire.chronicles.condition.WorldView view;
    private final JavaPlugin plugin;
    private final boolean animate;
    private final int charsPerTick;
    private String blip;
    private final Map<UUID, BukkitTask> animations = new HashMap<>();

    public DialogueManager(JavaPlugin plugin, ContentManager content, QuestService quests, ActionExecutor actions,
                           net.dragonempire.chronicles.condition.WorldView view, boolean animate, int charsPerTick, String blip) {
        this.plugin = plugin;
        this.animate = animate;
        this.charsPerTick = Math.max(1, charsPerTick);
        this.blip = blip == null || blip.isBlank() ? null : blip;
        this.content = content;
        this.quests = quests;
        this.actions = actions;
        this.view = view;
    }

    public boolean start(Player p, String dialogueId) {
        DialogueDefinition def = content.dialogues().get(dialogueId);
        if (def == null) {
            p.sendMessage(Messages.get("dialogue.nothing"));
            return false;
        }
        PlayerState st = quests.state(p);
        if (st == null) {
            p.sendMessage(Messages.get("quest.loading"));
            return false;
        }
        DialogueSession s = new DialogueSession(def, new PlayerContext(p, st, view));
        sessions.put(p.getUniqueId(), s);
        actions.run(p, s.enterActions());
        render(p, s);
        return true;
    }

    public void next(Player p) {
        DialogueSession s = sessions.get(p.getUniqueId());
        if (s == null) {
            p.sendMessage(Messages.get("dialogue.none"));
            return;
        }
        s.advance();
        if (s.ended()) {
            sessions.remove(p.getUniqueId());
            return;
        }
        render(p, s);
    }

    /** index is 1-based, as shown to the player. */
    public void choose(Player p, int index) {
        DialogueSession s = sessions.get(p.getUniqueId());
        if (s == null) {
            p.sendMessage(Messages.get("dialogue.none"));
            return;
        }
        DialogueSession.ChoiceResult r;
        try {
            r = s.choose(index - 1);
        } catch (IllegalArgumentException e) {
            p.sendMessage(Messages.get("dialogue.invalid"));
            return;
        }
        String choiceId = s.history().get(s.history().size() - 1);
        quests.addFlag(p, "choice:" + s.definition().id() + ":" + choiceId);
        actions.run(p, r.actions());
        if (r.ended()) {
            sessions.remove(p.getUniqueId());
            return;
        }
        actions.run(p, s.enterActions());
        render(p, s);
    }

    public void end(UUID id) {
        cancelAnimation(id);
        DialogueSession s = sessions.remove(id);
        if (s != null) s.interrupt();
    }

    private void cancelAnimation(UUID id) {
        BukkitTask t = animations.remove(id);
        if (t != null) t.cancel();
    }

    /**
     * Typewriter effect: the page types out on the action bar (with a voice blip), then the full text and the
     * clickable choices appear in chat. Capped at about 3 seconds per page; clicking on cancels it.
     */
    private void render(Player p, DialogueSession s) {
        cancelAnimation(p.getUniqueId());
        String text = s.pageText().replace("{player}", p.getName());
        String plain = PlainTextComponentSerializer.plainText().serialize(MiniMessage.miniMessage().deserialize(text));
        if (!animate || plain.length() < 4) {
            show(p, s);
            return;
        }
        DialogueDefinition def = s.definition();
        TextColor color = TextColor.fromHexString(def.color());
        if (color == null) color = NamedTextColor.WHITE;
        final TextColor speakerColor = color;
        int perTick = Math.max(charsPerTick, (int) Math.ceil(plain.length() / 60.0));
        float pitch = 0.8f + (Math.abs(def.speaker().hashCode()) % 10) / 10f;
        int[] shown = {0};
        BukkitTask[] self = new BukkitTask[1];
        self[0] = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || sessions.get(p.getUniqueId()) != s) {
                self[0].cancel();
                animations.remove(p.getUniqueId());
                return;
            }
            shown[0] = Math.min(plain.length(), shown[0] + perTick);
            p.sendActionBar(Component.text(def.speaker() + ": ", speakerColor, TextDecoration.BOLD)
                    .append(Component.text(plain.substring(0, shown[0]), NamedTextColor.WHITE)));
            if (blip != null) {
                try {
                    p.playSound(Sound.sound(Key.key(blip), Sound.Source.VOICE, 0.25f, pitch));
                } catch (RuntimeException e) {
                    plugin.getLogger().warning("Invalid dialogue.blip_sound '" + blip + "'; blips disabled: " + e.getMessage());
                    blip = null;
                }
            }
            if (shown[0] >= plain.length()) {
                self[0].cancel();
                animations.remove(p.getUniqueId());
                show(p, s);
            }
        }, 0L, 1L);
        animations.put(p.getUniqueId(), self[0]);
    }

    private void show(Player p, DialogueSession s) {
        DialogueDefinition def = s.definition();
        TextColor color = TextColor.fromHexString(def.color());
        if (color == null) color = NamedTextColor.WHITE;
        p.sendMessage(Component.empty());
        p.sendMessage(Component.text("» ", NamedTextColor.DARK_GRAY)
                .append(Component.text(def.speaker(), color, TextDecoration.BOLD)));
        p.sendMessage(MiniMessage.miniMessage().deserialize(s.pageText().replace("{player}", p.getName())));

        List<DialogueChoice> vis = s.visibleChoices();
        if (s.hasMorePages() || vis.isEmpty()) {
            p.sendMessage(Messages.get("dialogue.continue")
                    .clickEvent(ClickEvent.runCommand("/quests dialogue next")));
            return;
        }
        for (int i = 0; i < vis.size(); i++) {
            p.sendMessage(Component.text("[" + (i + 1) + "] ", NamedTextColor.YELLOW)
                    .append(MiniMessage.miniMessage().deserialize(vis.get(i).text()))
                    .clickEvent(ClickEvent.runCommand("/quests dialogue choose " + (i + 1))));
        }
    }
}
