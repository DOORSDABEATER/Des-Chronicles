package net.dragonempire.chronicles.dialogue;

import net.dragonempire.chronicles.content.Yamls;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.bukkit.configuration.InvalidConfigurationException;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class DialogueLoader {
    private DialogueLoader() {}

    public static Map<String, DialogueDefinition> load(Path dir, Set<String> knownActions, List<ValidationIssue> issues) {
        Map<String, DialogueDefinition> out = new LinkedHashMap<>();
        if (!Files.isDirectory(dir)) return out;
        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.yml")) {
            ds.forEach(files::add);
        } catch (IOException e) {
            issues.add(new ValidationIssue(dir.toString(), "(directory)", "cannot list: " + e.getMessage()));
            return out;
        }
        Collections.sort(files);
        for (Path f : files) {
            String name = f.getFileName().toString();
            try {
                Map<String, Object> root = Yamls.load(f);
                String id = root.get("id") instanceof String s ? s : name.substring(0, name.length() - 4);
                DialogueDefinition d = DialogueParser.parse(id, root, name, knownActions, issues);
                if (d != null) out.put(id, d);
            } catch (IOException | InvalidConfigurationException e) {
                issues.add(new ValidationIssue(name, "(file)", "unreadable YAML: " + e.getMessage()));
            }
        }
        return out;
    }
}
