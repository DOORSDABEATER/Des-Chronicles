package net.dragonempire.chronicles.player;

import net.dragonempire.chronicles.objectives.QuestProgress;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** In-memory copy of one online player's state. Main thread only. */
public final class PlayerState {
    public final Map<String, QuestProgress> active = new HashMap<>();
    public final Map<String, Integer> completions = new HashMap<>();
    public final Map<String, Long> lastCompleted = new HashMap<>();
    public final Set<String> flags = new HashSet<>();
    public final Map<String, Integer> counters = new HashMap<>();

    public boolean completed(String questId) { return completions.getOrDefault(questId, 0) > 0; }
    public boolean tracking(String questId) { return flags.contains("track:" + questId); }
}
