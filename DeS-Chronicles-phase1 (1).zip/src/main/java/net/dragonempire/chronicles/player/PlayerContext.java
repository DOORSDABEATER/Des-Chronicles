package net.dragonempire.chronicles.player;

import net.dragonempire.chronicles.condition.ConditionContext;
import org.bukkit.Material;
import org.bukkit.entity.Player;

/** Live condition context for one online player. */
public final class PlayerContext implements ConditionContext {
    private final Player player;
    private final PlayerState state;
    private final net.dragonempire.chronicles.condition.WorldView view;

    public PlayerContext(Player player, PlayerState state, net.dragonempire.chronicles.condition.WorldView view) {
        this.player = player;
        this.state = state;
        this.view = view;
    }

    @Override public boolean eventActive(String eventId) { return view.eventActive(eventId); }
    @Override public boolean globalAtLeast(String key, long min) { return view.globalAtLeast(key, min); }
    @Override public int counter(String key) { return state.counters.getOrDefault(key, 0); }

    @Override public boolean hasCompletedQuest(String id) { return state.completed(id); }
    @Override public boolean hasActiveQuest(String id) { return state.active.containsKey(id); }

    @Override
    public boolean hasItem(String material, int amount) {
        Material m = Material.matchMaterial(material);
        return m != null && player.getInventory().contains(m, amount);
    }

    @Override public boolean hasPermission(String node) { return player.hasPermission(node); }
    @Override public int level() { return player.getLevel(); }
    @Override public boolean hasAchievement(String id) { return state.flags.contains("ach:" + id); }
    @Override public boolean hasVisited(String location) { return state.flags.contains("visited:" + location); }
    @Override public boolean hasDefeatedBoss(String bossId) { return state.flags.contains("boss:" + bossId); }
    @Override public boolean choseOption(String dialogueId, String choiceId) { return state.flags.contains("choice:" + dialogueId + ":" + choiceId); }
    @Override public boolean atQuestlineStage(String line, String stage) { return state.flags.contains("stage:" + line + ":" + stage); }
}
