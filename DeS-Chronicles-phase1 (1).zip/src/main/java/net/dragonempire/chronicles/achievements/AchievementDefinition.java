package net.dragonempire.chronicles.achievements;

/** hidden achievements are only listed once unlocked. */
public record AchievementDefinition(String id, String title, String description, boolean hidden) {}
