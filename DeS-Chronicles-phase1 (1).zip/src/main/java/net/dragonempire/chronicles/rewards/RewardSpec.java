package net.dragonempire.chronicles.rewards;

import java.util.Map;

/** key must be unique within the quest: it is the idempotency key for claims. */
public record RewardSpec(String key, String type, Map<String, Object> params, double chance) {}
