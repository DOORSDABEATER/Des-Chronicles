package net.dragonempire.chronicles.rewards;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.lang.reflect.Method;

/**
 * Optional Vault economy access through reflection, so Vault is never a compile or runtime requirement.
 * Works with any Vault-compatible economy provider. Methods return null on success or an error message.
 */
public final class EconomyBridge {
    private EconomyBridge() {}

    public static boolean available() {
        return provider() != null;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Object provider() {
        try {
            Class<?> economy = Class.forName("net.milkbowl.vault.economy.Economy");
            RegisteredServiceProvider<?> rsp = Bukkit.getServicesManager().getRegistration((Class) economy);
            return rsp == null ? null : rsp.getProvider();
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    public static String deposit(OfflinePlayer player, double amount) {
        Object eco = provider();
        if (eco == null) return "no Vault economy provider is installed";
        try {
            return check(eco.getClass().getMethod("depositPlayer", OfflinePlayer.class, double.class).invoke(eco, player, amount));
        } catch (ReflectiveOperationException | ClassCastException e) {
            return "Vault API mismatch: " + e;
        }
    }

    public static String withdraw(OfflinePlayer player, double amount) {
        Object eco = provider();
        if (eco == null) return "no Vault economy provider is installed";
        try {
            Method has = eco.getClass().getMethod("has", OfflinePlayer.class, double.class);
            if (!(boolean) has.invoke(eco, player, amount)) return "not enough money";
            return check(eco.getClass().getMethod("withdrawPlayer", OfflinePlayer.class, double.class).invoke(eco, player, amount));
        } catch (ReflectiveOperationException | ClassCastException e) {
            return "Vault API mismatch: " + e;
        }
    }

    private static String check(Object response) throws ReflectiveOperationException {
        boolean ok = (boolean) response.getClass().getMethod("transactionSuccess").invoke(response);
        if (ok) return null;
        Object msg = response.getClass().getField("errorMessage").get(response);
        return "economy refused the transaction: " + msg;
    }
}
