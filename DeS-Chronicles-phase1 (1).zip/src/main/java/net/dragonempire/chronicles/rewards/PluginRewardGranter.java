package net.dragonempire.chronicles.rewards;

import net.dragonempire.chronicles.quest.QuestService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/** Applies validated reward types: item, xp, command (console, {player} placeholder), flag. */
public final class PluginRewardGranter implements RewardGranter {
    private final JavaPlugin plugin;
    private final Supplier<QuestService> quests;

    public PluginRewardGranter(JavaPlugin plugin, Supplier<QuestService> quests) {
        this.plugin = plugin;
        this.quests = quests;
    }

    @Override
    public void grant(UUID id, RewardSpec r) {
        Player p = Bukkit.getPlayer(id);
        if (p == null) {
            plugin.getLogger().warning("Reward '" + r.key() + "' was claimed but player " + id + " is offline; it was not delivered.");
            return;
        }
        Map<String, Object> m = r.params();
        switch (r.type()) {
            case "item" -> {
                Material mat = Material.matchMaterial(String.valueOf(m.get("item")));
                int amount = m.get("amount") instanceof Number n ? n.intValue() : 1;
                if (mat == null) {
                    plugin.getLogger().severe("Reward '" + r.key() + "' has invalid material " + m.get("item"));
                    return;
                }
                for (ItemStack left : p.getInventory().addItem(new ItemStack(mat, amount)).values()) {
                    p.getWorld().dropItemNaturally(p.getLocation(), left);
                }
            }
            case "xp" -> p.giveExp(((Number) m.get("amount")).intValue());
            case "command" -> {
                String cmd = String.valueOf(m.get("command")).replace("{player}", p.getName());
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            }
            case "flag" -> quests.get().addFlag(p, String.valueOf(m.get("flag")));
            case "counter" -> quests.get().addCounter(p, String.valueOf(m.get("key")), ((Number) m.get("amount")).intValue());
            case "global" -> quests.get().addGlobal(String.valueOf(m.get("key")), ((Number) m.get("amount")).longValue());
            case "money" -> {
                String err = EconomyBridge.deposit(p, ((Number) m.get("amount")).doubleValue());
                if (err != null) plugin.getLogger().severe("Money reward '" + r.key() + "' for " + p.getName() + " failed: " + err);
            }
            case "achievement" -> {
                String aid = String.valueOf(m.get("id"));
                var def = quests.get().content().achievements().get(aid);
                quests.get().addFlag(p, "ach:" + aid);
                p.sendMessage(net.kyori.adventure.text.Component.text("Achievement unlocked: ", net.kyori.adventure.text.format.NamedTextColor.GOLD)
                        .append(net.kyori.adventure.text.Component.text(def == null ? aid : def.title(), net.kyori.adventure.text.format.NamedTextColor.WHITE)));
            }
            default -> plugin.getLogger().severe("Reward '" + r.key() + "' has unhandled type " + r.type());
        }
    }
}
