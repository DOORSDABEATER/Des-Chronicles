package net.dragonempire.chronicles.rewards;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

public final class RewardParser {
    private RewardParser() {}

    @SuppressWarnings("unchecked")
    public static List<RewardSpec> parse(Object raw, String file, String path, Set<String> knownTypes,
                                         List<ValidationIssue> issues) {
        List<RewardSpec> out = new ArrayList<>();
        if (raw == null) return out;
        if (!(raw instanceof List<?> l)) {
            issues.add(new ValidationIssue(file, path, "must be a list"));
            return out;
        }
        Set<String> keys = new HashSet<>();
        for (int i = 0; i < l.size(); i++) {
            String p = path + "[" + i + "]";
            if (!(l.get(i) instanceof Map<?, ?> m) || !(m.get("type") instanceof String type)) {
                issues.add(new ValidationIssue(file, p + ".type", "required"));
                continue;
            }
            String t = type.toLowerCase(Locale.ROOT);
            if (!knownTypes.contains(t)) {
                issues.add(new ValidationIssue(file, p + ".type", "unknown reward type '" + type + "'"));
                continue;
            }
            String key = m.get("key") instanceof String k ? k : "r" + i;
            if (!keys.add(key)) {
                issues.add(new ValidationIssue(file, p + ".key", "duplicate reward key '" + key + "'"));
                continue;
            }
            double chance = m.get("chance") instanceof Number n ? n.doubleValue() : 1.0;
            if (chance <= 0 || chance > 1) {
                issues.add(new ValidationIssue(file, p + ".chance", "must be in (0, 1]"));
                continue;
            }
            out.add(new RewardSpec(key, t, (Map<String, Object>) m, chance));
        }
        return out;
    }
}
