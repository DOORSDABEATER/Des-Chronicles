package net.dragonempire.chronicles.rewards;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.random.RandomGenerator;

/**
 * Rolls chances, claims each reward atomically in storage, then grants it on `mainThread`.
 * Claim-before-grant means a crash between the two loses a reward but can never duplicate one.
 * Failures are propagated through the returned future, never swallowed.
 */
public final class RewardEngine {
    private final ClaimStore store;
    private final RewardGranter granter;
    private final Executor mainThread;
    private final RandomGenerator random;

    public RewardEngine(ClaimStore store, RewardGranter granter, Executor mainThread, RandomGenerator random) {
        this.store = store;
        this.granter = granter;
        this.mainThread = mainThread;
        this.random = random;
    }

    /** Completes with the number of rewards actually granted. */
    public CompletableFuture<Integer> award(UUID player, String questId, List<RewardSpec> rewards) {
        List<RewardSpec> rolled = new ArrayList<>();
        for (RewardSpec r : rewards) if (r.chance() >= 1.0 || random.nextDouble() < r.chance()) rolled.add(r);

        CompletableFuture<Integer> chain = CompletableFuture.completedFuture(0);
        for (RewardSpec r : rolled) {
            chain = chain.thenCompose(n -> store.claimReward(player, questId, r.key()).thenApplyAsync(claimed -> {
                if (!claimed) return n;
                granter.grant(player, r);
                return n + 1;
            }, mainThread));
        }
        return chain;
    }
}
