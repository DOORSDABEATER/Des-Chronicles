package net.dragonempire.chronicles.npc;

import net.dragonempire.chronicles.condition.Condition;
import net.dragonempire.chronicles.condition.ConditionParser;
import net.dragonempire.chronicles.condition.WorldView;
import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.content.Yamls;
import net.dragonempire.chronicles.dialogue.DialogueManager;
import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.objectives.ObjectiveEvent;
import net.dragonempire.chronicles.player.PlayerContext;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestService;
import net.dragonempire.chronicles.validation.ValidationIssue;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Entity-based NPCs with optional behaviour: look at nearby players, patrol between waypoints, and per-player
 * visibility driven by a condition. Entities are non-persistent and respawned from npc/*.yml on enable and chunk load.
 * "external" NPCs (for example Citizens NPCs with a skin) are driven through "/desquests npc talk <id> <player>".
 * Authentic player skins are only possible through such an external provider.
 */
public final class NpcManager {
    private static final Pattern ID = Pattern.compile("[a-z0-9_]{2,32}");

    private static final class PatrolState {
        int index;
        int pauseTicks;
    }

    private final JavaPlugin plugin;
    private final Path dir;
    private final QuestService quests;
    private final DialogueManager dialogues;
    private final ContentManager content;
    private final WorldView view;
    private final NamespacedKey key;
    private final Map<String, NpcDefinition> defs = new LinkedHashMap<>();
    private final Map<String, UUID> spawned = new HashMap<>();
    private final Map<String, PatrolState> patrols = new HashMap<>();
    private final Map<UUID, Long> lastInteract = new HashMap<>();
    private ShopMenu shops;
    private BukkitTask behaviorTask;
    private int behaviorInterval = 5;

    public NpcManager(JavaPlugin plugin, QuestService quests, DialogueManager dialogues, ContentManager content, WorldView view) {
        this.plugin = plugin;
        this.dir = plugin.getDataFolder().toPath().resolve("npc");
        this.quests = quests;
        this.dialogues = dialogues;
        this.content = content;
        this.view = view;
        this.key = new NamespacedKey(plugin, "npc_id");
    }

    public Collection<NpcDefinition> all() { return defs.values(); }
    public NpcDefinition get(String id) { return defs.get(id); }
    public NamespacedKey key() { return key; }
    public void setShops(ShopMenu shops) { this.shops = shops; }
    public void setBehaviorInterval(int ticks) { this.behaviorInterval = Math.max(2, ticks); }

    // ---- loading ----
    public void reload(List<ValidationIssue> issues) {
        despawnAll();
        defs.clear();
        patrols.clear();
        if (Files.isDirectory(dir)) {
            List<Path> files = new ArrayList<>();
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.yml")) {
                ds.forEach(files::add);
            } catch (IOException e) {
                issues.add(new ValidationIssue("npc/", "(directory)", "cannot list: " + e.getMessage()));
            }
            Collections.sort(files);
            for (Path f : files) {
                String name = f.getFileName().toString();
                String id = name.substring(0, name.length() - 4);
                try {
                    NpcDefinition d = parse(id, Yamls.load(f), name, issues);
                    if (d != null) defs.put(id, d);
                } catch (IOException | InvalidConfigurationException e) {
                    issues.add(new ValidationIssue(name, "(file)", "unreadable YAML: " + e.getMessage()));
                }
            }
        }
        for (NpcDefinition d : defs.values()) {
            if (!d.dialogue().isBlank() && !content.dialogues().containsKey(d.dialogue())) {
                issues.add(new ValidationIssue(d.id() + ".yml", "dialogue", "unknown dialogue '" + d.dialogue() + "'"));
            }
            if (!d.external()) ensureSpawnedIfLoaded(d);
        }
        startBehavior();
    }

    private NpcDefinition parse(String id, Map<String, Object> root, String file, List<ValidationIssue> issues) {
        int before = issues.size();
        if (!ID.matcher(id).matches()) issues.add(new ValidationIssue(file, "(name)", "id must match [a-z0-9_]{2,32}"));
        boolean external = "external".equalsIgnoreCase(String.valueOf(root.getOrDefault("provider", "entity")));
        String entity = root.get("entity") instanceof String s ? s.toUpperCase(Locale.ROOT) : "VILLAGER";
        if (!external) {
            try {
                EntityType t = EntityType.valueOf(entity);
                if (!t.isSpawnable() || !t.isAlive()) issues.add(new ValidationIssue(file, "entity", entity + " cannot be used for an NPC"));
            } catch (IllegalArgumentException e) {
                issues.add(new ValidationIssue(file, "entity", "unknown entity type '" + entity + "'"));
            }
        }
        String world = "";
        double x = 0, y = 0, z = 0;
        float yaw = 0, pitch = 0;
        if (root.get("location") instanceof Map<?, ?> l && l.get("world") instanceof String w && l.get("x") instanceof Number nx
                && l.get("y") instanceof Number ny && l.get("z") instanceof Number nz) {
            world = w;
            x = nx.doubleValue();
            y = ny.doubleValue();
            z = nz.doubleValue();
            yaw = l.get("yaw") instanceof Number n ? n.floatValue() : 0f;
            pitch = l.get("pitch") instanceof Number n ? n.floatValue() : 0f;
        } else if (!external) {
            issues.add(new ValidationIssue(file, "location", "needs world, x, y, z"));
        }
        double dist = root.get("interact_distance") instanceof Number n ? n.doubleValue() : 5.0;
        if (dist <= 0 || dist > 32) issues.add(new ValidationIssue(file, "interact_distance", "must be in (0, 32]"));

        String behavior = String.valueOf(root.getOrDefault("behavior", "stationary")).toLowerCase(Locale.ROOT);
        List<double[]> patrol = new ArrayList<>();
        double speed = root.get("patrol_speed") instanceof Number n ? n.doubleValue() : 1.5;
        if (behavior.equals("patrol")) {
            if (root.get("patrol") instanceof List<?> pl) {
                for (int i = 0; i < pl.size(); i++) {
                    if (pl.get(i) instanceof Map<?, ?> pm && pm.get("x") instanceof Number px && pm.get("y") instanceof Number py && pm.get("z") instanceof Number pz) {
                        patrol.add(new double[]{px.doubleValue(), py.doubleValue(), pz.doubleValue()});
                    } else {
                        issues.add(new ValidationIssue(file, "patrol[" + i + "]", "needs x, y, z"));
                    }
                }
            }
            if (patrol.size() < 2) issues.add(new ValidationIssue(file, "patrol", "patrol behavior needs at least 2 waypoints"));
            if (speed <= 0 || speed > 10) issues.add(new ValidationIssue(file, "patrol_speed", "must be in (0, 10] blocks per second"));
        } else if (!behavior.equals("stationary")) {
            issues.add(new ValidationIssue(file, "behavior", "must be stationary or patrol"));
        }
        List<ShopItem> shop = ShopParser.parse(root.get("shop"), file, "shop", issues);
        for (int i = 0; i < shop.size(); i++) {
            if (org.bukkit.Material.matchMaterial(shop.get(i).item()) == null) {
                issues.add(new ValidationIssue(file, "shop[" + i + "].item", "'" + shop.get(i).item() + "' is not a valid material"));
            }
        }
        boolean conditional = root.containsKey("visible_if");
        Condition visible = ConditionParser.parse(root.get("visible_if"), file, "visible_if", issues);
        if (issues.size() > before) return null;
        return new NpcDefinition(id, root.get("name") instanceof String s ? s : id, entity, world, x, y, z, yaw, pitch,
                root.get("dialogue") instanceof String s ? s : "", dist, root.get("permission") instanceof String s ? s : "",
                external, Boolean.TRUE.equals(root.get("look_at_players")), speed, List.copyOf(patrol), conditional, visible, List.copyOf(shop));
    }

    // ---- spawning ----
    public void ensureSpawnedIfLoaded(NpcDefinition d) {
        World w = Bukkit.getWorld(d.world());
        if (w == null) {
            plugin.getLogger().warning("NPC '" + d.id() + "': world '" + d.world() + "' is not loaded; it will not spawn.");
            return;
        }
        if (w.isChunkLoaded(((int) Math.floor(d.x())) >> 4, ((int) Math.floor(d.z())) >> 4)) ensureSpawned(d);
    }

    public void ensureSpawned(NpcDefinition d) {
        if (d.external()) return;
        Entity existing = entity(d.id());
        if (existing != null) return;
        World w = Bukkit.getWorld(d.world());
        if (w == null) return;
        Entity e = w.spawnEntity(new Location(w, d.x(), d.y(), d.z(), d.yaw(), d.pitch()), EntityType.valueOf(d.entity()));
        e.setPersistent(false);
        e.setInvulnerable(true);
        e.setSilent(true);
        e.customName(MiniMessage.miniMessage().deserialize(d.name()));
        e.setCustomNameVisible(true);
        e.getPersistentDataContainer().set(key, PersistentDataType.STRING, d.id());
        if (e instanceof LivingEntity le) {
            le.setAI(false);
            le.setCollidable(false);
            le.setRemoveWhenFarAway(false);
        }
        spawned.put(d.id(), e.getUniqueId());
        if (d.conditional()) for (Player p : Bukkit.getOnlinePlayers()) refreshVisibility(p);
    }

    private Entity entity(String id) {
        UUID u = spawned.get(id);
        if (u == null) return null;
        Entity e = Bukkit.getEntity(u);
        return e != null && e.isValid() ? e : null;
    }

    public void despawn(String id) {
        UUID u = spawned.remove(id);
        if (u == null) return;
        Entity e = Bukkit.getEntity(u);
        if (e != null) e.remove();
    }

    public void despawnAll() {
        if (behaviorTask != null) behaviorTask.cancel();
        behaviorTask = null;
        for (String id : new ArrayList<>(spawned.keySet())) despawn(id);
    }

    public void onChunkLoad(String world, int cx, int cz) {
        for (NpcDefinition d : defs.values()) {
            if (!d.external() && d.world().equals(world) && (((int) Math.floor(d.x())) >> 4) == cx && (((int) Math.floor(d.z())) >> 4) == cz) {
                plugin.getServer().getScheduler().runTask(plugin, () -> ensureSpawned(d));
            }
        }
    }

    // ---- per-player visibility ----
    /** Hides or shows conditional NPCs for this player according to their visible_if condition. */
    public void refreshVisibility(Player p) {
        PlayerState s = quests.state(p);
        if (s == null) return;
        PlayerContext ctx = new PlayerContext(p, s, view);
        for (NpcDefinition d : defs.values()) {
            if (!d.conditional() || d.external()) continue;
            Entity e = entity(d.id());
            if (e == null) continue;
            if (d.visibleIf().test(ctx)) p.showEntity(plugin, e);
            else p.hideEntity(plugin, e);
        }
    }

    // ---- behaviour: look at players, patrol ----
    private void startBehavior() {
        if (behaviorTask != null) behaviorTask.cancel();
        behaviorTask = null;
        if (defs.values().stream().noneMatch(NpcDefinition::hasBehavior)) return;
        behaviorTask = plugin.getServer().getScheduler().runTaskTimer(plugin, this::behaviorTick, behaviorInterval, behaviorInterval);
    }

    private void behaviorTick() {
        for (NpcDefinition d : defs.values()) {
            if (!d.hasBehavior()) continue;
            Entity e = entity(d.id());
            if (e == null) continue;
            Player nearest = null;
            double nearestSq = Double.MAX_VALUE;
            for (Player p : e.getWorld().getPlayers()) {
                double sq = p.getLocation().distanceSquared(e.getLocation());
                if (sq < nearestSq) {
                    nearestSq = sq;
                    nearest = p;
                }
            }
            boolean talking = nearest != null && nearestSq < 9; // pause patrols when someone is right next to the NPC
            if (!d.patrol().isEmpty() && !talking) patrolStep(d, e);
            if (d.lookAtPlayers() && nearest != null && nearestSq <= 36) face(e, nearest.getLocation());
        }
    }

    private void patrolStep(NpcDefinition d, Entity e) {
        PatrolState st = patrols.computeIfAbsent(d.id(), k -> new PatrolState());
        if (st.pauseTicks > 0) {
            st.pauseTicks -= behaviorInterval;
            return;
        }
        double[] target = d.patrol().get(st.index % d.patrol().size());
        Location cur = e.getLocation();
        double dx = target[0] - cur.getX(), dy = target[1] - cur.getY(), dz = target[2] - cur.getZ();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double step = d.patrolSpeed() * behaviorInterval / 20.0;
        if (dist <= step) {
            Location arrive = cur.clone();
            arrive.setX(target[0]);
            arrive.setY(target[1]);
            arrive.setZ(target[2]);
            e.teleport(arrive);
            st.index = (st.index + 1) % d.patrol().size();
            st.pauseTicks = 40;
            return;
        }
        double r = step / dist;
        Location next = cur.clone().add(dx * r, dy * r, dz * r);
        next.setYaw((float) Math.toDegrees(Math.atan2(-dx, dz)));
        next.setPitch(0f);
        e.teleport(next);
    }

    private static void face(Entity e, Location target) {
        double dx = target.getX() - e.getLocation().getX();
        double dz = target.getZ() - e.getLocation().getZ();
        e.setRotation((float) Math.toDegrees(Math.atan2(-dx, dz)), 0f);
    }

    // ---- interaction ----
    public void interact(Player p, String npcId, Entity entity) {
        NpcDefinition d = defs.get(npcId);
        if (d != null) run(p, d, entity);
    }

    /** Entry point for external providers (e.g. Citizens running "/desquests npc talk <id> <player>"). */
    public String talk(Player p, String npcId) {
        NpcDefinition d = defs.get(npcId);
        if (d == null) return "Unknown NPC: " + npcId;
        run(p, d, null);
        return null;
    }

    private void run(Player p, NpcDefinition d, Entity entity) {
        long now = System.currentTimeMillis();
        Long last = lastInteract.get(p.getUniqueId());
        if (last != null && now - last < 500) return;
        lastInteract.put(p.getUniqueId(), now);

        PlayerState s = quests.state(p);
        if (d.conditional() && (s == null || !d.visibleIf().test(new PlayerContext(p, s, view)))) return; // hidden from this player
        if (!d.permission().isBlank() && !p.hasPermission(d.permission())) {
            p.sendMessage(Messages.get("npc.ignore"));
            return;
        }
        if (entity != null) {
            double max = d.interactDistance();
            if (!p.getWorld().equals(entity.getWorld()) || p.getLocation().distanceSquared(entity.getLocation()) > max * max) {
                p.sendMessage(Messages.get("npc.toofar"));
                return;
            }
            face(entity, p.getLocation());
        }
        quests.handle(p, new ObjectiveEvent("TALK_NPC", d.id()));
        quests.handle(p, new ObjectiveEvent("INTERACT_NPC", d.id()));
        if (!d.dialogue().isBlank()) dialogues.start(p, d.dialogue());
        else if (!d.shop().isEmpty() && shops != null) shops.open(p, d.id());
    }

    public void forget(UUID player) { lastInteract.remove(player); }

    // ---- admin editing ----
    /** Returns null on success, otherwise an error message. */
    public String create(String id, Location at, String displayName) {
        if (!ID.matcher(id).matches()) return "NPC ids must match [a-z0-9_]{2,32}.";
        if (defs.containsKey(id)) return "An NPC with that id already exists.";
        NpcDefinition d = new NpcDefinition(id, displayName, "VILLAGER", at.getWorld().getName(), at.getX(), at.getY(), at.getZ(),
                at.getYaw(), at.getPitch(), "", 5.0, "", false, false, 1.5, List.of(), false, c -> true, List.of());
        String err = save(d);
        if (err != null) return err;
        defs.put(id, d);
        ensureSpawned(d);
        return null;
    }

    public String move(String id, Location at) {
        NpcDefinition d = defs.get(id);
        if (d == null) return "Unknown NPC: " + id;
        NpcDefinition n = d.withLocation(at.getWorld().getName(), at.getX(), at.getY(), at.getZ(), at.getYaw(), at.getPitch());
        String err = save(n);
        if (err != null) return err;
        despawn(id);
        defs.put(id, n);
        ensureSpawned(n);
        return null;
    }

    public String setDialogue(String id, String dialogueId) {
        NpcDefinition d = defs.get(id);
        if (d == null) return "Unknown NPC: " + id;
        if (!content.dialogues().containsKey(dialogueId)) return "Unknown dialogue: " + dialogueId;
        NpcDefinition n = d.withDialogue(dialogueId);
        String err = save(n);
        if (err != null) return err;
        defs.put(id, n);
        return null;
    }

    public String delete(String id) {
        if (!defs.containsKey(id)) return "Unknown NPC: " + id;
        try {
            Files.deleteIfExists(dir.resolve(id + ".yml"));
        } catch (IOException e) {
            return "Could not delete file: " + e.getMessage();
        }
        despawn(id);
        defs.remove(id);
        return null;
    }

    /** Updates only the keys this plugin edits, so hand-written settings (visible_if, patrol, ...) survive. */
    private String save(NpcDefinition d) {
        Path file = dir.resolve(d.id() + ".yml");
        YamlConfiguration y = Files.exists(file) ? YamlConfiguration.loadConfiguration(file.toFile()) : new YamlConfiguration();
        y.set("name", d.name());
        if (!d.external()) {
            y.set("entity", d.entity());
            y.set("location.world", d.world());
            y.set("location.x", d.x());
            y.set("location.y", d.y());
            y.set("location.z", d.z());
            y.set("location.yaw", d.yaw());
            y.set("location.pitch", d.pitch());
        }
        y.set("dialogue", d.dialogue());
        y.set("interact_distance", d.interactDistance());
        y.set("permission", d.permission());
        try {
            Files.createDirectories(dir);
            y.save(file.toFile());
            return null;
        } catch (IOException e) {
            return "Could not save NPC file: " + e.getMessage();
        }
    }
}
