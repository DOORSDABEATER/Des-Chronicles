package net.dragonempire.chronicles.npc;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class ShopParser {
    private ShopParser() {}

    public static List<ShopItem> parse(Object raw, String file, String path, List<ValidationIssue> issues) {
        List<ShopItem> out = new ArrayList<>();
        if (raw == null) return out;
        if (!(raw instanceof List<?> l)) {
            issues.add(new ValidationIssue(file, path, "must be a list"));
            return out;
        }
        if (l.size() > 45) issues.add(new ValidationIssue(file, path, "at most 45 offers"));
        for (int i = 0; i < l.size(); i++) {
            String p = path + "[" + i + "]";
            if (!(l.get(i) instanceof Map<?, ?> m) || !(m.get("item") instanceof String item) || item.isBlank()) {
                issues.add(new ValidationIssue(file, p + ".item", "required"));
                continue;
            }
            int amount = m.get("amount") instanceof Number n ? n.intValue() : 1;
            if (amount < 1 || amount > 64) {
                issues.add(new ValidationIssue(file, p + ".amount", "must be 1-64"));
                continue;
            }
            if (!(m.get("price") instanceof Number price) || price.doubleValue() <= 0) {
                issues.add(new ValidationIssue(file, p + ".price", "required, > 0"));
                continue;
            }
            out.add(new ShopItem(item, amount, price.doubleValue()));
        }
        return out;
    }
}
