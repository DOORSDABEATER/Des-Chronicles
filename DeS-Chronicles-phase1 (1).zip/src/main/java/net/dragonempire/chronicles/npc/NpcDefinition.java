package net.dragonempire.chronicles.npc;

import net.dragonempire.chronicles.condition.Condition;

import java.util.List;

/**
 * external=true means no entity is spawned by this plugin (for example a Citizens NPC that calls
 * "/desquests npc talk"). patrol entries are {x, y, z}. visibleIf is only consulted when conditional is true.
 */
public record NpcDefinition(String id, String name, String entity, String world, double x, double y, double z,
                            float yaw, float pitch, String dialogue, double interactDistance, String permission,
                            boolean external, boolean lookAtPlayers, double patrolSpeed, List<double[]> patrol,
                            boolean conditional, Condition visibleIf, List<ShopItem> shop) {

    public NpcDefinition withLocation(String world, double x, double y, double z, float yaw, float pitch) {
        return new NpcDefinition(id, name, entity, world, x, y, z, yaw, pitch, dialogue, interactDistance, permission,
                external, lookAtPlayers, patrolSpeed, patrol, conditional, visibleIf, shop);
    }

    public NpcDefinition withDialogue(String dialogue) {
        return new NpcDefinition(id, name, entity, world, x, y, z, yaw, pitch, dialogue, interactDistance, permission,
                external, lookAtPlayers, patrolSpeed, patrol, conditional, visibleIf, shop);
    }

    public boolean hasBehavior() { return !external && (lookAtPlayers || !patrol.isEmpty()); }
}
