package net.dragonempire.chronicles;

import net.dragonempire.chronicles.actions.ActionExecutor;
import net.dragonempire.chronicles.commands.AdminCommand;
import net.dragonempire.chronicles.commands.QuestsCommand;
import net.dragonempire.chronicles.bosses.BossManager;
import net.dragonempire.chronicles.escorts.EscortManager;
import net.dragonempire.chronicles.listeners.EscortListener;
import net.dragonempire.chronicles.listeners.ShopListener;
import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.npc.ShopMenu;
import net.dragonempire.chronicles.studio.QuestEditor;
import net.dragonempire.chronicles.community.CommunityManager;
import net.dragonempire.chronicles.condition.WorldView;
import net.dragonempire.chronicles.hud.MarkerService;
import net.dragonempire.chronicles.hud.SidebarService;
import net.dragonempire.chronicles.listeners.InteractionListener;
import net.dragonempire.chronicles.listeners.StudioListener;
import net.dragonempire.chronicles.studio.StudioMenu;
import net.dragonempire.chronicles.studio.StudioService;
import org.bukkit.scheduler.BukkitTask;
import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.cutscenes.CutsceneManager;
import net.dragonempire.chronicles.events.EventManager;
import net.dragonempire.chronicles.listeners.BossListener;
import net.dragonempire.chronicles.listeners.CutsceneListener;
import net.dragonempire.chronicles.parties.PartyManager;
import net.dragonempire.chronicles.questline.QuestlineService;
import net.dragonempire.chronicles.dialogue.DialogueManager;
import net.dragonempire.chronicles.journal.QuestJournal;
import net.dragonempire.chronicles.listeners.JournalListener;
import net.dragonempire.chronicles.listeners.NpcListener;
import net.dragonempire.chronicles.listeners.ObjectiveListener;
import net.dragonempire.chronicles.listeners.PlayerListener;
import net.dragonempire.chronicles.npc.NpcManager;
import net.dragonempire.chronicles.quest.QuestService;
import net.dragonempire.chronicles.storage.Database;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ChroniclesPlugin extends JavaPlugin {
    private Database database;
    private ContentManager content;
    private QuestService quests;
    private NpcManager npcs;
    private EventManager events;
    private CutsceneManager cutscenes;
    private BossManager bosses;
    private CommunityManager community;
    private StudioService studio;
    private StudioMenu studioMenu;
    private BukkitTask surviveTask;
    private EscortManager escorts;
    private QuestEditor questEditor;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        copyDefaultContent();
        Messages.init(this);

        database = new Database(getDataFolder().toPath().resolve(getConfig().getString("database.file", "database/chronicles.db")));
        database.open().whenComplete((v, err) -> {
            if (err == null) {
                getLogger().info("Database ready.");
                return;
            }
            getLogger().severe("Database failed to open; disabling plugin: " + err);
            if (isEnabled()) getServer().getScheduler().runTask(this, () -> getServer().getPluginManager().disablePlugin(this));
        });

        content = new ContentManager();
        quests = new QuestService(this, content, database);
        ActionExecutor actions = new ActionExecutor(quests);
        events = new EventManager(this, content, database);
        community = new CommunityManager(this, content, database);
        WorldView view = new WorldView() {
            @Override public boolean eventActive(String eventId) { return events.isActive(eventId); }
            @Override public boolean globalAtLeast(String key, long min) { return community.globalAtLeast(key, min); }
        };
        DialogueManager dialogues = new DialogueManager(this, content, quests, actions, view,
                getConfig().getBoolean("dialogue.animate", true), getConfig().getInt("dialogue.chars_per_tick", 2),
                getConfig().getString("dialogue.blip_sound", "minecraft:block.note_block.hat"));
        npcs = new NpcManager(this, quests, dialogues, content, view);
        npcs.setBehaviorInterval(getConfig().getInt("npc.behavior_interval_ticks", 5));
        MarkerService markers = new MarkerService(content, quests);
        SidebarService sidebar = new SidebarService(content, quests);
        escorts = new EscortManager(this, content, quests);
        ShopMenu shops = new ShopMenu(npcs);
        npcs.setShops(shops);
        actions.setEscorts(escorts);
        actions.setShops(shops);
        questEditor = new QuestEditor(this);
        studio = new StudioService(this);
        studioMenu = new StudioMenu(this, studio);
        quests.setCommunity(community);
        QuestJournal journal = new QuestJournal(content, quests);
        PartyManager parties = new PartyManager(Math.max(2, getConfig().getInt("party.max_size", 4)));
        QuestlineService questlines = new QuestlineService(content, quests);
        bosses = new BossManager(this, content, quests, actions);
        cutscenes = new CutsceneManager(this, content, quests);
        cutscenes.setDialogues(dialogues);
        cutscenes.setBosses(bosses);
        actions.setCutscenes(cutscenes);
        actions.setBosses(bosses);

        quests.setActions(actions);
        quests.setEvents(events);
        quests.setQuestlines(questlines);
        quests.setParties(parties);
        quests.setOnLoaded(p -> {
            cutscenes.restoreIfNeeded(p, quests.state(p));
            questlines.onQuestCompleted(p); // catch up chapter flags/rewards after content changes
            npcs.refreshVisibility(p);
            markers.update(p, true);
            sidebar.update(p);
        });
        quests.setOnChanged(p -> {
            npcs.refreshVisibility(p);
            markers.update(p, true);
            sidebar.update(p);
        });
        try {
            quests.setZone(java.time.ZoneId.of(getConfig().getString("reset.timezone", "UTC")));
        } catch (java.time.DateTimeException e) {
            getLogger().severe("Invalid reset.timezone in config.yml, using UTC: " + e.getMessage());
        }

        reloadContent();

        var pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerListener(quests, dialogues, npcs, markers, sidebar), this);
        pm.registerEvents(new ObjectiveListener(quests, content, markers), this);
        pm.registerEvents(new InteractionListener(content, quests), this);
        pm.registerEvents(new StudioListener(studioMenu), this);
        pm.registerEvents(new EscortListener(escorts), this);
        pm.registerEvents(new ShopListener(shops), this);
        pm.registerEvents(new NpcListener(npcs), this);
        pm.registerEvents(new JournalListener(journal), this);
        pm.registerEvents(new CutsceneListener(cutscenes), this);
        pm.registerEvents(new BossListener(bosses), this);
        events.start();
        community.start();
        int surviveSeconds = Math.max(1, getConfig().getInt("survive.interval_seconds", 5));
        surviveTask = getServer().getScheduler().runTaskTimer(this, () -> {
            for (Player p : getServer().getOnlinePlayers()) {
                if (quests.wantsEvent(p, "SURVIVE")) quests.handle(p, new net.dragonempire.chronicles.objectives.ObjectiveEvent("SURVIVE", "any", surviveSeconds));
            }
        }, surviveSeconds * 20L, surviveSeconds * 20L);

        var admin = getCommand("desquests");
        if (admin != null) {
            AdminCommand h = new AdminCommand(this);
            admin.setExecutor(h);
            admin.setTabCompleter(h);
        }
        var player = getCommand("quests");
        if (player != null) {
            QuestsCommand h = new QuestsCommand(this, database, quests, content, journal, dialogues, parties, questlines, cutscenes, community, markers, sidebar);
            player.setExecutor(h);
            player.setTabCompleter(h);
        }

        // Plugin (re)loaded while players are online.
        for (Player p : getServer().getOnlinePlayers()) quests.loadPlayer(p);
    }

    @Override
    public void onDisable() {
        if (surviveTask != null) surviveTask.cancel();
        if (escorts != null) escorts.shutdown();
        if (events != null) events.shutdown();
        if (cutscenes != null) cutscenes.cleanupAll();
        if (bosses != null) bosses.despawnAll();
        if (npcs != null) npcs.despawnAll();
        if (database != null) database.close();
    }

    /** Re-reads quests, dialogues, locations and NPCs. Player progress is untouched. */
    public List<ValidationIssue> reloadContent() {
        List<ValidationIssue> issues = new ArrayList<>(content.reload(getDataFolder().toPath()));
        npcs.reload(issues);
        boolean usesMoney = content.quests().values().stream().anyMatch(q -> q.rewards().stream().anyMatch(r -> r.type().equals("money")));
        if (usesMoney && !net.dragonempire.chronicles.rewards.EconomyBridge.available()) {
            getLogger().warning("Quests use money rewards but no Vault economy provider is registered; those rewards will fail.");
        }
        Messages.init(this);
        for (ValidationIssue i : issues) getLogger().warning("Content issue: " + i);
        for (Player online : getServer().getOnlinePlayers()) npcs.refreshVisibility(online);
        getLogger().info("Loaded " + content.quests().size() + " quest(s), " + content.questlines().size() + " questline(s), "
                + content.dialogues().size() + " dialogue(s), " + content.cutscenes().size() + " cutscene(s), "
                + content.bosses().size() + " boss(es), " + content.events().size() + " event(s), "
                + npcs.all().size() + " NPC(s) with " + issues.size() + " issue(s).");
        return issues;
    }

    /** Copies bundled sample files listed in defaults.txt, never overwriting anything that exists. */
    private void copyDefaultContent() {
        // Marker file: once samples were installed, deleting them (to disable the demo) must stick.
        Path marker = getDataFolder().toPath().resolve(".defaults-installed");
        if (Files.exists(marker)) return;
        try (InputStream in = getResource("defaults.txt")) {
            if (in == null) return;
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) continue;
                    Path target = getDataFolder().toPath().resolve(line);
                    if (!Files.exists(target)) saveResource(line, false);
                }
            }
            Files.createDirectories(marker.getParent());
            Files.writeString(marker, "Delete the sample files you do not want; they will not be recreated.\n");
        } catch (IOException e) {
            getLogger().severe("Could not copy default content: " + e);
        }
    }

    public ContentManager content() { return content; }
    public QuestService quests() { return quests; }
    public NpcManager npcs() { return npcs; }
    public EventManager events() { return events; }
    public CutsceneManager cutscenes() { return cutscenes; }
    public BossManager bosses() { return bosses; }
    public CommunityManager community() { return community; }
    public StudioService studio() { return studio; }
    public QuestEditor questEditor() { return questEditor; }
    public EscortManager escorts() { return escorts; }
    public StudioMenu studioMenu() { return studioMenu; }
    public Database database() { return database; }
}
