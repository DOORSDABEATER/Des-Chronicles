package net.dragonempire.chronicles.commands;

import net.dragonempire.chronicles.community.CommunityManager;
import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.hud.MarkerService;
import net.dragonempire.chronicles.hud.SidebarService;
import net.dragonempire.chronicles.storage.Database;
import org.bukkit.plugin.java.JavaPlugin;
import net.dragonempire.chronicles.cutscenes.CutsceneManager;
import net.dragonempire.chronicles.parties.PartyManager;
import net.dragonempire.chronicles.questline.QuestlineService;
import org.bukkit.Bukkit;
import net.dragonempire.chronicles.dialogue.DialogueManager;
import net.dragonempire.chronicles.journal.QuestJournal;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestDefinition;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Player command. "dialogue" is used by the clickable chat lines and is not meant to be typed. */
public final class QuestsCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUB = List.of("active", "available", "completed", "journal", "track", "untrack", "abandon", "questlines", "achievements", "reputation", "community", "recommend", "top", "markers", "sidebar", "party", "skip", "help");

    private final QuestService quests;
    private final ContentManager content;
    private final QuestJournal journal;
    private final DialogueManager dialogues;
    private final PartyManager parties;
    private final QuestlineService questlines;
    private final CutsceneManager cutscenes;
    private final JavaPlugin plugin;
    private final Database db;
    private final CommunityManager community;
    private final MarkerService markers;
    private final SidebarService sidebar;

    public QuestsCommand(JavaPlugin plugin, Database db, QuestService quests, ContentManager content, QuestJournal journal,
                         DialogueManager dialogues, PartyManager parties, QuestlineService questlines, CutsceneManager cutscenes,
                         CommunityManager community, MarkerService markers, SidebarService sidebar) {
        this.plugin = plugin;
        this.db = db;
        this.community = community;
        this.markers = markers;
        this.sidebar = sidebar;
        this.quests = quests;
        this.content = content;
        this.journal = journal;
        this.dialogues = dialogues;
        this.parties = parties;
        this.questlines = questlines;
        this.cutscenes = cutscenes;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }
        if (!p.hasPermission("desquests.use")) {
            p.sendMessage(Component.text("You do not have permission.", NamedTextColor.RED));
            return true;
        }
        String sub = args.length == 0 ? "journal" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "journal" -> journal.open(p, QuestJournal.Tab.ACTIVE, 0);
            case "active" -> journal.open(p, QuestJournal.Tab.ACTIVE, 0);
            case "available" -> journal.open(p, QuestJournal.Tab.AVAILABLE, 0);
            case "completed" -> journal.open(p, QuestJournal.Tab.COMPLETED, 0);
            case "track", "untrack" -> {
                if (args.length < 2) {
                    p.sendMessage(Component.text("Usage: /" + label + " " + sub + " <quest>", NamedTextColor.RED));
                    return true;
                }
                boolean ok = quests.setTracked(p, args[1], sub.equals("track"));
                p.sendMessage(Component.text(ok ? (sub.equals("track") ? "Now tracking " : "Stopped tracking ") + title(args[1])
                        : "You do not have an active quest called '" + args[1] + "'.", ok ? NamedTextColor.GREEN : NamedTextColor.RED));
            }
            case "abandon" -> {
                if (args.length < 2) {
                    p.sendMessage(Component.text("Usage: /" + label + " abandon <quest>", NamedTextColor.RED));
                    return true;
                }
                boolean ok = quests.abandon(p, args[1]);
                p.sendMessage(Component.text(ok ? "Abandoned " + title(args[1]) + ". Your progress on it was cleared."
                        : "You do not have an active quest called '" + args[1] + "'.", ok ? NamedTextColor.YELLOW : NamedTextColor.RED));
            }
            case "dialogue" -> {
                if (args.length >= 2 && args[1].equalsIgnoreCase("next")) {
                    dialogues.next(p);
                } else if (args.length >= 3 && args[1].equalsIgnoreCase("choose")) {
                    try {
                        dialogues.choose(p, Integer.parseInt(args[2]));
                    } catch (NumberFormatException e) {
                        p.sendMessage(Component.text("That option is not available.", NamedTextColor.GRAY));
                    }
                }
            }
            case "questlines" -> {
                List<Component> lines = questlines.describe(p);
                if (lines.isEmpty()) p.sendMessage(Component.text("No questlines yet.", NamedTextColor.GRAY));
                lines.forEach(p::sendMessage);
            }
            case "achievements" -> {
                PlayerState st = quests.state(p);
                if (st == null) {
                    p.sendMessage(Component.text("Your quest data is still loading. Try again in a moment.", NamedTextColor.GRAY));
                    return true;
                }
                if (content.achievements().isEmpty()) p.sendMessage(Component.text("No achievements are defined.", NamedTextColor.GRAY));
                content.achievements().values().forEach(a -> {
                    boolean has = st.flags.contains("ach:" + a.id());
                    if (a.hidden() && !has) return;
                    p.sendMessage(Component.text((has ? "[x] " : "[ ] ") + a.title() + (a.description().isBlank() ? "" : " - " + a.description()),
                            has ? NamedTextColor.GREEN : NamedTextColor.GRAY));
                });
            }
            case "reputation" -> {
                PlayerState st = quests.state(p);
                if (st == null || st.counters.isEmpty()) {
                    p.sendMessage(Component.text("You have no reputation or decisions recorded yet.", NamedTextColor.GRAY));
                    return true;
                }
                st.counters.entrySet().stream().sorted(java.util.Map.Entry.comparingByKey())
                        .forEach(en -> p.sendMessage(Component.text(en.getKey() + ": " + en.getValue(), NamedTextColor.YELLOW)));
            }
            case "community" -> {
                List<Component> lines = community.describe();
                if (lines.isEmpty()) p.sendMessage(Component.text("No community goals right now.", NamedTextColor.GRAY));
                lines.forEach(p::sendMessage);
            }
            case "recommend" -> {
                PlayerState st = quests.state(p);
                List<QuestDefinition> rec = st == null ? List.of() : quests.recommend(st, 3);
                if (rec.isEmpty()) p.sendMessage(Component.text("Nothing to recommend right now. Talk to people around the world.", NamedTextColor.GRAY));
                for (QuestDefinition q : rec) {
                    p.sendMessage(Component.text(q.title(), NamedTextColor.GOLD).append(Component.text(" - " + q.description()
                            + (q.giver().isBlank() ? "" : " (ask " + q.giver() + ")"), NamedTextColor.GRAY)));
                }
            }
            case "top" -> {
                if (args.length < 2 || !content.quests().containsKey(args[1])) {
                    p.sendMessage(Component.text("Usage: /" + label + " top <quest>", NamedTextColor.RED));
                    return true;
                }
                String qid = args[1];
                db.topCompletions(qid, 10).whenComplete((rows, err) -> {
                    if (!plugin.isEnabled()) return;
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        if (err != null) {
                            plugin.getLogger().severe("Leaderboard query failed: " + err);
                            p.sendMessage(Component.text("Could not load the leaderboard.", NamedTextColor.RED));
                            return;
                        }
                        p.sendMessage(Component.text("Most completions of " + title(qid), NamedTextColor.GOLD));
                        int rank = 1;
                        for (Database.TopEntry row : rows) {
                            String name = Bukkit.getOfflinePlayer(row.player()).getName();
                            p.sendMessage(Component.text(rank++ + ". " + (name == null ? row.player().toString() : name) + " - " + row.count(), NamedTextColor.YELLOW));
                        }
                        if (rows.isEmpty()) p.sendMessage(Component.text("Nobody yet.", NamedTextColor.GRAY));
                    });
                });
            }
            case "markers", "sidebar" -> {
                boolean on = args.length >= 2 && args[1].equalsIgnoreCase("on");
                boolean off = args.length >= 2 && args[1].equalsIgnoreCase("off");
                if (!on && !off) {
                    p.sendMessage(Component.text("Usage: /" + label + " " + sub + " on|off", NamedTextColor.RED));
                    return true;
                }
                if (sub.equals("markers")) {
                    if (on) quests.removeFlag(p, "pref:nomarkers"); else quests.addFlag(p, "pref:nomarkers");
                    markers.update(p, true);
                } else {
                    if (on) quests.addFlag(p, "pref:sidebar"); else quests.removeFlag(p, "pref:sidebar");
                    sidebar.update(p);
                }
                p.sendMessage(Component.text(sub + " " + (on ? "on" : "off"), NamedTextColor.GREEN));
            }
            case "skip" -> {
                if (!cutscenes.skip(p)) p.sendMessage(Component.text("There is nothing to skip.", NamedTextColor.GRAY));
            }
            case "party" -> party(p, label, args);
            case "help" -> {
                p.sendMessage(Component.text("/quests - open the journal", NamedTextColor.GOLD));
                p.sendMessage(Component.text("/quests active | available | completed - open a tab", NamedTextColor.GRAY));
                p.sendMessage(Component.text("/quests track|untrack <quest> - choose which quests show on your action bar", NamedTextColor.GRAY));
                p.sendMessage(Component.text("/quests abandon <quest> - drop an active quest (progress is lost)", NamedTextColor.GRAY));
                p.sendMessage(Component.text("/quests questlines - campaign and chapter progress", NamedTextColor.GRAY));
                p.sendMessage(Component.text("/quests achievements | reputation | community | recommend | top <quest>", NamedTextColor.GRAY));
                p.sendMessage(Component.text("/quests markers on|off - distance marker bar; /quests sidebar on|off - sidebar tracker", NamedTextColor.GRAY));
                p.sendMessage(Component.text("/quests party create|invite <player>|accept|leave|list - share progress on party quests", NamedTextColor.GRAY));
                p.sendMessage(Component.text("/quests skip - skip a cutscene that allows it", NamedTextColor.GRAY));
            }
            default -> p.sendMessage(Component.text("Unknown subcommand. Try /" + label + " help", NamedTextColor.RED));
        }
        return true;
    }

    private void party(Player p, String label, String[] args) {
        String sub = args.length < 2 ? "list" : args[1].toLowerCase(Locale.ROOT);
        String err;
        switch (sub) {
            case "create" -> err = parties.create(p.getUniqueId());
            case "leave" -> err = parties.leave(p.getUniqueId());
            case "accept" -> err = parties.accept(p.getUniqueId(), System.currentTimeMillis());
            case "invite" -> {
                Player t = args.length < 3 ? null : Bukkit.getPlayerExact(args[2]);
                if (t == null) {
                    p.sendMessage(Component.text("Usage: /" + label + " party invite <online player>", NamedTextColor.RED));
                    return;
                }
                err = parties.invite(p.getUniqueId(), t.getUniqueId(), System.currentTimeMillis());
                if (err == null) {
                    t.sendMessage(Component.text(p.getName() + " invited you to a party. Type /" + label + " party accept (60s).", NamedTextColor.GOLD));
                    p.sendMessage(Component.text("Invited " + t.getName() + ".", NamedTextColor.GREEN));
                    return;
                }
            }
            case "list" -> {
                StringBuilder sb = new StringBuilder();
                for (java.util.UUID u : parties.membersOf(p.getUniqueId())) {
                    Player m = Bukkit.getPlayer(u);
                    sb.append(m == null ? "(offline)" : m.getName()).append(' ');
                }
                p.sendMessage(Component.text((parties.inParty(p.getUniqueId()) ? "Party: " : "You are not in a party. Members: ") + sb.toString().trim(), NamedTextColor.YELLOW));
                return;
            }
            default -> {
                p.sendMessage(Component.text("Usage: /" + label + " party create|invite <player>|accept|leave|list", NamedTextColor.RED));
                return;
            }
        }
        p.sendMessage(err == null ? Component.text("Done.", NamedTextColor.GREEN) : Component.text(err, NamedTextColor.RED));
    }

    private String title(String id) {
        QuestDefinition q = content.quests().get(id);
        return q == null ? id : q.title();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!(sender instanceof Player p)) return List.of();
        String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
        if (args.length == 1) return SUB.stream().filter(s -> s.startsWith(prefix)).toList();
        if (args.length == 2 && args[0].equalsIgnoreCase("party")) {
            return List.of("create", "invite", "accept", "leave", "list").stream().filter(s -> s.startsWith(prefix)).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("party") && args[1].equalsIgnoreCase("invite")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix)).sorted().toList();
        }
        if (args.length == 2 && List.of("track", "untrack", "abandon").contains(args[0].toLowerCase(Locale.ROOT))) {
            PlayerState s = quests.state(p);
            if (s == null) return List.of();
            return new ArrayList<>(s.active.keySet()).stream().filter(id -> id.toLowerCase(Locale.ROOT).startsWith(prefix)).sorted().toList();
        }
        return List.of();
    }
}
