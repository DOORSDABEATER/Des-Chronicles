package net.dragonempire.chronicles.escorts;

import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.objectives.ObjectiveEvent;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Escort / protect quests: spawns a mob that follows its player to a destination. It fails if the mob dies, the
 * time limit passes, or the player quits or dies. One cancellable task runs only while an escort is active.
 * Arrival fires ESCORT and PROTECT_NPC objective events with the escort id as target.
 */
public final class EscortManager {
    private static final class Active {
        final Player player;
        final EscortDefinition def;
        final UUID entity;
        final long startedAt = System.currentTimeMillis();

        Active(Player player, EscortDefinition def, UUID entity) {
            this.player = player;
            this.def = def;
            this.entity = entity;
        }
    }

    private final JavaPlugin plugin;
    private final ContentManager content;
    private final QuestService quests;
    private final NamespacedKey idKey;
    private final NamespacedKey ownerKey;
    private final Map<UUID, Active> active = new HashMap<>();
    private BukkitTask task;

    public EscortManager(JavaPlugin plugin, ContentManager content, QuestService quests) {
        this.plugin = plugin;
        this.content = content;
        this.quests = quests;
        this.idKey = new NamespacedKey(plugin, "escort_id");
        this.ownerKey = new NamespacedKey(plugin, "escort_owner");
    }

    public NamespacedKey idKey() { return idKey; }
    public NamespacedKey ownerKey() { return ownerKey; }

    /** Returns null on success or a reason it could not start. */
    public String start(Player p, String id) {
        EscortDefinition def = content.escorts().get(id);
        if (def == null) return "Unknown escort: " + id;
        if (!def.configured()) return "This escort has not been set up on the server yet ('" + id + "' is unconfigured).";
        if (active.containsKey(p.getUniqueId())) return "You are already escorting someone.";
        World w = Bukkit.getWorld(def.world());
        if (w == null) return "Escort world '" + def.world() + "' is not loaded.";
        Entity e = w.spawnEntity(new Location(w, def.startX(), def.startY(), def.startZ()), EntityType.valueOf(def.entity()));
        e.setPersistent(false);
        e.customName(MiniMessage.miniMessage().deserialize(def.name()));
        e.setCustomNameVisible(true);
        e.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, id);
        e.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, p.getUniqueId().toString());
        if (e instanceof LivingEntity le) {
            AttributeInstance max = le.getAttribute(Attribute.MAX_HEALTH);
            if (max != null) max.setBaseValue(def.health());
            le.setHealth(Math.min(def.health(), max == null ? def.health() : max.getValue()));
            le.setRemoveWhenFarAway(false);
        }
        active.put(p.getUniqueId(), new Active(p, def, e.getUniqueId()));
        if (task == null) task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 10L, 10L);
        p.sendMessage(Messages.get("escort.started", "name", stripName(def.name())));
        return null;
    }

    private void tick() {
        for (Active a : new ArrayList<>(active.values())) {
            Player p = a.player;
            Entity e = Bukkit.getEntity(a.entity);
            if (!p.isOnline()) {
                remove(a, e);
                continue;
            }
            if (e == null || !e.isValid()) {
                fail(a, null, "the escort was lost");
                continue;
            }
            if (a.def.timeLimitSeconds() > 0 && System.currentTimeMillis() - a.startedAt > a.def.timeLimitSeconds() * 1000L) {
                fail(a, e, "time ran out");
                continue;
            }
            double distSq = p.getWorld().equals(e.getWorld()) ? p.getLocation().distanceSquared(e.getLocation()) : Double.MAX_VALUE;
            if (distSq > 40 * 40) {
                e.teleport(p.getLocation()); // fell too far behind or changed world: catch up instead of failing
            } else if (e instanceof Mob m) {
                if (distSq > 25) m.getPathfinder().moveTo(p.getLocation(), a.def.speed());
                else if (distSq < 9) m.getPathfinder().stopPathfinding();
            }
            Location dest = new Location(e.getWorld(), a.def.destX(), a.def.destY(), a.def.destZ());
            if (e.getLocation().distanceSquared(dest) <= a.def.radius() * a.def.radius() && distSq <= 16 * 16) {
                active.remove(p.getUniqueId());
                e.remove();
                p.sendMessage(Messages.get("escort.arrived", "name", stripName(a.def.name())));
                quests.handle(p, new ObjectiveEvent("ESCORT", a.def.id()));
                quests.handle(p, new ObjectiveEvent("PROTECT_NPC", a.def.id()));
            }
        }
        if (active.isEmpty() && task != null) {
            task.cancel();
            task = null;
        }
    }

    public void onEscortDeath(Entity dead) {
        String owner = dead.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        if (owner == null) return;
        try {
            Active a = active.get(UUID.fromString(owner));
            if (a != null && a.entity.equals(dead.getUniqueId())) fail(a, null, "the escort was killed");
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("Escort entity with a corrupt owner tag: " + owner);
        }
    }

    public void onPlayerGone(Player p, String reason) {
        Active a = active.get(p.getUniqueId());
        if (a != null) fail(a, Bukkit.getEntity(a.entity), reason);
    }

    private void fail(Active a, Entity e, String reason) {
        remove(a, e);
        if (a.player.isOnline()) a.player.sendMessage(Messages.get("escort.failed", "reason", reason));
    }

    private void remove(Active a, Entity e) {
        active.remove(a.player.getUniqueId());
        if (e != null && e.isValid()) e.remove();
    }

    public void shutdown() {
        if (task != null) task.cancel();
        task = null;
        for (Active a : new ArrayList<>(active.values())) remove(a, Bukkit.getEntity(a.entity));
        active.clear();
    }

    private static String stripName(String miniMessage) {
        return net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(MiniMessage.miniMessage().deserialize(miniMessage));
    }
}
