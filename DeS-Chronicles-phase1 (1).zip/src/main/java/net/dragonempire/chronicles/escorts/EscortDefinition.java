package net.dragonempire.chronicles.escorts;

/** configured=false means placeholder coordinates: the escort refuses to start until an admin sets it up. */
public record EscortDefinition(String id, String name, String entity, boolean configured, String world,
                               double startX, double startY, double startZ, double destX, double destY, double destZ,
                               double radius, double health, int timeLimitSeconds, double speed) {}
