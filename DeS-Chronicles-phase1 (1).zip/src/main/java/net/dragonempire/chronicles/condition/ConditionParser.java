package net.dragonempire.chronicles.condition;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Parses condition specs from YAML-style data.
 * A list means AND. A map may be {all: [...]}, {any: [...]}, {not: spec} or a leaf {type: ..., ...}.
 * Invalid specs add a ValidationIssue and evaluate to false.
 */
public final class ConditionParser {
    private static final Condition NEVER = c -> false;
    private static final Condition ALWAYS = c -> true;

    private ConditionParser() {}

    public static Condition parse(Object spec, String file, String path, List<ValidationIssue> issues) {
        if (spec == null) return ALWAYS;
        if (spec instanceof List<?> list) return combine(true, list, file, path, issues);
        if (spec instanceof Map<?, ?> m) {
            if (m.containsKey("all")) return combine(true, m.get("all"), file, path + ".all", issues);
            if (m.containsKey("any")) return combine(false, m.get("any"), file, path + ".any", issues);
            if (m.containsKey("not")) {
                Condition inner = parse(m.get("not"), file, path + ".not", issues);
                return c -> !inner.test(c);
            }
            return leaf(m, file, path, issues);
        }
        issues.add(new ValidationIssue(file, path, "condition must be a list or map"));
        return NEVER;
    }

    private static Condition combine(boolean and, Object raw, String file, String path, List<ValidationIssue> issues) {
        if (!(raw instanceof List<?> list)) {
            issues.add(new ValidationIssue(file, path, "must be a list of conditions"));
            return NEVER;
        }
        List<Condition> parts = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) parts.add(parse(list.get(i), file, path + "[" + i + "]", issues));
        if (and) return c -> parts.stream().allMatch(p -> p.test(c));
        return c -> parts.stream().anyMatch(p -> p.test(c));
    }

    private static Condition leaf(Map<?, ?> m, String file, String path, List<ValidationIssue> issues) {
        Object t = m.get("type");
        if (!(t instanceof String type)) {
            issues.add(new ValidationIssue(file, path + ".type", "required"));
            return NEVER;
        }
        switch (type.toLowerCase(Locale.ROOT)) {
            case "completed_quest" -> {
                String q = str(m, "quest", file, path, issues);
                return q == null ? NEVER : c -> c.hasCompletedQuest(q);
            }
            case "not_completed_quest" -> {
                String q = str(m, "quest", file, path, issues);
                return q == null ? NEVER : c -> !c.hasCompletedQuest(q);
            }
            case "active_quest" -> {
                String q = str(m, "quest", file, path, issues);
                return q == null ? NEVER : c -> c.hasActiveQuest(q);
            }
            case "has_item" -> {
                String item = str(m, "item", file, path, issues);
                int amount = m.get("amount") instanceof Number n ? n.intValue() : 1;
                if (amount < 1) {
                    issues.add(new ValidationIssue(file, path + ".amount", "must be >= 1"));
                    return NEVER;
                }
                return item == null ? NEVER : c -> c.hasItem(item, amount);
            }
            case "permission" -> {
                String node = str(m, "node", file, path, issues);
                return node == null ? NEVER : c -> c.hasPermission(node);
            }
            case "level" -> {
                if (!(m.get("min") instanceof Number n)) {
                    issues.add(new ValidationIssue(file, path + ".min", "required number"));
                    return NEVER;
                }
                int min = n.intValue();
                return c -> c.level() >= min;
            }
            case "achievement" -> {
                String id = str(m, "id", file, path, issues);
                return id == null ? NEVER : c -> c.hasAchievement(id);
            }
            case "visited" -> {
                String loc = str(m, "location", file, path, issues);
                return loc == null ? NEVER : c -> c.hasVisited(loc);
            }
            case "defeated_boss" -> {
                String boss = str(m, "boss", file, path, issues);
                return boss == null ? NEVER : c -> c.hasDefeatedBoss(boss);
            }
            case "chose" -> {
                String d = str(m, "dialogue", file, path, issues);
                String ch = str(m, "choice", file, path, issues);
                return d == null || ch == null ? NEVER : c -> c.choseOption(d, ch);
            }
            case "counter" -> {
                String key = str(m, "key", file, path, issues);
                Integer min = m.get("min") instanceof Number n ? n.intValue() : null;
                Integer max = m.get("max") instanceof Number n ? n.intValue() : null;
                if (min == null && max == null) {
                    issues.add(new ValidationIssue(file, path, "counter needs min and/or max"));
                    return NEVER;
                }
                return key == null ? NEVER : c -> (min == null || c.counter(key) >= min) && (max == null || c.counter(key) <= max);
            }
            case "global" -> {
                String key = str(m, "key", file, path, issues);
                if (!(m.get("min") instanceof Number n)) {
                    issues.add(new ValidationIssue(file, path + ".min", "required number"));
                    return NEVER;
                }
                long min = n.longValue();
                return key == null ? NEVER : c -> c.globalAtLeast(key, min);
            }
            case "event_active" -> {
                String ev = str(m, "event", file, path, issues);
                return ev == null ? NEVER : c -> c.eventActive(ev);
            }
            case "questline_stage" -> {
                String line = str(m, "questline", file, path, issues);
                String stage = str(m, "stage", file, path, issues);
                return line == null || stage == null ? NEVER : c -> c.atQuestlineStage(line, stage);
            }
            default -> {
                issues.add(new ValidationIssue(file, path + ".type", "unknown condition type '" + type + "'"));
                return NEVER;
            }
        }
    }

    private static String str(Map<?, ?> m, String key, String file, String path, List<ValidationIssue> issues) {
        Object v = m.get(key);
        if (v instanceof String s && !s.isBlank()) return s;
        issues.add(new ValidationIssue(file, path + "." + key, "required"));
        return null;
    }
}
