package net.dragonempire.chronicles.condition;

/** Server-wide facts conditions may ask about. */
public interface WorldView {
    boolean eventActive(String eventId);

    boolean globalAtLeast(String key, long min);
}
