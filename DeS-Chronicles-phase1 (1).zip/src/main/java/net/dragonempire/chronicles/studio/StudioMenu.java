package net.dragonempire.chronicles.studio;

import net.dragonempire.chronicles.ChroniclesPlugin;
import net.dragonempire.chronicles.events.EventDefinition;
import net.dragonempire.chronicles.npc.NpcDefinition;
import net.dragonempire.chronicles.quest.QuestDefinition;
import net.dragonempire.chronicles.quest.QuestStatus;
import net.dragonempire.chronicles.validation.ValidationIssue;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Admin studio: browse and manage quests (draft/publish/disable, preview), NPCs (teleport, move here), events
 * (toggle) and validation problems. Authoring text, objectives and dialogue is done in the YAML files, then reload.
 */
public final class StudioMenu {
    public enum Kind { MAIN, QUESTS, NPCS, EVENTS, DIAGNOSTICS }

    private static final int PER_PAGE = 45;

    public static final class Holder implements InventoryHolder {
        final Kind kind;
        final int page;
        final List<String> ids = new ArrayList<>();
        Inventory inventory;

        Holder(Kind kind, int page) {
            this.kind = kind;
            this.page = page;
        }

        @Override
        public Inventory getInventory() { return inventory; }
    }

    private final ChroniclesPlugin plugin;
    private final StudioService service;

    public StudioMenu(ChroniclesPlugin plugin, StudioService service) {
        this.plugin = plugin;
        this.service = service;
    }

    public void open(Player p, Kind kind, int page) {
        if (!p.hasPermission("desquests.admin")) {
            p.sendMessage(Component.text("You do not have permission.", NamedTextColor.RED));
            return;
        }
        Holder h = new Holder(kind, Math.max(0, page));
        Inventory inv = Bukkit.createInventory(h, kind == Kind.MAIN ? 27 : 54, Component.text("DeS Studio - " + kind.name().charAt(0) + kind.name().substring(1).toLowerCase()));
        h.inventory = inv;
        if (kind == Kind.MAIN) {
            inv.setItem(10, item(Material.WRITABLE_BOOK, "Quests", NamedTextColor.GOLD, List.of(plugin.content().quests().size() + " loaded", "Publish, disable, preview")));
            inv.setItem(12, item(Material.VILLAGER_SPAWN_EGG, "NPCs", NamedTextColor.GOLD, List.of(plugin.npcs().all().size() + " defined", "Teleport, move")));
            inv.setItem(14, item(Material.CLOCK, "Events", NamedTextColor.GOLD, List.of(plugin.content().events().size() + " defined", "Start / stop")));
            inv.setItem(16, item(Material.COMPARATOR, "Diagnostics", NamedTextColor.GOLD, List.of(plugin.content().issues().size() + " validation issue(s)")));
            inv.setItem(22, item(Material.REPEATER, "Reload content", NamedTextColor.YELLOW, List.of("Re-reads all files. Player progress is untouched.")));
        } else {
            fill(inv, h);
            inv.setItem(45, item(Material.ARROW, "Previous page", NamedTextColor.YELLOW, List.of()));
            inv.setItem(49, item(Material.BARRIER, "Back", NamedTextColor.RED, List.of()));
            inv.setItem(53, item(Material.ARROW, "Next page", NamedTextColor.YELLOW, List.of()));
        }
        p.openInventory(inv);
    }

    private void fill(Inventory inv, Holder h) {
        List<ItemStack> items = new ArrayList<>();
        switch (h.kind) {
            case QUESTS -> plugin.content().quests().values().stream().sorted((a, b) -> a.id().compareTo(b.id())).forEach(q -> {
                h.ids.add(q.id());
                items.add(questItem(q));
            });
            case NPCS -> plugin.npcs().all().forEach(n -> {
                h.ids.add(n.id());
                items.add(item(Material.VILLAGER_SPAWN_EGG, n.id(), NamedTextColor.AQUA, List.of(n.world() + " " + (int) n.x() + " " + (int) n.y() + " " + (int) n.z(),
                        n.dialogue().isBlank() ? "no dialogue" : "dialogue: " + n.dialogue(), "Left-click: teleport to it", "Right-click: move it to you")));
            });
            case EVENTS -> plugin.content().events().values().forEach(ev -> {
                h.ids.add(ev.id());
                boolean on = plugin.events().isActive(ev.id());
                items.add(item(on ? Material.LIME_DYE : Material.GRAY_DYE, ev.title() + (on ? " (ACTIVE)" : " (inactive)"), on ? NamedTextColor.GREEN : NamedTextColor.GRAY,
                        List.of("Click to " + (on ? "stop" : "start"), ev.id())));
            });
            case DIAGNOSTICS -> {
                for (ValidationIssue i : plugin.content().issues()) {
                    h.ids.add("");
                    items.add(item(Material.PAPER, i.file(), NamedTextColor.RED, List.of(i.path(), i.message())));
                }
            }
            default -> { }
        }
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = h.page * PER_PAGE + i;
            if (idx >= items.size()) break;
            inv.setItem(i, items.get(idx));
        }
    }

    private ItemStack questItem(QuestDefinition q) {
        Material m = switch (q.status()) {
            case PUBLISHED -> Material.LIME_DYE;
            case DRAFT -> Material.YELLOW_DYE;
            case DISABLED -> Material.GRAY_DYE;
        };
        return item(m, q.title(), NamedTextColor.WHITE, List.of("id: " + q.id(), "status: " + q.status().name().toLowerCase(),
                q.prerequisites().isEmpty() ? "no prerequisites" : "needs: " + String.join(", ", q.prerequisites()),
                "Left-click: draft -> published -> disabled -> draft", "Right-click: start it for yourself (preview)"));
    }

    public void click(Player p, Holder h, int slot, ClickType type) {
        if (!p.hasPermission("desquests.admin")) {
            p.closeInventory();
            return;
        }
        if (h.kind == Kind.MAIN) {
            switch (slot) {
                case 10 -> open(p, Kind.QUESTS, 0);
                case 12 -> open(p, Kind.NPCS, 0);
                case 14 -> open(p, Kind.EVENTS, 0);
                case 16 -> open(p, Kind.DIAGNOSTICS, 0);
                case 22 -> {
                    int n = plugin.reloadContent().size();
                    p.sendMessage(Component.text("Reloaded. " + n + " issue(s).", n == 0 ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
                    open(p, Kind.MAIN, 0);
                }
                default -> { }
            }
            return;
        }
        if (slot == 49) { open(p, Kind.MAIN, 0); return; }
        if (slot == 45) { open(p, h.kind, h.page - 1); return; }
        if (slot == 53) { open(p, h.kind, h.page + 1); return; }
        int idx = h.page * PER_PAGE + slot;
        if (slot < 0 || slot >= PER_PAGE || idx >= h.ids.size() || h.ids.get(idx).isEmpty()) return;
        String id = h.ids.get(idx);
        switch (h.kind) {
            case QUESTS -> {
                QuestDefinition q = plugin.content().quests().get(id);
                if (q == null) return;
                if (type.isRightClick()) {
                    String err = plugin.quests().start(p, id, true);
                    p.sendMessage(Component.text(err == null ? "Started " + id + " for you (preview)." : err, err == null ? NamedTextColor.GREEN : NamedTextColor.RED));
                    return;
                }
                QuestStatus next = switch (q.status()) {
                    case DRAFT -> QuestStatus.PUBLISHED;
                    case PUBLISHED -> QuestStatus.DISABLED;
                    case DISABLED -> QuestStatus.DRAFT;
                };
                String err = service.setQuestStatus(id, next);
                p.sendMessage(Component.text(err == null ? id + " is now " + next.name().toLowerCase() + "." : err, err == null ? NamedTextColor.GREEN : NamedTextColor.RED));
                open(p, Kind.QUESTS, h.page);
            }
            case NPCS -> {
                NpcDefinition n = plugin.npcs().get(id);
                if (n == null) return;
                if (type.isRightClick()) {
                    String err = plugin.npcs().move(id, p.getLocation());
                    p.sendMessage(Component.text(err == null ? "Moved " + id + " to you." : err, err == null ? NamedTextColor.GREEN : NamedTextColor.RED));
                    open(p, Kind.NPCS, h.page);
                } else {
                    World w = Bukkit.getWorld(n.world());
                    if (w == null) p.sendMessage(Component.text("That NPC's world is not loaded.", NamedTextColor.RED));
                    else p.teleport(new Location(w, n.x(), n.y(), n.z(), n.yaw(), n.pitch()));
                }
            }
            case EVENTS -> {
                EventDefinition ev = plugin.content().events().get(id);
                if (ev == null) return;
                String err = plugin.events().set(id, !plugin.events().isActive(id));
                if (err != null) p.sendMessage(Component.text(err, NamedTextColor.RED));
                open(p, Kind.EVENTS, h.page);
            }
            default -> { }
        }
    }

    private static ItemStack item(Material m, String name, NamedTextColor color, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(Component.text(s, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }
}
