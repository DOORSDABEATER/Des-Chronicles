package net.dragonempire.chronicles.studio;

import net.dragonempire.chronicles.ChroniclesPlugin;
import net.dragonempire.chronicles.quest.QuestFiles;
import net.dragonempire.chronicles.quest.QuestStatus;
import net.dragonempire.chronicles.validation.ValidationIssue;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Draft / publish / disable workflow shared by the studio menu and commands. Main thread only. */
public final class StudioService {
    private final ChroniclesPlugin plugin;

    public StudioService(ChroniclesPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Rewrites only the quest file's status line, reloads, and verifies. Publishing a quest that fails
     * validation is rolled back and the reasons are returned. Player progress is never touched.
     * Returns null on success, otherwise a message.
     */
    public String setQuestStatus(String questId, QuestStatus status) {
        String fileName = plugin.content().questFiles().get(questId);
        if (fileName == null) return "Unknown quest (or it failed to load - run /desquests validate): " + questId;
        Path file = plugin.getDataFolder().toPath().resolve("quests").resolve(fileName);
        String original;
        try {
            original = Files.readString(file, StandardCharsets.UTF_8);
            QuestFiles.setStatus(file, status);
        } catch (IOException e) {
            return "Could not edit " + fileName + ": " + e.getMessage();
        }
        List<ValidationIssue> issues = plugin.reloadContent();
        if (status == QuestStatus.PUBLISHED && !plugin.content().quests().containsKey(questId)) {
            try {
                Files.writeString(file, original, StandardCharsets.UTF_8);
            } catch (IOException e) {
                return "Publish failed AND the file could not be restored (" + e.getMessage() + "): fix " + fileName + " by hand.";
            }
            plugin.reloadContent();
            StringBuilder sb = new StringBuilder("Not published, " + fileName + " has errors:");
            issues.stream().filter(i -> i.file().equals(fileName)).limit(5).forEach(i -> sb.append("\n - ").append(i));
            return sb.toString();
        }
        return null;
    }
}
