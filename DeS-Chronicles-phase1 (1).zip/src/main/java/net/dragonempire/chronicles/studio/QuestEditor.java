package net.dragonempire.chronicles.studio;

import net.dragonempire.chronicles.ChroniclesPlugin;
import net.dragonempire.chronicles.quest.QuestLoader;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Command-driven quest authoring. Every change is validated by reloading; a change that makes the quest invalid is
 * rolled back and the problems are reported. Player progress is never touched. Methods return null on success.
 * Stages, dialogue and cutscenes are still authored in the YAML files.
 */
public final class QuestEditor {
    private static final Pattern ID = Pattern.compile("[a-z0-9_]{3,48}");
    private static final Pattern TYPE = Pattern.compile("[A-Za-z_]{2,40}");
    private static final Set<String> SCALARS = Set.of("title", "description", "giver", "category", "repeatable", "hidden", "reset", "event", "party");

    private final ChroniclesPlugin plugin;

    public QuestEditor(ChroniclesPlugin plugin) {
        this.plugin = plugin;
    }

    private Path dir() { return plugin.getDataFolder().toPath().resolve("quests"); }

    private Path fileOf(String id) {
        String f = plugin.content().questFiles().get(id);
        return f == null ? null : dir().resolve(f);
    }

    public String create(String id) {
        if (!ID.matcher(id).matches()) return "Quest ids must match [a-z0-9_]{3,48}.";
        Path file = dir().resolve(id + ".yml");
        if (Files.exists(file) || plugin.content().quests().containsKey(id)) return "A quest with that id already exists.";
        YamlConfiguration y = new YamlConfiguration();
        y.set("title", id);
        y.set("description", "Describe this quest.");
        y.set("status", "draft");
        y.set("category", "side");
        y.set("objectives", List.of(new LinkedHashMap<>(Map.of("id", "o1", "type", "TALK_NPC", "target", "ancient_one", "amount", 1))));
        try {
            Files.createDirectories(dir());
            y.save(file.toFile());
        } catch (IOException e) {
            return "Could not write " + file.getFileName() + ": " + e.getMessage();
        }
        List<ValidationIssue> issues = plugin.reloadContent();
        if (!plugin.content().quests().containsKey(id)) {
            try {
                Files.deleteIfExists(file);
            } catch (IOException ignored) {
                // the next reload reports the leftover file; nothing more to do here
            }
            plugin.reloadContent();
            return "Could not create the quest: " + firstIssues(issues, id + ".yml");
        }
        return null;
    }

    public String set(String id, String key, String value) {
        if (!SCALARS.contains(key)) return "Editable keys: " + String.join(", ", new TreeSet<>(SCALARS)) + ". Use the YAML file for anything else.";
        return mutate(id, y -> {
            switch (key) {
                case "repeatable", "hidden" -> {
                    if (!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false")) throw new IllegalArgumentException(key + " must be true or false");
                    y.set(key, Boolean.parseBoolean(value));
                }
                case "reset" -> {
                    if (!List.of("none", "daily", "weekly").contains(value.toLowerCase(Locale.ROOT))) throw new IllegalArgumentException("reset must be none, daily or weekly");
                    y.set(key, value.toLowerCase(Locale.ROOT));
                }
                case "party" -> {
                    if (!List.of("individual", "shared").contains(value.toLowerCase(Locale.ROOT))) throw new IllegalArgumentException("party must be individual or shared");
                    y.set(key, value.toLowerCase(Locale.ROOT));
                }
                default -> y.set(key, value);
            }
        });
    }

    /** target "-" means any target. Only for quests that use a flat objectives list. */
    public String addObjective(String id, String type, String target, int amount) {
        if (!TYPE.matcher(type).matches()) return "Objective types look like KILL_MOB or COLLECT_ITEM.";
        if (amount < 1) return "Amount must be at least 1.";
        return mutate(id, y -> {
            if (y.contains("stages")) throw new IllegalArgumentException("this quest uses stages; edit the YAML file instead");
            List<Map<?, ?>> list = new ArrayList<>(y.getMapList("objectives"));
            Set<String> used = new HashSet<>();
            for (Map<?, ?> m : list) used.add(String.valueOf(m.get("id")));
            int n = list.size() + 1;
            while (used.contains("o" + n)) n++;
            Map<String, Object> o = new LinkedHashMap<>();
            o.put("id", "o" + n);
            o.put("type", type.toUpperCase(Locale.ROOT));
            if (!target.equals("-")) o.put("target", target);
            o.put("amount", amount);
            list.add(o);
            y.set("objectives", list);
        });
    }

    /** params are key=value tokens, for example: addreward q item item=DIAMOND amount=2 chance=0.5 */
    public String addReward(String id, String type, List<String> params) {
        String t = type.toLowerCase(Locale.ROOT);
        if (!QuestLoader.REWARD_TYPES.contains(t)) return "Reward types: " + String.join(", ", new TreeSet<>(QuestLoader.REWARD_TYPES));
        Map<String, Object> reward = new LinkedHashMap<>();
        reward.put("type", t);
        for (String p : params) {
            int eq = p.indexOf('=');
            if (eq < 1) return "Parameters look like key=value (got '" + p + "').";
            reward.put(p.substring(0, eq), scalar(p.substring(eq + 1)));
        }
        return mutate(id, y -> {
            List<Map<?, ?>> list = new ArrayList<>(y.getMapList("rewards"));
            list.add(reward);
            y.set("rewards", list);
        });
    }

    public String delete(String id, boolean confirmed) {
        Path file = fileOf(id);
        if (file == null) return "Unknown quest (or it failed to load): " + id;
        if (!confirmed) return "This deletes " + file.getFileName() + ". Players' saved progress stays in the database. Repeat with 'confirm' to proceed.";
        try {
            Files.delete(file);
        } catch (IOException e) {
            return "Could not delete " + file.getFileName() + ": " + e.getMessage();
        }
        plugin.reloadContent();
        return null;
    }

    private String mutate(String id, Consumer<YamlConfiguration> change) {
        Path file = fileOf(id);
        if (file == null) return "Unknown quest (or it failed to load - run /desquests validate): " + id;
        String original;
        try {
            original = Files.readString(file, StandardCharsets.UTF_8);
            YamlConfiguration y = new YamlConfiguration();
            y.options().parseComments(true);
            y.load(file.toFile());
            change.accept(y);
            y.save(file.toFile());
        } catch (IllegalArgumentException e) {
            return "Rejected: " + e.getMessage();
        } catch (IOException | InvalidConfigurationException e) {
            return "Could not edit " + file.getFileName() + ": " + e.getMessage();
        }
        List<ValidationIssue> issues = plugin.reloadContent();
        if (plugin.content().quests().containsKey(id)) return null;
        try {
            Files.writeString(file, original, StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "That change made the quest invalid AND the file could not be restored (" + e.getMessage() + "). Fix " + file.getFileName() + " by hand.";
        }
        plugin.reloadContent();
        return "Rejected, the quest would be invalid: " + firstIssues(issues, file.getFileName().toString());
    }

    private static String firstIssues(List<ValidationIssue> issues, String file) {
        StringBuilder sb = new StringBuilder();
        issues.stream().filter(i -> i.file().equals(file)).limit(3).forEach(i -> sb.append("\n - ").append(i));
        return sb.length() == 0 ? "see /desquests validate" : sb.toString();
    }

    private static Object scalar(String v) {
        if (v.equalsIgnoreCase("true") || v.equalsIgnoreCase("false")) return Boolean.parseBoolean(v);
        try {
            if (v.matches("-?\\d{1,9}")) return Integer.parseInt(v);
            if (v.matches("-?\\d+\\.\\d+")) return Double.parseDouble(v);
        } catch (NumberFormatException ignored) {
            // falls through to a plain string
        }
        return v;
    }
}
