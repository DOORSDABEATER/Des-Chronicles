package net.dragonempire.chronicles.storage;

import java.util.Map;
import java.util.Set;

/** Snapshot of one player's persisted state. activeQuests maps quest id to encoded progress. */
public record PlayerData(Map<String, String> activeQuests, Map<String, Integer> completions,
                         Map<String, Long> lastCompleted, Set<String> flags,
                         Map<String, Integer> counters) {}
