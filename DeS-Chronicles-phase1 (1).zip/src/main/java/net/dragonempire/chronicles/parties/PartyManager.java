package net.dragonempire.chronicles.parties;

import java.util.*;

/** In-memory parties. Every method returns null on success or a player-facing error. Main thread only. */
public final class PartyManager {
    private static final long INVITE_MS = 60_000;

    private record Invite(UUID party, long expires) {}

    private final int maxSize;
    private final Map<UUID, Set<UUID>> parties = new HashMap<>();   // leader -> members (including leader)
    private final Map<UUID, UUID> leaderOf = new HashMap<>();       // member -> leader
    private final Map<UUID, Invite> invites = new HashMap<>();      // invitee -> invite

    public PartyManager(int maxSize) {
        this.maxSize = maxSize;
    }

    public String create(UUID player) {
        if (leaderOf.containsKey(player)) return "You are already in a party.";
        Set<UUID> s = new LinkedHashSet<>();
        s.add(player);
        parties.put(player, s);
        leaderOf.put(player, player);
        return null;
    }

    public String invite(UUID inviter, UUID target, long now) {
        UUID leader = leaderOf.get(inviter);
        if (leader == null) return "You are not in a party. Create one first.";
        if (!leader.equals(inviter)) return "Only the party leader can invite.";
        if (inviter.equals(target)) return "You cannot invite yourself.";
        if (leaderOf.containsKey(target)) return "That player is already in a party.";
        if (parties.get(leader).size() >= maxSize) return "Your party is full.";
        invites.put(target, new Invite(leader, now + INVITE_MS));
        return null;
    }

    public String accept(UUID invitee, long now) {
        Invite inv = invites.remove(invitee);
        if (inv == null || inv.expires() < now) return "You have no pending party invite.";
        Set<UUID> members = parties.get(inv.party());
        if (members == null) return "That party no longer exists.";
        if (leaderOf.containsKey(invitee)) return "You are already in a party.";
        if (members.size() >= maxSize) return "That party is full.";
        members.add(invitee);
        leaderOf.put(invitee, inv.party());
        return null;
    }

    public String leave(UUID player) {
        UUID leader = leaderOf.remove(player);
        if (leader == null) return "You are not in a party.";
        Set<UUID> members = parties.get(leader);
        members.remove(player);
        if (members.isEmpty()) {
            parties.remove(leader);
        } else if (leader.equals(player)) {
            UUID next = members.iterator().next();   // promote the longest-standing member
            parties.remove(leader);
            parties.put(next, members);
            for (UUID m : members) leaderOf.put(m, next);
        }
        return null;
    }

    /** Members including the player; just the player if they have no party. */
    public Set<UUID> membersOf(UUID player) {
        UUID leader = leaderOf.get(player);
        if (leader == null) return Set.of(player);
        return Collections.unmodifiableSet(parties.get(leader));
    }

    public boolean inParty(UUID player) { return leaderOf.containsKey(player); }
}
