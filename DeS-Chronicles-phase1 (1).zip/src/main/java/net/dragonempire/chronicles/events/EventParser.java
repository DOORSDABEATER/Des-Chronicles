package net.dragonempire.chronicles.events;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.*;

public final class EventParser {
    private EventParser() {}

    public static EventDefinition parse(String id, Map<String, Object> root, String file, Set<String> knownQuests,
                                        List<ValidationIssue> issues) {
        int before = issues.size();
        String title = root.get("title") instanceof String s && !s.isBlank() ? s : null;
        if (title == null) issues.add(new ValidationIssue(file, "title", "required"));
        Instant start = time(root.get("start"), file, "start", issues);
        Instant end = time(root.get("end"), file, "end", issues);
        if (start != null && end != null && !end.isAfter(start)) issues.add(new ValidationIssue(file, "end", "must be after start"));
        List<String> quests = new ArrayList<>();
        if (root.get("quests") instanceof List<?> l) {
            for (Object o : l) {
                String q = String.valueOf(o);
                if (!knownQuests.contains(q)) issues.add(new ValidationIssue(file, "quests", "unknown quest '" + q + "'"));
                quests.add(q);
            }
        }
        if (issues.size() > before) return null;
        return new EventDefinition(id, title, start, end,
                root.get("start_message") instanceof String s ? s : "", root.get("end_message") instanceof String s ? s : "",
                List.copyOf(quests));
    }

    private static Instant time(Object raw, String file, String path, List<ValidationIssue> issues) {
        if (raw == null) return null;
        try {
            return OffsetDateTime.parse(String.valueOf(raw)).toInstant();
        } catch (DateTimeParseException e) {
            issues.add(new ValidationIssue(file, path, "must be an ISO-8601 timestamp with offset, e.g. 2026-12-01T00:00:00Z"));
            return null;
        }
    }
}
