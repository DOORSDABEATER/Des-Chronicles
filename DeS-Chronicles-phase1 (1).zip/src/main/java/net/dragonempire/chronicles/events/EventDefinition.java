package net.dragonempire.chronicles.events;

import java.time.Instant;
import java.util.List;

/** start/end may be null. Events with neither are manual-only. quests are the quests gated behind the event. */
public record EventDefinition(String id, String title, Instant start, Instant end, String startMessage,
                              String endMessage, List<String> quests) {}
