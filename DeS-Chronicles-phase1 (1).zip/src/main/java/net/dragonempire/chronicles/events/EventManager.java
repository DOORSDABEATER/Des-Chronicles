package net.dragonempire.chronicles.events;

import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.storage.Database;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Live events. Whether an event is active is computed from its schedule plus a persisted manual override
 * (so admins can start/stop without restarting). One cancellable task per minute only announces transitions.
 */
public final class EventManager {
    private final JavaPlugin plugin;
    private final ContentManager content;
    private final Database db;
    private final Map<String, String> overrides = new HashMap<>();
    private final Map<String, Boolean> lastActive = new HashMap<>();
    private BukkitTask task;
    private boolean loaded;

    public EventManager(JavaPlugin plugin, ContentManager content, Database db) {
        this.plugin = plugin;
        this.content = content;
        this.db = db;
    }

    /** Loads persisted overrides, then starts the transition watcher. Queued behind the database open. */
    public void start() {
        db.loadServerState().whenComplete((state, err) -> {
            if (!plugin.isEnabled()) return;
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (err != null) {
                    plugin.getLogger().severe("Could not load event state: " + err);
                } else {
                    state.forEach((k, v) -> { if (k.startsWith("event:")) overrides.put(k.substring(6), v); });
                }
                loaded = true;
                for (EventDefinition d : content.events().values()) lastActive.put(d.id(), isActive(d.id())); // silent baseline
                task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 1200L, 1200L);
            });
        });
    }

    public void shutdown() {
        if (task != null) task.cancel();
        task = null;
    }

    public boolean isActive(String id) {
        EventDefinition d = content.events().get(id);
        return d != null && loaded && EventSchedule.isActive(d, overrides.get(id), Instant.now());
    }

    /** Returns null on success or an error message. */
    public String set(String id, boolean on) {
        EventDefinition d = content.events().get(id);
        if (d == null) return "Unknown event: " + id;
        overrides.put(id, on ? "on" : "off");
        db.setServerState("event:" + id, on ? "on" : "off").exceptionally(err -> {
            plugin.getLogger().severe("Could not persist event state for " + id + ": " + err);
            return null;
        });
        tick();
        if (on && !isActive(id)) return "Event '" + id + "' was switched on but its end time has already passed, so it is not active.";
        return null;
    }

    private void tick() {
        for (EventDefinition d : content.events().values()) {
            boolean now = isActive(d.id());
            Boolean before = lastActive.put(d.id(), now);
            if (before == null || before == now) continue;
            String msg = now ? d.startMessage() : d.endMessage();
            if (msg.isBlank()) msg = (now ? "<gold>Event started: " : "<gray>Event ended: ") + d.title();
            Component c = MiniMessage.miniMessage().deserialize(msg);
            plugin.getServer().broadcast(c);
        }
    }
}
