package net.dragonempire.chronicles.bosses;

import java.util.List;

/** configured=false means the spawn location is still a placeholder: the boss refuses to spawn. */
public record BossDefinition(String id, String name, String entity, boolean configured, String world,
                             double x, double y, double z, double health, double arenaRadius,
                             int timeLimitSeconds, double minDamage, List<BossPhase> phases) {}
