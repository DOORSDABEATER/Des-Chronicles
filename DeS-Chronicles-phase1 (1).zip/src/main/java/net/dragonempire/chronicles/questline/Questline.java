package net.dragonempire.chronicles.questline;

import net.dragonempire.chronicles.rewards.RewardSpec;

import java.util.List;

/** endings: if non-empty, the campaign is complete once all required chapters are done and any ending quest is done. */
public record Questline(String id, String title, String description, List<Chapter> chapters,
                        List<String> endings, List<RewardSpec> rewards) {}
