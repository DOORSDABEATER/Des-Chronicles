package net.dragonempire.chronicles.questline;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Predicate;

/** Derives chapter and campaign state from the set of completed quests. Pure and stateless. */
public final class QuestlineProgress {
    public enum Status { LOCKED, AVAILABLE, COMPLETE }

    public record Evaluation(Map<String, Status> chapters, boolean complete, String endingQuest) {}

    private QuestlineProgress() {}

    public static Evaluation evaluate(Questline line, Predicate<String> done) {
        Map<String, Status> out = new LinkedHashMap<>();
        // Completion first, since unlocking depends on other chapters' completion.
        Map<String, Boolean> complete = new LinkedHashMap<>();
        for (Chapter c : line.chapters()) {
            long n = c.quests().stream().filter(done).count();
            complete.put(c.id(), n >= c.required());
        }
        for (Chapter c : line.chapters()) {
            if (complete.get(c.id())) out.put(c.id(), Status.COMPLETE);
            else if (c.requires().stream().allMatch(r -> Boolean.TRUE.equals(complete.get(r)))) out.put(c.id(), Status.AVAILABLE);
            else out.put(c.id(), Status.LOCKED);
        }
        String ending = null;
        for (String e : line.endings()) {
            if (done.test(e)) { ending = e; break; }
        }
        boolean chaptersDone = line.chapters().stream().filter(c -> !c.optional()).allMatch(c -> complete.get(c.id()));
        boolean finished = chaptersDone && (line.endings().isEmpty() || ending != null);
        return new Evaluation(out, finished, ending);
    }

    /** A quest in a chapter is only startable if at least one chapter containing it is unlocked. */
    public static boolean questUnlocked(Questline line, String questId, Evaluation eval) {
        boolean member = false;
        for (Chapter c : line.chapters()) {
            if (!c.quests().contains(questId)) continue;
            member = true;
            if (eval.chapters().get(c.id()) != Status.LOCKED) return true;
        }
        return !member;
    }
}
