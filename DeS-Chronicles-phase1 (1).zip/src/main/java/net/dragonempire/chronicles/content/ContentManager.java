package net.dragonempire.chronicles.content;

import net.dragonempire.chronicles.achievements.AchievementDefinition;
import net.dragonempire.chronicles.escorts.EscortDefinition;
import net.dragonempire.chronicles.escorts.EscortParser;
import net.dragonempire.chronicles.community.GoalDefinition;
import net.dragonempire.chronicles.community.GoalParser;
import net.dragonempire.chronicles.interactions.InteractableDefinition;
import net.dragonempire.chronicles.interactions.InteractionParser;
import net.dragonempire.chronicles.interactions.PuzzleDefinition;
import net.dragonempire.chronicles.achievements.AchievementParser;
import net.dragonempire.chronicles.actions.ActionExecutor;
import net.dragonempire.chronicles.rewards.RewardValidator;
import net.dragonempire.chronicles.questline.Chapter;
import net.dragonempire.chronicles.bosses.BossDefinition;
import net.dragonempire.chronicles.bosses.BossParser;
import net.dragonempire.chronicles.bosses.BossPhase;
import net.dragonempire.chronicles.cutscenes.CutsceneDefinition;
import net.dragonempire.chronicles.cutscenes.CutsceneParser;
import net.dragonempire.chronicles.cutscenes.CutsceneStep;
import net.dragonempire.chronicles.dialogue.DialogueAction;
import net.dragonempire.chronicles.dialogue.DialogueChoice;
import net.dragonempire.chronicles.dialogue.DialogueDefinition;
import net.dragonempire.chronicles.dialogue.DialogueLoader;
import net.dragonempire.chronicles.dialogue.DialogueNode;
import net.dragonempire.chronicles.events.EventDefinition;
import net.dragonempire.chronicles.events.EventParser;
import net.dragonempire.chronicles.quest.QuestDefinition;
import net.dragonempire.chronicles.quest.QuestLoadResult;
import net.dragonempire.chronicles.quest.QuestLoader;
import net.dragonempire.chronicles.questline.Questline;
import net.dragonempire.chronicles.questline.QuestlineParser;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.entity.EntityType;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Holds loaded content. reload() swaps whole snapshots, so readers never see a half-loaded state. */
public final class ContentManager {
    private interface DocParser<T> {
        T parse(String id, Map<String, Object> root, String file, List<ValidationIssue> issues);
    }

    private volatile Map<String, QuestDefinition> quests = Map.of();
    private volatile Map<String, DialogueDefinition> dialogues = Map.of();
    private volatile Map<String, LocationSpec> locations = Map.of();
    private volatile Map<String, Questline> questlines = Map.of();
    private volatile Map<String, EventDefinition> events = Map.of();
    private volatile Map<String, CutsceneDefinition> cutscenes = Map.of();
    private volatile Map<String, BossDefinition> bosses = Map.of();
    private volatile Map<String, AchievementDefinition> achievements = Map.of();
    private volatile Map<String, GoalDefinition> goals = Map.of();
    private volatile Map<String, InteractableDefinition> interactables = Map.of();
    private volatile Map<String, InteractableDefinition> interactablesByBlock = Map.of();
    private volatile Map<String, PuzzleDefinition> puzzles = Map.of();
    private volatile Map<String, String> questFiles = Map.of();
    private volatile Map<String, EscortDefinition> escorts = Map.of();
    private volatile List<ValidationIssue> issues = List.of();

    public Map<String, QuestDefinition> quests() { return quests; }
    public Map<String, DialogueDefinition> dialogues() { return dialogues; }
    public Map<String, LocationSpec> locations() { return locations; }
    public Map<String, Questline> questlines() { return questlines; }
    public Map<String, EventDefinition> events() { return events; }
    public Map<String, CutsceneDefinition> cutscenes() { return cutscenes; }
    public Map<String, BossDefinition> bosses() { return bosses; }
    public Map<String, AchievementDefinition> achievements() { return achievements; }
    public Map<String, GoalDefinition> goals() { return goals; }
    public Map<String, InteractableDefinition> interactables() { return interactables; }
    public Map<String, PuzzleDefinition> puzzles() { return puzzles; }
    public Map<String, String> questFiles() { return questFiles; }
    public Map<String, EscortDefinition> escorts() { return escorts; }
    public InteractableDefinition interactableAt(String world, int x, int y, int z) { return interactablesByBlock.get(world + ":" + x + ":" + y + ":" + z); }
    public List<ValidationIssue> issues() { return issues; }

    public List<ValidationIssue> reload(Path dataDir) {
        List<ValidationIssue> all = new ArrayList<>();
        QuestLoadResult q = new QuestLoader().load(dataDir.resolve("quests"));
        all.addAll(q.issues());
        Set<String> questIds = q.quests().keySet();

        Map<String, DialogueDefinition> d = DialogueLoader.load(dataDir.resolve("dialogues"), ActionExecutor.KNOWN, all);
        Map<String, LocationSpec> l = loadLocations(dataDir.resolve("locations.yml"), all);
        Map<String, Questline> lines = loadDir(dataDir.resolve("questlines"), all,
                (id, root, file, iss) -> QuestlineParser.parse(id, root, file, questIds, QuestLoader.REWARD_TYPES, iss));
        Map<String, EventDefinition> ev = loadDir(dataDir.resolve("events"), all,
                (id, root, file, iss) -> EventParser.parse(id, root, file, questIds, iss));
        Map<String, CutsceneDefinition> cs = loadDir(dataDir.resolve("cutscenes"), all,
                (id, root, file, iss) -> CutsceneParser.parse(id, root, file, iss));
        Map<String, BossDefinition> bs = loadDir(dataDir.resolve("bosses"), all,
                (id, root, file, iss) -> BossParser.parse(id, root, file, ActionExecutor.KNOWN, iss));

        Map<String, GoalDefinition> goalMap = new LinkedHashMap<>();
        Path communityFile = dataDir.resolve("community.yml");
        if (Files.isRegularFile(communityFile)) {
            try {
                goalMap = GoalParser.parse(Yamls.load(communityFile), "community.yml", all);
            } catch (IOException | InvalidConfigurationException e) {
                all.add(new ValidationIssue("community.yml", "(file)", "unreadable YAML: " + e.getMessage()));
            }
        }
        InteractionParser.Result inter = new InteractionParser.Result(Map.of(), Map.of());
        Path interFile = dataDir.resolve("interactables.yml");
        if (Files.isRegularFile(interFile)) {
            try {
                inter = InteractionParser.parse(Yamls.load(interFile), "interactables.yml", all);
            } catch (IOException | InvalidConfigurationException e) {
                all.add(new ValidationIssue("interactables.yml", "(file)", "unreadable YAML: " + e.getMessage()));
            }
        }
        Map<String, InteractableDefinition> byBlock = new LinkedHashMap<>();
        for (InteractableDefinition d2 : inter.interactables().values()) byBlock.put(d2.key(), d2);

        Map<String, EscortDefinition> escortMap = new LinkedHashMap<>();
        Path escortFile = dataDir.resolve("escorts.yml");
        if (Files.isRegularFile(escortFile)) {
            try {
                escortMap = EscortParser.parse(Yamls.load(escortFile), "escorts.yml", all);
            } catch (IOException | InvalidConfigurationException e) {
                all.add(new ValidationIssue("escorts.yml", "(file)", "unreadable YAML: " + e.getMessage()));
            }
        }
        for (EscortDefinition es : escortMap.values()) {
            try {
                EntityType t = EntityType.valueOf(es.entity());
                if (!t.isSpawnable() || !t.isAlive() || t.getEntityClass() == null || !org.bukkit.entity.Mob.class.isAssignableFrom(t.getEntityClass())) {
                    all.add(new ValidationIssue("escorts.yml", "escorts." + es.id() + ".entity", es.entity() + " cannot walk and follow (needs a mob)"));
                }
            } catch (IllegalArgumentException e) {
                all.add(new ValidationIssue("escorts.yml", "escorts." + es.id() + ".entity", "unknown entity type '" + es.entity() + "'"));
            }
        }

        Map<String, AchievementDefinition> ach = loadAchievements(dataDir.resolve("achievements.yml"), all);
        for (QuestDefinition qd : q.quests().values()) RewardValidator.validate(qd.rewards(), qd.id() + ".yml", "rewards", ach, true, all);
        for (Questline line : lines.values()) {
            RewardValidator.validate(line.rewards(), line.id() + ".yml", "rewards", ach, true, all);
            for (Chapter c : line.chapters()) RewardValidator.validate(c.rewards(), line.id() + ".yml", "chapters." + c.id() + ".rewards", ach, true, all);
        }

        // Cross-references between content types.
        for (BossDefinition b : bs.values()) {
            try {
                EntityType t = EntityType.valueOf(b.entity());
                if (!t.isSpawnable() || !t.isAlive()) all.add(new ValidationIssue(b.id() + ".yml", "entity", b.entity() + " cannot be used for a boss"));
            } catch (IllegalArgumentException e) {
                all.add(new ValidationIssue(b.id() + ".yml", "entity", "unknown entity type '" + b.entity() + "'"));
            }
            for (BossPhase ph : b.phases()) checkActions(b.id() + ".yml", "phase " + ph.below(), ph.actions(), q.quests(), cs, bs, all);
        }
        for (DialogueDefinition def : d.values()) {
            for (DialogueNode n : def.nodes().values()) {
                checkActions(def.id() + ".yml", "nodes." + n.id() + " on_enter", n.onEnter(), q.quests(), cs, bs, all);
                for (DialogueChoice c : n.choices()) checkActions(def.id() + ".yml", "nodes." + n.id() + " choice " + c.id(), c.actions(), q.quests(), cs, bs, all);
            }
        }
        for (QuestDefinition qd : q.quests().values()) {
            checkActions(qd.id() + ".yml", "on_start", qd.onStart(), q.quests(), cs, bs, all);
            checkActions(qd.id() + ".yml", "on_complete", qd.onComplete(), q.quests(), cs, bs, all);
            if (!qd.event().isBlank() && !ev.containsKey(qd.event())) {
                all.add(new ValidationIssue(qd.id() + ".yml", "event", "unknown event '" + qd.event() + "'"));
            }
        }
        for (CutsceneDefinition c : cs.values()) {
            for (CutsceneStep s : c.steps()) {
                if (s.type().equals("spawn_boss") && !bs.containsKey(String.valueOf(s.params().get("boss")))) {
                    all.add(new ValidationIssue(c.id() + ".yml", "steps (spawn_boss)", "unknown boss '" + s.params().get("boss") + "'"));
                }
                if (s.type().equals("dialogue") && !d.containsKey(String.valueOf(s.params().get("dialogue")))) {
                    all.add(new ValidationIssue(c.id() + ".yml", "steps (dialogue)", "unknown dialogue '" + s.params().get("dialogue") + "'"));
                }
            }
        }

        this.quests = q.quests();
        this.dialogues = d;
        this.locations = l;
        this.questlines = lines;
        this.events = ev;
        this.cutscenes = cs;
        this.bosses = bs;
        this.achievements = ach;
        this.goals = goalMap;
        this.escorts = escortMap;
        this.interactables = inter.interactables();
        this.interactablesByBlock = byBlock;
        this.puzzles = inter.puzzles();
        this.questFiles = q.files();
        this.issues = List.copyOf(all);
        return this.issues;
    }

    private static void checkActions(String file, String where, List<DialogueAction> actions, Map<String, QuestDefinition> quests,
                                     Map<String, CutsceneDefinition> cutscenes, Map<String, BossDefinition> bosses,
                                     List<ValidationIssue> issues) {
        for (DialogueAction a : actions) {
            switch (a.type()) {
                case "start_quest", "complete_quest" -> {
                    if (!quests.containsKey(String.valueOf(a.params().get("quest")))) {
                        issues.add(new ValidationIssue(file, where, a.type() + " references unknown quest '" + a.params().get("quest") + "'"));
                    }
                }
                case "set_flag", "clear_flag" -> {
                    if (!(a.params().get("flag") instanceof String f) || f.isBlank()) issues.add(new ValidationIssue(file, where, a.type() + " needs a flag"));
                }
                case "add_counter" -> {
                    if (!(a.params().get("key") instanceof String k) || k.isBlank() || !(a.params().get("amount") instanceof Number)) {
                        issues.add(new ValidationIssue(file, where, "add_counter needs key and amount"));
                    }
                }
                case "message" -> {
                    if (!(a.params().get("text") instanceof String t) || t.isBlank()) issues.add(new ValidationIssue(file, where, "message needs text"));
                }
                case "title" -> {
                    if (!(a.params().get("title") instanceof String t) || t.isBlank()) issues.add(new ValidationIssue(file, where, "title action needs a title"));
                }
                case "sound" -> {
                    if (!(a.params().get("sound") instanceof String t) || t.isBlank()) issues.add(new ValidationIssue(file, where, "sound action needs a sound"));
                }
                case "start_escort" -> {
                    if (!(a.params().get("escort") instanceof String es) || es.isBlank()) issues.add(new ValidationIssue(file, where, "start_escort needs an escort id"));
                }
                case "open_shop" -> {
                    if (!(a.params().get("npc") instanceof String n) || n.isBlank()) issues.add(new ValidationIssue(file, where, "open_shop needs an npc id"));
                }
                case "play_cutscene" -> {
                    if (!cutscenes.containsKey(String.valueOf(a.params().get("cutscene")))) {
                        issues.add(new ValidationIssue(file, where, "play_cutscene references unknown cutscene '" + a.params().get("cutscene") + "'"));
                    }
                }
                case "spawn_boss" -> {
                    if (!bosses.containsKey(String.valueOf(a.params().get("boss")))) {
                        issues.add(new ValidationIssue(file, where, "spawn_boss references unknown boss '" + a.params().get("boss") + "'"));
                    }
                }
                default -> { }
            }
        }
    }

    private static <T> Map<String, T> loadDir(Path dir, List<ValidationIssue> issues, DocParser<T> parser) {
        Map<String, T> out = new LinkedHashMap<>();
        if (!Files.isDirectory(dir)) return out;
        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.yml")) {
            ds.forEach(files::add);
        } catch (IOException e) {
            issues.add(new ValidationIssue(dir.getFileName() + "/", "(directory)", "cannot list: " + e.getMessage()));
            return out;
        }
        Collections.sort(files);
        for (Path f : files) {
            String name = f.getFileName().toString();
            try {
                Map<String, Object> root = Yamls.load(f);
                String id = root.get("id") instanceof String s ? s : name.substring(0, name.length() - 4);
                T t = parser.parse(id, root, name, issues);
                if (t != null) out.put(id, t);
            } catch (IOException | InvalidConfigurationException e) {
                issues.add(new ValidationIssue(name, "(file)", "unreadable YAML: " + e.getMessage()));
            }
        }
        return out;
    }

    private static Map<String, AchievementDefinition> loadAchievements(Path file, List<ValidationIssue> issues) {
        if (!Files.isRegularFile(file)) return Map.of();
        try {
            return AchievementParser.parse(Yamls.load(file), "achievements.yml", issues);
        } catch (IOException | InvalidConfigurationException e) {
            issues.add(new ValidationIssue("achievements.yml", "(file)", "unreadable YAML: " + e.getMessage()));
            return Map.of();
        }
    }

    private static Map<String, LocationSpec> loadLocations(Path file, List<ValidationIssue> issues) {
        Map<String, LocationSpec> out = new LinkedHashMap<>();
        if (!Files.isRegularFile(file)) return out;
        Map<String, Object> root;
        try {
            root = Yamls.load(file);
        } catch (IOException | InvalidConfigurationException e) {
            issues.add(new ValidationIssue("locations.yml", "(file)", "unreadable YAML: " + e.getMessage()));
            return out;
        }
        if (!(root.get("locations") instanceof Map<?, ?> m)) return out;
        for (Map.Entry<?, ?> e : m.entrySet()) {
            String name = String.valueOf(e.getKey());
            String p = "locations." + name;
            if (!(e.getValue() instanceof Map<?, ?> v)) {
                issues.add(new ValidationIssue("locations.yml", p, "must be a map"));
                continue;
            }
            if (Boolean.FALSE.equals(v.get("enabled"))) continue;
            if (!(v.get("world") instanceof String w) || !(v.get("x") instanceof Number x)
                    || !(v.get("y") instanceof Number y) || !(v.get("z") instanceof Number z)) {
                issues.add(new ValidationIssue("locations.yml", p, "needs world, x, y, z"));
                continue;
            }
            double r = v.get("radius") instanceof Number n ? n.doubleValue() : 5.0;
            if (r <= 0) {
                issues.add(new ValidationIssue("locations.yml", p + ".radius", "must be > 0"));
                continue;
            }
            out.put(name, new LocationSpec(name, w, x.doubleValue(), y.doubleValue(), z.doubleValue(), r));
        }
        return out;
    }
}
