package net.dragonempire.chronicles.content;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Loads a YAML file into plain maps/lists so the parsers stay free of Bukkit types. */
public final class Yamls {
    private Yamls() {}

    public static Map<String, Object> load(Path file) throws IOException, InvalidConfigurationException {
        YamlConfiguration y = new YamlConfiguration();
        y.load(file.toFile());
        return toMap(y);
    }

    public static Map<String, Object> toMap(ConfigurationSection section) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (Map.Entry<String, Object> e : section.getValues(false).entrySet()) out.put(e.getKey(), convert(e.getValue()));
        return out;
    }

    private static Object convert(Object v) {
        if (v instanceof ConfigurationSection cs) return toMap(cs);
        if (v instanceof List<?> l) {
            List<Object> out = new ArrayList<>();
            for (Object o : l) out.add(convert(o));
            return out;
        }
        return v;
    }
}
