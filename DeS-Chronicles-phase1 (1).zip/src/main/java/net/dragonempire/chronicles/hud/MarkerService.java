package net.dragonempire.chronicles.hud;

import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.content.LocationSpec;
import net.dragonempire.chronicles.objectives.ObjectiveSpec;
import net.dragonempire.chronicles.objectives.QuestProgress;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.quest.QuestDefinition;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Boss-bar quest marker showing the distance to the nearest unfinished VISIT_LOCATION objective of a tracked quest.
 * Updated on block-change movement (throttled to once a second per player) and on quest changes; no repeating task.
 * Players can turn it off with /quests markers off.
 */
public final class MarkerService {
    private static final double RANGE = 500.0;

    private final ContentManager content;
    private final QuestService quests;
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Map<UUID, Long> last = new HashMap<>();

    public MarkerService(ContentManager content, QuestService quests) {
        this.content = content;
        this.quests = quests;
    }

    public void update(Player p, boolean force) {
        long now = System.currentTimeMillis();
        Long prev = last.get(p.getUniqueId());
        if (!force && prev != null && now - prev < 1000) return;
        last.put(p.getUniqueId(), now);

        PlayerState s = quests.state(p);
        double best = Double.MAX_VALUE;
        String bestTitle = null;
        if (s != null && !s.flags.contains("pref:nomarkers")) {
            for (Map.Entry<String, QuestProgress> e : s.active.entrySet()) {
                if (!s.tracking(e.getKey())) continue;
                QuestDefinition q = content.quests().get(e.getKey());
                if (q == null || e.getValue().stage() >= q.plan().stages().size()) continue;
                for (ObjectiveSpec o : q.plan().stages().get(e.getValue().stage()).objectives()) {
                    if (!o.type().equals("VISIT_LOCATION") || e.getValue().isDone(o) || o.target() == null) continue;
                    LocationSpec loc = content.locations().get(o.target());
                    if (loc == null || !loc.world().equals(p.getWorld().getName())) continue;
                    double d = Math.sqrt(Math.pow(p.getLocation().getX() - loc.x(), 2) + Math.pow(p.getLocation().getY() - loc.y(), 2)
                            + Math.pow(p.getLocation().getZ() - loc.z(), 2));
                    if (d < best) {
                        best = d;
                        bestTitle = q.title();
                    }
                }
            }
        }
        BossBar bar = bars.get(p.getUniqueId());
        if (bestTitle == null) {
            if (bar != null) {
                p.hideBossBar(bar);
                bars.remove(p.getUniqueId());
            }
            return;
        }
        Component name = Component.text(bestTitle + " - " + (int) best + " m");
        float progress = (float) Math.max(0.0, Math.min(1.0, 1.0 - best / RANGE));
        if (bar == null) {
            bar = BossBar.bossBar(name, progress, BossBar.Color.YELLOW, BossBar.Overlay.PROGRESS);
            bars.put(p.getUniqueId(), bar);
            p.showBossBar(bar);
        } else {
            bar.name(name);
            bar.progress(progress);
        }
    }

    public void forget(Player p) {
        BossBar bar = bars.remove(p.getUniqueId());
        if (bar != null) p.hideBossBar(bar);
        last.remove(p.getUniqueId());
    }
}
