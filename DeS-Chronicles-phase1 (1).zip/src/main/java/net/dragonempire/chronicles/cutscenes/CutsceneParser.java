package net.dragonempire.chronicles.cutscenes;

import net.dragonempire.chronicles.validation.ValidationIssue;

import java.util.*;

public final class CutsceneParser {
    public static final Set<String> TYPES = Set.of("title", "actionbar", "message", "sound", "particle", "lightning",
            "fade", "teleport", "camera", "restrict", "dialogue", "spawn_boss");

    private CutsceneParser() {}

    public static CutsceneDefinition parse(String id, Map<String, Object> root, String file, List<ValidationIssue> issues) {
        int before = issues.size();
        if (!(root.get("steps") instanceof List<?> raw) || raw.isEmpty()) {
            issues.add(new ValidationIssue(file, "steps", "at least one step required"));
            return null;
        }
        boolean shared = Boolean.TRUE.equals(root.get("shared"));
        double radius = root.get("radius") instanceof Number n ? n.doubleValue() : 0;
        if (shared && radius <= 0) issues.add(new ValidationIssue(file, "radius", "shared scenes need a radius > 0"));
        List<CutsceneStep> steps = new ArrayList<>();
        int end = 0;
        for (int i = 0; i < raw.size(); i++) {
            String p = "steps[" + i + "]";
            if (!(raw.get(i) instanceof Map<?, ?> m) || !(m.get("type") instanceof String t)) {
                issues.add(new ValidationIssue(file, p + ".type", "required"));
                continue;
            }
            String type = t.toLowerCase(Locale.ROOT);
            if (!TYPES.contains(type)) {
                issues.add(new ValidationIssue(file, p + ".type", "unknown step type '" + t + "'"));
                continue;
            }
            int at = m.get("at") instanceof Number n ? n.intValue() : 0;
            if (at < 0) {
                issues.add(new ValidationIssue(file, p + ".at", "must be >= 0"));
                continue;
            }
            int len = 0;
            switch (type) {
                case "title" -> need(m, "title", "subtitle", file, p, issues);
                case "actionbar", "message" -> need(m, "text", null, file, p, issues);
                case "sound" -> need(m, "sound", null, file, p, issues);
                case "particle" -> need(m, "particle", null, file, p, issues);
                case "dialogue" -> need(m, "dialogue", null, file, p, issues);
                case "spawn_boss" -> need(m, "boss", null, file, p, issues);
                case "teleport" -> point(m.get("to"), file, p + ".to", issues);
                case "camera" -> {
                    point(m.get("from"), file, p + ".from", issues);
                    point(m.get("to"), file, p + ".to", issues);
                    if (!(m.get("ticks") instanceof Number n) || n.intValue() < 1) issues.add(new ValidationIssue(file, p + ".ticks", "required, >= 1"));
                    else len = n.intValue();
                }
                case "restrict", "fade" -> {
                    if (!(m.get("ticks") instanceof Number n) || n.intValue() < 1) issues.add(new ValidationIssue(file, p + ".ticks", "required, >= 1"));
                    else len = n.intValue();
                }
                default -> { }
            }
            boolean essential = m.get("essential") instanceof Boolean b ? b : type.equals("spawn_boss");
            @SuppressWarnings("unchecked") Map<String, Object> params = (Map<String, Object>) m;
            steps.add(new CutsceneStep(at, type, essential, params));
            end = Math.max(end, at + len);
        }
        if (issues.size() > before) return null;
        int duration = root.get("duration") instanceof Number n ? Math.max(n.intValue(), end) : end + 20;
        steps.sort(Comparator.comparingInt(CutsceneStep::at));
        return new CutsceneDefinition(id, !Boolean.FALSE.equals(root.get("skippable")), shared, radius, duration, List.copyOf(steps));
    }

    private static void need(Map<?, ?> m, String a, String b, String file, String p, List<ValidationIssue> issues) {
        boolean ok = m.get(a) instanceof String s && !s.isBlank() || b != null && m.get(b) instanceof String s2 && !s2.isBlank();
        if (!ok) issues.add(new ValidationIssue(file, p + "." + a, b == null ? "required" : "needs " + a + " or " + b));
    }

    private static void point(Object o, String file, String path, List<ValidationIssue> issues) {
        if (!(o instanceof Map<?, ?> m) || !(m.get("world") instanceof String) || !(m.get("x") instanceof Number)
                || !(m.get("y") instanceof Number) || !(m.get("z") instanceof Number)) {
            issues.add(new ValidationIssue(file, path, "needs world, x, y, z"));
        }
    }
}
