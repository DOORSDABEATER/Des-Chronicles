package net.dragonempire.chronicles.validation;

/** A content problem pinned to a file and a field path. */
public record ValidationIssue(String file, String path, String message) {
    @Override
    public String toString() {
        return file + " @ " + path + ": " + message;
    }
}
