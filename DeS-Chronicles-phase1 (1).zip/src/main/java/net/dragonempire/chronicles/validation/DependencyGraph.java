package net.dragonempire.chronicles.validation;

import java.util.*;

/** Directed prerequisite graph (node -> its prerequisites) with cycle detection. */
public final class DependencyGraph {
    private final Map<String, Set<String>> edges = new LinkedHashMap<>();

    public void addNode(String id) {
        edges.computeIfAbsent(id, k -> new LinkedHashSet<>());
    }

    public void addPrerequisite(String id, String prerequisite) {
        addNode(id);
        edges.get(id).add(prerequisite);
    }

    /** Returns one cycle (first node repeated at the end) or empty if the graph is acyclic. */
    public Optional<List<String>> findCycle() {
        Map<String, Integer> state = new HashMap<>(); // 1 = visiting, 2 = done
        Deque<String> stack = new ArrayDeque<>();
        for (String start : new ArrayList<>(edges.keySet())) {
            Optional<List<String>> c = visit(start, state, stack);
            if (c.isPresent()) return c;
        }
        return Optional.empty();
    }

    private Optional<List<String>> visit(String node, Map<String, Integer> state, Deque<String> stack) {
        Integer s = state.get(node);
        if (s != null && s == 2) return Optional.empty();
        if (s != null && s == 1) {
            List<String> cycle = new ArrayList<>();
            boolean on = false;
            for (Iterator<String> it = stack.descendingIterator(); it.hasNext(); ) {
                String n = it.next();
                if (n.equals(node)) on = true;
                if (on) cycle.add(n);
            }
            cycle.add(node);
            return Optional.of(cycle);
        }
        state.put(node, 1);
        stack.push(node);
        for (String next : edges.getOrDefault(node, Set.of())) {
            Optional<List<String>> c = visit(next, state, stack);
            if (c.isPresent()) return c;
        }
        stack.pop();
        state.put(node, 2);
        return Optional.empty();
    }
}
