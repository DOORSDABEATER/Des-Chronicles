package net.dragonempire.chronicles.listeners;

import net.dragonempire.chronicles.bosses.BossManager;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.persistence.PersistentDataType;

public final class BossListener implements Listener {
    private final BossManager bosses;

    public BossListener(BossManager bosses) {
        this.bosses = bosses;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!e.getEntity().getPersistentDataContainer().has(bosses.key(), PersistentDataType.STRING)) return;
        Player attacker = null;
        if (e.getDamager() instanceof Player p) attacker = p;
        else if (e.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player p) attacker = p;
        if (attacker != null) bosses.onDamage(e.getEntity(), attacker, e.getFinalDamage());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        if (e.getEntity().getPersistentDataContainer().has(bosses.key(), PersistentDataType.STRING)) bosses.onDeath(e.getEntity());
    }
}
