package net.dragonempire.chronicles.listeners;

import net.dragonempire.chronicles.npc.NpcManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;

public final class NpcListener implements Listener {
    private final NpcManager npcs;

    public NpcListener(NpcManager npcs) {
        this.npcs = npcs;
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return; // the off-hand event would fire a second time
        String id = e.getRightClicked().getPersistentDataContainer().get(npcs.key(), PersistentDataType.STRING);
        if (id == null) return;
        e.setCancelled(true); // stops villager trade screens etc.
        npcs.interact(e.getPlayer(), id, e.getRightClicked());
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        npcs.onChunkLoad(e.getWorld().getName(), e.getChunk().getX(), e.getChunk().getZ());
    }
}
