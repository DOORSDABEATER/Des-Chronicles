package net.dragonempire.chronicles.listeners;

import net.dragonempire.chronicles.studio.StudioMenu;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/** Studio menus are controls, not storage: every click and drag is cancelled. */
public final class StudioListener implements Listener {
    private final StudioMenu menu;

    public StudioListener(StudioMenu menu) {
        this.menu = menu;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof StudioMenu.Holder h)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getInventory())) return;
        if (e.getWhoClicked() instanceof Player p) menu.click(p, h, e.getSlot(), e.getClick());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof StudioMenu.Holder) e.setCancelled(true);
    }
}
