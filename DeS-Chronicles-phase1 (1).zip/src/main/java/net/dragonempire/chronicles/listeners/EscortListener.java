package net.dragonempire.chronicles.listeners;

import net.dragonempire.chronicles.escorts.EscortManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataType;

public final class EscortListener implements Listener {
    private final EscortManager escorts;

    public EscortListener(EscortManager escorts) {
        this.escorts = escorts;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        if (e.getEntity().getPersistentDataContainer().has(escorts.idKey(), PersistentDataType.STRING)) escorts.onEscortDeath(e.getEntity());
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent e) {
        escorts.onPlayerGone(e.getEntity(), "you died");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        escorts.onPlayerGone(e.getPlayer(), "you left the server");
    }
}
