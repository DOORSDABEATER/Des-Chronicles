package net.dragonempire.chronicles.listeners;

import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.interactions.InteractableDefinition;
import net.dragonempire.chronicles.interactions.PuzzleDefinition;
import net.dragonempire.chronicles.interactions.PuzzleTracker;
import net.dragonempire.chronicles.objectives.ObjectiveEvent;
import net.dragonempire.chronicles.quest.QuestService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

/** Configured blocks (interactables.yml): activating mechanisms, rituals, objects and ordered puzzles. */
public final class InteractionListener implements Listener {
    private final ContentManager content;
    private final QuestService quests;
    private final PuzzleTracker puzzles = new PuzzleTracker();

    public InteractionListener(ContentManager content, QuestService quests) {
        this.content = content;
        this.quests = quests;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND || e.getClickedBlock() == null) return;
        if (content.interactables().isEmpty()) return;
        Block b = e.getClickedBlock();
        InteractableDefinition d = content.interactableAt(b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
        if (d == null) return;
        Player p = e.getPlayer();
        quests.handle(p, new ObjectiveEvent(d.event(), d.id()));
        for (PuzzleDefinition pz : content.puzzles().values()) {
            if (!pz.steps().contains(d.id())) continue;
            switch (puzzles.advance(p.getUniqueId(), pz, d.id())) {
                case SOLVED -> {
                    p.sendMessage(Component.text("Something clicks into place.", NamedTextColor.GREEN));
                    quests.handle(p, new ObjectiveEvent("SOLVE_PUZZLE", pz.id()));
                }
                case WRONG -> p.sendMessage(Component.text("Nothing happens. The sequence resets.", NamedTextColor.GRAY));
                case PROGRESS -> { }
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        puzzles.forget(e.getPlayer().getUniqueId());
    }
}
