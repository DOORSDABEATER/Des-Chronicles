package net.dragonempire.chronicles.quest;

import net.dragonempire.chronicles.actions.ActionExecutor;
import net.dragonempire.chronicles.community.CommunityManager;
import net.dragonempire.chronicles.content.ContentManager;
import net.dragonempire.chronicles.events.EventManager;
import net.dragonempire.chronicles.messages.Messages;
import net.dragonempire.chronicles.objectives.*;
import net.dragonempire.chronicles.parties.PartyManager;
import net.dragonempire.chronicles.player.PlayerState;
import net.dragonempire.chronicles.questline.QuestlineService;
import net.dragonempire.chronicles.rewards.PluginRewardGranter;
import net.dragonempire.chronicles.rewards.RewardEngine;
import net.dragonempire.chronicles.rewards.RewardSpec;
import net.dragonempire.chronicles.storage.Database;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Instant;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.random.RandomGenerator;

/**
 * Player quest lifecycle. All state lives on the main thread; persistence is asynchronous
 * and failures are logged, never swallowed.
 */
public final class QuestService {
    private final JavaPlugin plugin;
    private final ContentManager content;
    private final Database db;
    private final RewardEngine rewards;
    private final Map<UUID, PlayerState> states = new HashMap<>();

    private ActionExecutor actions;
    private EventManager events;
    private QuestlineService questlines;
    private PartyManager parties;
    private Consumer<Player> onLoaded = p -> { };
    private Consumer<Player> onChanged = p -> { };
    private CommunityManager community;
    private ZoneId zone = ZoneId.of("UTC");

    public QuestService(JavaPlugin plugin, ContentManager content, Database db) {
        this.plugin = plugin;
        this.content = content;
        this.db = db;
        this.rewards = new RewardEngine(db, new PluginRewardGranter(plugin, () -> this),
                r -> { if (plugin.isEnabled()) plugin.getServer().getScheduler().runTask(plugin, r); },
                RandomGenerator.getDefault());
    }

    public void setActions(ActionExecutor a) { this.actions = a; }
    public void setEvents(EventManager e) { this.events = e; }
    public void setQuestlines(QuestlineService q) { this.questlines = q; }
    public void setParties(PartyManager p) { this.parties = p; }
    public void setOnLoaded(Consumer<Player> c) { this.onLoaded = c; }
    public void setOnChanged(Consumer<Player> c) { this.onChanged = c; }
    public void setCommunity(CommunityManager c) { this.community = c; }
    public void setZone(ZoneId z) { this.zone = z; }
    public ZoneId zone() { return zone; }

    // ---- state ----
    public PlayerState state(Player p) { return states.get(p.getUniqueId()); }
    public ContentManager content() { return content; }

    public void loadPlayer(Player p) {
        UUID id = p.getUniqueId();
        db.loadPlayer(id).whenComplete((data, err) -> {
            if (!plugin.isEnabled()) return;
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (err != null) {
                    plugin.getLogger().severe("Failed to load quest data for " + p.getName() + ": " + err);
                    return;
                }
                if (!p.isOnline()) return;
                PlayerState s = new PlayerState();
                for (Map.Entry<String, String> e : data.activeQuests().entrySet()) {
                    try {
                        s.active.put(e.getKey(), QuestProgress.decode(e.getValue()));
                    } catch (IllegalArgumentException ex) {
                        plugin.getLogger().severe("Corrupt progress for quest '" + e.getKey() + "' of " + p.getName()
                                + " (row kept in database): " + ex.getMessage());
                    }
                }
                s.completions.putAll(data.completions());
                s.lastCompleted.putAll(data.lastCompleted());
                s.flags.addAll(data.flags());
                s.counters.putAll(data.counters());
                states.put(id, s);
                onLoaded.accept(p);
            });
        });
    }

    public void unload(UUID id) { states.remove(id); }

    private void logFail(CompletableFuture<?> f, String what) {
        f.exceptionally(err -> {
            plugin.getLogger().severe("Database write failed (" + what + "): " + err);
            return null;
        });
    }

    // ---- availability ----
    public String unavailableReason(PlayerState s, QuestDefinition q) {
        if (s.active.containsKey(q.id())) return Messages.plain("quest.reason.active");
        if (s.completed(q.id())) {
            if (ResetPolicy.active(q.reset())) {
                long last = s.lastCompleted.getOrDefault(q.id(), 0L);
                if (!ResetPolicy.availableAgain(q.reset(), last, Instant.now(), zone)) return Messages.plain("quest.reason.reset");
            } else if (!q.repeatable()) {
                return Messages.plain("quest.reason.completed");
            }
        }
        for (String pre : q.prerequisites()) if (!s.completed(pre)) return Messages.plain("quest.reason.requirements");
        for (String ex : q.excludes()) if (s.completed(ex) || s.active.containsKey(ex)) return Messages.plain("quest.reason.excluded");
        if (!q.event().isBlank() && (events == null || !events.isActive(q.event()))) return Messages.plain("quest.reason.event");
        if (questlines != null && questlines.locked(s, q.id())) return Messages.plain("quest.reason.chapter");
        return null;
    }

    public List<QuestDefinition> available(PlayerState s) {
        List<QuestDefinition> out = new ArrayList<>();
        for (QuestDefinition q : content.quests().values()) {
            if (q.status() == QuestStatus.PUBLISHED && !q.hidden() && unavailableReason(s, q) == null) out.add(q);
        }
        return out;
    }

    // ---- lifecycle ----
    /** Returns null on success, otherwise a player-facing reason. force skips status/requirement checks. */
    public String start(Player p, String questId, boolean force) {
        PlayerState s = state(p);
        if (s == null) return Messages.plain("quest.loading");
        QuestDefinition q = content.quests().get(questId);
        if (q == null) return Messages.plain("quest.unknown", "quest", questId);
        if (!force) {
            if (q.status() != QuestStatus.PUBLISHED) return Messages.plain("quest.unavailable");
            String why = unavailableReason(s, q);
            if (why != null) return why;
        } else if (s.active.containsKey(questId)) {
            return Messages.plain("quest.reason.active");
        }
        QuestProgress prog = new QuestProgress();
        s.active.put(questId, prog);
        s.flags.add("track:" + questId);
        logFail(db.saveQuest(p.getUniqueId(), questId, prog.encode()), "start " + questId);
        logFail(db.addFlag(p.getUniqueId(), "track:" + questId), "track " + questId);

        p.showTitle(Title.title(Messages.get("quest.started.title"), Component.text(q.title(), NamedTextColor.WHITE)));
        play(p, "minecraft:entity.experience_orb.pickup");
        showTracker(p, q, prog);
        if (actions != null) actions.run(p, q.onStart());
        onChanged.accept(p);
        return null;
    }

    public void handle(Player p, ObjectiveEvent ev) {
        process(p, ev, p, false);
        if (parties == null || !parties.inParty(p.getUniqueId())) return;
        for (UUID id : parties.membersOf(p.getUniqueId())) {
            if (id.equals(p.getUniqueId())) continue;
            Player mate = plugin.getServer().getPlayer(id);
            if (mate != null && mate.getWorld().equals(p.getWorld())) process(mate, ev, p, true);
        }
    }

    /** sharedOnly: this player is a party member of the actor; only shared quests in range may progress. */
    private void process(Player p, ObjectiveEvent ev, Player actor, boolean sharedOnly) {
        PlayerState s = state(p);
        if (s == null || s.active.isEmpty()) return;
        for (Map.Entry<String, QuestProgress> e : new ArrayList<>(s.active.entrySet())) {
            QuestDefinition q = content.quests().get(e.getKey());
            if (q == null) continue;
            if (sharedOnly) {
                if (!q.partyShared()) continue;
                double max = q.partyDistance();
                if (p.getLocation().distanceSquared(actor.getLocation()) > max * max) continue; // no remote credit
            }
            QuestProgress prog = e.getValue();
            if (prog.stage() >= q.plan().stages().size()) {
                plugin.getLogger().warning("Quest '" + q.id() + "' was edited so " + p.getName() + "'s stage no longer exists; progress left untouched.");
                continue;
            }
            ProgressResult r = prog.apply(q.plan(), ev);
            if (!r.changed()) continue;
            if (r.questCompleted()) {
                complete(p, q.id());
                continue;
            }
            logFail(db.saveQuest(p.getUniqueId(), q.id(), prog.encode()), "progress " + q.id());
            if (r.stageAdvanced()) {
                p.sendMessage(Messages.get("quest.stage.complete", "quest", q.title()));
                play(p, "minecraft:entity.player.levelup");
            }
            if (s.tracking(q.id())) showTracker(p, q, prog);
            onChanged.accept(p);
        }
    }

    public void complete(Player p, String questId) {
        PlayerState s = state(p);
        QuestDefinition q = content.quests().get(questId);
        if (s == null || q == null) return;
        if (s.active.remove(questId) == null) return; // only an active quest can complete: no double completion
        UUID id = p.getUniqueId();
        int count = s.completions.merge(questId, 1, Integer::sum);
        s.lastCompleted.put(questId, System.currentTimeMillis());
        if (s.flags.remove("track:" + questId)) logFail(db.removeFlag(id, "track:" + questId), "untrack " + questId);
        logFail(db.deleteQuest(id, questId), "delete active " + questId);
        logFail(db.recordCompletion(id, questId), "completion " + questId);

        p.showTitle(Title.title(Messages.get("quest.complete.title"), Component.text(q.title(), NamedTextColor.WHITE)));
        play(p, "minecraft:ui.toast.challenge_complete");

        boolean again = q.repeatable() || ResetPolicy.active(q.reset());
        awardNamed(p, again ? questId + "#" + count : questId, q.rewards());
        if (actions != null) actions.run(p, q.onComplete());
        process(p, new ObjectiveEvent("COMPLETE_QUEST", questId), p, false);
        if (questlines != null) questlines.onQuestCompleted(p);
        onChanged.accept(p);
    }

    /** Claims and grants rewards once per claimKey. Delivery failures are logged. */
    public CompletableFuture<Integer> awardNamed(Player p, String claimKey, List<RewardSpec> specs) {
        UUID id = p.getUniqueId();
        CompletableFuture<Integer> f = rewards.award(id, claimKey, specs);
        f.whenComplete((n, err) -> {
            if (err != null) plugin.getLogger().severe("Reward delivery failed for " + p.getName() + " on " + claimKey + ": " + err);
            else if (n > 0 && p.isOnline()) p.sendMessage(Messages.get("quest.rewards", "count", String.valueOf(n)));
        });
        return f;
    }

    public boolean abandon(Player p, String questId) {
        PlayerState s = state(p);
        if (s == null || s.active.remove(questId) == null) return false;
        s.flags.remove("track:" + questId);
        logFail(db.deleteQuest(p.getUniqueId(), questId), "abandon " + questId);
        logFail(db.removeFlag(p.getUniqueId(), "track:" + questId), "untrack " + questId);
        onChanged.accept(p);
        return true;
    }

    public void reset(Player p, String questId) {
        PlayerState s = state(p);
        if (s == null) return;
        s.active.remove(questId);
        s.completions.remove(questId);
        s.lastCompleted.remove(questId);
        s.flags.remove("track:" + questId);
        logFail(db.resetQuest(p.getUniqueId(), questId), "reset " + questId);
        onChanged.accept(p);
    }

    public void addFlag(Player p, String flag) {
        PlayerState s = state(p);
        if (s != null && s.flags.add(flag)) {
            logFail(db.addFlag(p.getUniqueId(), flag), "flag " + flag);
            onChanged.accept(p);
        }
    }

    public void removeFlag(Player p, String flag) {
        PlayerState s = state(p);
        if (s != null && s.flags.remove(flag)) {
            logFail(db.removeFlag(p.getUniqueId(), flag), "unflag " + flag);
            onChanged.accept(p);
        }
    }

    // ---- counters (reputation, morality, relationships) and community ----
    public void addCounter(Player p, String key, int delta) {
        PlayerState s = state(p);
        if (s == null || delta == 0) return;
        int v = s.counters.merge(key, delta, Integer::sum);
        logFail(db.setCounter(p.getUniqueId(), key, v), "counter " + key);
        onChanged.accept(p);
    }

    public int counter(Player p, String key) {
        PlayerState s = state(p);
        return s == null ? 0 : s.counters.getOrDefault(key, 0);
    }

    public void addGlobal(String key, long amount) {
        if (community != null) community.add(key, amount);
    }

    /** True if any active quest currently has an unfinished objective of this type (cheap gate for noisy events). */
    public boolean wantsEvent(Player p, String type) {
        PlayerState s = state(p);
        if (s == null) return false;
        for (Map.Entry<String, QuestProgress> e : s.active.entrySet()) {
            QuestDefinition q = content.quests().get(e.getKey());
            if (q == null || e.getValue().stage() >= q.plan().stages().size()) continue;
            for (ObjectiveSpec o : q.plan().stages().get(e.getValue().stage()).objectives()) {
                if (o.type().equalsIgnoreCase(type) && !e.getValue().isDone(o)) return true;
            }
        }
        return false;
    }

    /** Dying zeroes unfinished reset_on_death objectives (for example survival timers). */
    public void onDeath(Player p) {
        PlayerState s = state(p);
        if (s == null) return;
        boolean any = false;
        for (Map.Entry<String, QuestProgress> e : s.active.entrySet()) {
            QuestDefinition q = content.quests().get(e.getKey());
            if (q == null || !e.getValue().resetOnDeath(q.plan())) continue;
            logFail(db.saveQuest(p.getUniqueId(), q.id(), e.getValue().encode()), "death reset " + q.id());
            p.sendMessage(Messages.get("quest.death.reset", "quest", q.title()));
            any = true;
        }
        if (any) onChanged.accept(p);
    }

    /** Suggested next quests: main story first, then side, daily, other. */
    public List<QuestDefinition> recommend(PlayerState s, int limit) {
        List<QuestDefinition> list = new ArrayList<>(available(s));
        list.sort(Comparator.comparingInt((QuestDefinition q) -> switch (q.category()) {
            case "main" -> 0;
            case "side" -> 1;
            case "daily" -> 2;
            default -> 3;
        }).thenComparing(QuestDefinition::title));
        return list.subList(0, Math.min(limit, list.size()));
    }

    /** Returns false if the quest is not active for the player. */
    public boolean setTracked(Player p, String questId, boolean tracked) {
        PlayerState s = state(p);
        if (s == null || !s.active.containsKey(questId)) return false;
        if (tracked) addFlag(p, "track:" + questId); else removeFlag(p, "track:" + questId);
        return true;
    }

    // ---- display ----
    public List<String> describe(QuestDefinition q, QuestProgress prog) {
        List<String> lines = new ArrayList<>();
        if (prog.stage() >= q.plan().stages().size()) return lines;
        for (ObjectiveSpec o : q.plan().stages().get(prog.stage()).objectives()) {
            if (o.hidden() && !prog.isDone(o)) continue;
            String text = o.description().isBlank()
                    ? o.type().toLowerCase(Locale.ROOT).replace('_', ' ') + (o.target() == null ? "" : " " + o.target())
                    : o.description();
            lines.add((prog.isDone(o) ? "[x] " : "[ ] ") + text + (o.amount() > 1 ? " (" + prog.count(o.id()) + "/" + o.amount() + ")" : "")
                    + (o.optional() ? " (optional)" : ""));
        }
        return lines;
    }

    private void showTracker(Player p, QuestDefinition q, QuestProgress prog) {
        p.sendActionBar(Component.text(q.title() + "  ", NamedTextColor.GOLD)
                .append(Component.text(String.join("  ", describe(q, prog)), NamedTextColor.WHITE)));
    }

    private void play(Player p, String key) {
        try {
            p.playSound(Sound.sound(Key.key(key), Sound.Source.MASTER, 1f, 1f));
        } catch (RuntimeException e) {
            plugin.getLogger().warning("Invalid sound key '" + key + "': " + e.getMessage());
        }
    }
}
