package net.dragonempire.chronicles.quest;

import net.dragonempire.chronicles.actions.ActionExecutor;
import net.dragonempire.chronicles.content.Yamls;
import net.dragonempire.chronicles.dialogue.DialogueParser;
import net.dragonempire.chronicles.objectives.QuestPlan;
import net.dragonempire.chronicles.objectives.QuestPlanParser;
import net.dragonempire.chronicles.rewards.RewardParser;
import net.dragonempire.chronicles.rewards.RewardSpec;
import net.dragonempire.chronicles.rewards.RewardValidator;
import net.dragonempire.chronicles.validation.DependencyGraph;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.bukkit.configuration.InvalidConfigurationException;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Loads quest YAML files. A malformed file produces ValidationIssues and is skipped;
 * it never throws out of load().
 */
public final class QuestLoader {
    public static final Set<String> REWARD_TYPES = Set.of("item", "xp", "command", "flag", "money", "achievement", "counter", "global");

    public QuestLoadResult load(Path dir) {
        Map<String, QuestDefinition> quests = new LinkedHashMap<>();
        Map<String, String> fileById = new HashMap<>();
        List<ValidationIssue> issues = new ArrayList<>();
        if (!Files.isDirectory(dir)) return new QuestLoadResult(quests, issues, Map.of());

        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.yml")) {
            ds.forEach(files::add);
        } catch (IOException e) {
            issues.add(new ValidationIssue(dir.toString(), "(directory)", "cannot list: " + e.getMessage()));
            return new QuestLoadResult(quests, issues, Map.of());
        }
        Collections.sort(files);

        for (Path file : files) {
            String name = file.getFileName().toString();
            Map<String, Object> root;
            try {
                root = Yamls.load(file);
            } catch (IOException | InvalidConfigurationException e) {
                issues.add(new ValidationIssue(name, "(file)", "unreadable YAML: " + e.getMessage()));
                continue;
            }
            int before = issues.size();
            String id = root.get("id") instanceof String s ? s : name.substring(0, name.length() - 4);
            String title = root.get("title") instanceof String s ? s : null;
            if (title == null || title.isBlank()) issues.add(new ValidationIssue(name, "title", "required"));
            if (fileById.containsKey(id)) {
                issues.add(new ValidationIssue(name, "id", "duplicate of quest id '" + id + "' in " + fileById.get(id)));
            }
            QuestStatus status = QuestStatus.DRAFT;
            try {
                status = QuestStatus.valueOf(String.valueOf(root.getOrDefault("status", "draft")).toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                issues.add(new ValidationIssue(name, "status", "must be draft, published or disabled"));
            }
            QuestPlan plan = QuestPlanParser.parse(root, name, issues);
            List<RewardSpec> rewards = RewardParser.parse(root.get("rewards"), name, "rewards", REWARD_TYPES, issues);
            RewardValidator.validate(rewards, name, "rewards", Map.of(), false, issues); // achievement ids are checked after all content loads
            String reset = String.valueOf(root.getOrDefault("reset", "none")).toLowerCase(Locale.ROOT);
            if (!ResetPolicy.VALID.contains(reset)) issues.add(new ValidationIssue(name, "reset", "must be none, daily or weekly"));
            String party = String.valueOf(root.getOrDefault("party", "individual")).toLowerCase(Locale.ROOT);
            if (!party.equals("individual") && !party.equals("shared")) issues.add(new ValidationIssue(name, "party", "must be individual or shared"));
            double partyDistance = root.get("party_distance") instanceof Number pn ? pn.doubleValue() : 30.0;
            if (partyDistance <= 0) issues.add(new ValidationIssue(name, "party_distance", "must be > 0"));
            var onStart = DialogueParser.parseActions(root.get("on_start"), name, "on_start", ActionExecutor.KNOWN, issues);
            var onComplete = DialogueParser.parseActions(root.get("on_complete"), name, "on_complete", ActionExecutor.KNOWN, issues);
            if (issues.size() > before) continue;

            fileById.put(id, name);
            quests.put(id, new QuestDefinition(id, title,
                    root.get("description") instanceof String s ? s : "", status,
                    root.get("giver") instanceof String s ? s : "",
                    root.get("category") instanceof String s ? s : "side",
                    Boolean.TRUE.equals(root.get("repeatable")), Boolean.TRUE.equals(root.get("hidden")),
                    reset, root.get("event") instanceof String ev ? ev : "", party.equals("shared"), partyDistance,
                    strings(root.get("prerequisites")), strings(root.get("excludes")), plan, List.copyOf(rewards),
                    onStart, onComplete));
        }

        DependencyGraph graph = new DependencyGraph();
        for (QuestDefinition q : quests.values()) {
            graph.addNode(q.id());
            for (String pre : q.prerequisites()) {
                if (!quests.containsKey(pre)) {
                    issues.add(new ValidationIssue(fileById.get(q.id()), "prerequisites", "unknown quest '" + pre + "'"));
                } else {
                    graph.addPrerequisite(q.id(), pre);
                }
            }
            for (String ex : q.excludes()) {
                if (!quests.containsKey(ex)) {
                    issues.add(new ValidationIssue(fileById.get(q.id()), "excludes", "unknown quest '" + ex + "'"));
                }
            }
        }
        graph.findCycle().ifPresent(c -> issues.add(new ValidationIssue("(quests)", "prerequisites",
                "circular prerequisites: " + String.join(" -> ", c))));
        return new QuestLoadResult(Collections.unmodifiableMap(quests), List.copyOf(issues), Map.copyOf(fileById));
    }

    private static List<String> strings(Object raw) {
        List<String> out = new ArrayList<>();
        if (raw instanceof List<?> l) for (Object o : l) out.add(String.valueOf(o));
        return List.copyOf(out);
    }
}
