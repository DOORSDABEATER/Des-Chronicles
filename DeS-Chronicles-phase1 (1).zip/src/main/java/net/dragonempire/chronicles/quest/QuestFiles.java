package net.dragonempire.chronicles.quest;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Edits only the status line of a quest file so comments and formatting survive. */
public final class QuestFiles {
    private static final Pattern STATUS = Pattern.compile("(?m)^status:[^\\r\\n]*");

    private QuestFiles() {}

    public static String setStatusText(String yaml, QuestStatus status) {
        String line = "status: " + status.name().toLowerCase(java.util.Locale.ROOT);
        Matcher m = STATUS.matcher(yaml);
        if (m.find()) return m.replaceFirst(Matcher.quoteReplacement(line));
        return line + "\n" + yaml;
    }

    public static QuestStatus readStatus(String yaml) {
        Matcher m = STATUS.matcher(yaml);
        if (!m.find()) return QuestStatus.DRAFT;
        String v = m.group().substring("status:".length()).replaceAll("#.*", "").trim().replace("\"", "").replace("'", "");
        try {
            return QuestStatus.valueOf(v.toUpperCase(java.util.Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return QuestStatus.DRAFT;
        }
    }

    /** Writes through a temp file and atomic move so a crash cannot leave a half-written quest. */
    public static void setStatus(Path file, QuestStatus status) throws IOException {
        String text = Files.readString(file, StandardCharsets.UTF_8);
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        Files.writeString(tmp, setStatusText(text, status), StandardCharsets.UTF_8);
        Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
    }
}
