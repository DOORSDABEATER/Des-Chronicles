package net.dragonempire.chronicles;

import net.dragonempire.chronicles.condition.ConditionParser;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ConditionParserTest {
    @Test
    void andOrNotLogic() {
        FakeContext ctx = new FakeContext();
        ctx.completed.add("a");
        List<ValidationIssue> issues = new ArrayList<>();
        Map<String, Object> spec = Map.of("any", List.of(
                Map.of("type", "completed_quest", "quest", "zzz"),
                Map.of("all", List.of(
                        Map.of("type", "completed_quest", "quest", "a"),
                        Map.of("not", Map.of("type", "active_quest", "quest", "b"))))));
        var c = ConditionParser.parse(spec, "f.yml", "if", issues);
        assertTrue(issues.isEmpty());
        assertTrue(c.test(ctx));
        ctx.active.add("b");
        assertFalse(c.test(ctx));
    }

    @Test
    void levelAndPermission() {
        FakeContext ctx = new FakeContext();
        List<ValidationIssue> issues = new ArrayList<>();
        var c = ConditionParser.parse(List.of(Map.of("type", "level", "min", 10),
                Map.of("type", "permission", "node", "x.y")), "f.yml", "if", issues);
        assertFalse(c.test(ctx));
        ctx.level = 10;
        ctx.perms.add("x.y");
        assertTrue(c.test(ctx));
    }

    @Test
    void badSpecReportsFieldAndEvaluatesFalse() {
        List<ValidationIssue> issues = new ArrayList<>();
        var c = ConditionParser.parse(Map.of("type", "completed_quest"), "f.yml", "choices[0].if", issues);
        assertEquals(1, issues.size());
        assertEquals("choices[0].if.quest", issues.get(0).path());
        assertFalse(c.test(new FakeContext()));
        issues.clear();
        ConditionParser.parse(Map.of("type", "nope"), "f.yml", "if", issues);
        assertEquals(1, issues.size());
    }

    @Test
    void eventActiveCondition() {
        FakeContext ctx = new FakeContext();
        List<ValidationIssue> issues = new ArrayList<>();
        var c = ConditionParser.parse(Map.of("type", "event_active", "event", "winter"), "f.yml", "if", issues);
        assertTrue(issues.isEmpty());
        assertFalse(c.test(ctx));
        ctx.events.add("winter");
        assertTrue(c.test(ctx));
    }
}
