package net.dragonempire.chronicles;

import net.dragonempire.chronicles.quest.ResetPolicy;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.ZoneId;

import static org.junit.jupiter.api.Assertions.*;

class ResetPolicyTest {
    private static final ZoneId UTC = ZoneId.of("UTC");
    // Thursday 2026-11-12 15:00 UTC
    private static final Instant NOW = Instant.parse("2026-11-12T15:00:00Z");

    @Test
    void dailyResetsAtMidnight() {
        assertEquals(Instant.parse("2026-11-12T00:00:00Z"), ResetPolicy.periodStart("daily", NOW, UTC));
        assertEquals(Instant.parse("2026-11-13T00:00:00Z"), ResetPolicy.nextReset("daily", NOW, UTC));
        assertFalse(ResetPolicy.availableAgain("daily", Instant.parse("2026-11-12T01:00:00Z").toEpochMilli(), NOW, UTC));
        assertTrue(ResetPolicy.availableAgain("daily", Instant.parse("2026-11-11T23:59:00Z").toEpochMilli(), NOW, UTC));
    }

    @Test
    void weeklyResetsOnMonday() {
        assertEquals(Instant.parse("2026-11-09T00:00:00Z"), ResetPolicy.periodStart("weekly", NOW, UTC));
        assertEquals(Instant.parse("2026-11-16T00:00:00Z"), ResetPolicy.nextReset("weekly", NOW, UTC));
        assertFalse(ResetPolicy.availableAgain("weekly", Instant.parse("2026-11-10T10:00:00Z").toEpochMilli(), NOW, UTC));
        assertTrue(ResetPolicy.availableAgain("weekly", Instant.parse("2026-11-08T10:00:00Z").toEpochMilli(), NOW, UTC));
    }

    @Test
    void timezoneShiftsTheBoundary() {
        ZoneId tokyo = ZoneId.of("Asia/Tokyo"); // 2026-11-13 00:00 JST == 2026-11-12 15:00 UTC
        assertEquals(Instant.parse("2026-11-12T15:00:00Z"), ResetPolicy.periodStart("daily", NOW, tokyo));
        assertThrows(IllegalArgumentException.class, () -> ResetPolicy.periodStart("none", NOW, UTC));
    }
}
