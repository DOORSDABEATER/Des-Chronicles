package net.dragonempire.chronicles;

import net.dragonempire.chronicles.escorts.EscortParser;
import net.dragonempire.chronicles.messages.MessageCatalog;
import net.dragonempire.chronicles.npc.ShopParser;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class BatchFourLogicTest {
    private static final Map<String, Object> START = Map.of("world", "w", "x", 1, "y", 2, "z", 3);
    private static final Map<String, Object> DEST = Map.of("x", 50, "y", 2, "z", 3);

    @Test
    void escortParsesAndValidates() {
        Map<String, Object> good = new LinkedHashMap<>();
        good.put("name", "Archivist"); good.put("start", START); good.put("destination", DEST); good.put("configured", false);
        Map<String, Object> bad = Map.of("start", START, "destination", DEST, "speed", 9, "radius", 0);
        Map<String, Object> noStart = Map.of("destination", DEST);
        Map<String, Object> escorts = new LinkedHashMap<>();
        escorts.put("ok", good); escorts.put("bad", bad); escorts.put("nostart", noStart);
        List<ValidationIssue> issues = new ArrayList<>();
        var out = EscortParser.parse(Map.of("escorts", escorts), "escorts.yml", issues);
        assertEquals(1, out.size());
        assertFalse(out.get("ok").configured());
        assertEquals("VILLAGER", out.get("ok").entity());
        assertEquals(3, issues.size());                 // speed, radius, missing start
    }

    @Test
    void shopParserValidatesOffers() {
        List<ValidationIssue> issues = new ArrayList<>();
        var shop = ShopParser.parse(List.of(
                Map.of("item", "BREAD", "amount", 4, "price", 10),
                Map.of("item", "APPLE", "price", 2.5),
                Map.of("item", "STONE", "amount", 99, "price", 1),
                Map.of("item", "DIRT", "price", 0),
                Map.of("amount", 1, "price", 1)), "n.yml", "shop", issues);
        assertEquals(2, shop.size());
        assertEquals(1, shop.get(1).amount());
        assertEquals(3, issues.size());
    }

    @Test
    void catalogFallsBackAndSubstitutes() {
        MessageCatalog c = new MessageCatalog(Map.of("hello", "Hallo {name}!"), Map.of("hello", "Hello {name}!", "bye", "Bye"));
        assertEquals("Hallo Sam!", c.format("hello", "name", "Sam"));
        assertEquals("Bye", c.format("bye"));
        assertTrue(c.format("nope").contains("missing message: nope"));
        assertTrue(c.has("bye") && !c.has("nope"));
        assertThrows(IllegalArgumentException.class, () -> c.format("hello", "name"));
    }
}
