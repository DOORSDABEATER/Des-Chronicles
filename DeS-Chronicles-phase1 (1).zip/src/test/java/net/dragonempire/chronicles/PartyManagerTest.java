package net.dragonempire.chronicles;

import net.dragonempire.chronicles.parties.PartyManager;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class PartyManagerTest {
    @Test
    void inviteAcceptLeaveAndPromotion() {
        PartyManager pm = new PartyManager(3);
        UUID a = UUID.randomUUID(), b = UUID.randomUUID(), c = UUID.randomUUID(), d = UUID.randomUUID();
        assertNull(pm.create(a));
        assertNotNull(pm.create(a));
        assertNull(pm.invite(a, b, 0));
        assertNull(pm.accept(b, 1000));
        assertEquals(2, pm.membersOf(a).size());
        assertNotNull(pm.invite(b, c, 0));                 // only the leader invites
        assertNull(pm.invite(a, c, 0));
        assertNull(pm.accept(c, 10));
        assertNotNull(pm.invite(a, d, 0));                 // full at 3

        assertNull(pm.leave(a));                           // leader leaves: b is promoted
        assertTrue(pm.membersOf(b).contains(c));
        assertNull(pm.invite(b, d, 0));
        assertEquals(1, pm.membersOf(a).size());           // a is alone again
    }

    @Test
    void invitesExpire() {
        PartyManager pm = new PartyManager(5);
        UUID a = UUID.randomUUID(), b = UUID.randomUUID();
        pm.create(a);
        pm.invite(a, b, 0);
        assertNotNull(pm.accept(b, 61_000));
        assertFalse(pm.inParty(b));
    }
}
