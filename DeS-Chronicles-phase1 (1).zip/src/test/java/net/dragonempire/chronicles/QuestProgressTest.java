package net.dragonempire.chronicles;

import net.dragonempire.chronicles.objectives.*;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class QuestProgressTest {
    private static Map<String, Object> obj(String id, String type, String target, int amount, boolean optional) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id); m.put("type", type); m.put("target", target); m.put("amount", amount); m.put("optional", optional);
        return m;
    }

    private QuestPlan plan(Map<String, Object> root) {
        List<ValidationIssue> issues = new ArrayList<>();
        QuestPlan p = QuestPlanParser.parse(root, "q.yml", issues);
        assertNotNull(p, issues.toString());
        return p;
    }

    @Test
    void sequentialObjectivesMustBeDoneInOrder() {
        QuestPlan p = plan(Map.of("stages", List.of(Map.of("mode", "sequential", "objectives", List.of(
                obj("talk", "TALK_NPC", "elder", 1, false),
                obj("kill", "KILL_MOB", "ZOMBIE", 2, false))))));
        QuestProgress qp = new QuestProgress();
        assertFalse(qp.apply(p, new ObjectiveEvent("KILL_MOB", "ZOMBIE")).changed()); // too early
        assertTrue(qp.apply(p, new ObjectiveEvent("TALK_NPC", "elder")).changed());
        qp.apply(p, new ObjectiveEvent("KILL_MOB", "ZOMBIE"));
        var r = qp.apply(p, new ObjectiveEvent("KILL_MOB", "zombie"));
        assertTrue(r.questCompleted());
        assertTrue(qp.complete());
    }

    @Test
    void parallelAnyOrderAndRequiredCount() {
        QuestPlan p = plan(Map.of("stages", List.of(Map.of("mode", "parallel", "required", 2, "objectives", List.of(
                obj("a", "COLLECT_ITEM", "DIAMOND", 1, false),
                obj("b", "COLLECT_ITEM", "EMERALD", 1, false),
                obj("c", "COLLECT_ITEM", "GOLD_INGOT", 1, false))))));
        QuestProgress qp = new QuestProgress();
        assertFalse(qp.apply(p, new ObjectiveEvent("COLLECT_ITEM", "EMERALD")).questCompleted());
        assertTrue(qp.apply(p, new ObjectiveEvent("COLLECT_ITEM", "GOLD_INGOT")).questCompleted()); // 2 of 3 is enough
    }

    @Test
    void multiStageAdvancesAndOptionalDoesNotBlock() {
        QuestPlan p = plan(Map.of("stages", List.of(
                Map.of("objectives", List.of(obj("a", "TALK_NPC", "x", 1, false), obj("opt", "KILL_MOB", "*", 1, true))),
                Map.of("objectives", List.of(obj("b", "VISIT_LOCATION", "ruins", 1, false))))));
        QuestProgress qp = new QuestProgress();
        var r = qp.apply(p, new ObjectiveEvent("TALK_NPC", "x"));
        assertTrue(r.stageAdvanced());
        assertFalse(r.questCompleted());
        assertEquals(1, qp.stage());
        assertEquals(0, qp.optionalCompleted(p));
        assertTrue(qp.apply(p, new ObjectiveEvent("VISIT_LOCATION", "ruins")).questCompleted());
    }

    @Test
    void progressRoundTripsThroughEncoding() {
        QuestPlan p = plan(Map.of("objectives", List.of(obj("kill", "KILL_MOB", "ZOMBIE", 5, false))));
        QuestProgress qp = new QuestProgress();
        qp.apply(p, new ObjectiveEvent("KILL_MOB", "ZOMBIE", 3));
        QuestProgress back = QuestProgress.decode(qp.encode());
        assertEquals(3, back.count("kill"));
        assertThrows(IllegalArgumentException.class, () -> QuestProgress.decode("garbage"));
    }

    @Test
    void parserRejectsBadPlans() {
        List<ValidationIssue> issues = new ArrayList<>();
        assertNull(QuestPlanParser.parse(Map.of("stages", List.of(Map.of("required", 5, "objectives",
                List.of(obj("a", "TALK_NPC", "x", 1, false))))), "q.yml", issues));
        assertEquals("stages[0].required", issues.get(0).path());
        issues.clear();
        assertNull(QuestPlanParser.parse(Map.of("objectives", List.of(obj("a", "T", "x", 1, false), obj("a", "T", "y", 1, false))),
                "q.yml", issues));
        assertFalse(issues.isEmpty());
    }
}
