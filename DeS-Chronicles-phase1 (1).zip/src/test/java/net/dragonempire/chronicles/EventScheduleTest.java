package net.dragonempire.chronicles;

import net.dragonempire.chronicles.events.*;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class EventScheduleTest {
    private EventDefinition ev(String start, String end) {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("title", "Winter");
        if (start != null) root.put("start", start);
        if (end != null) root.put("end", end);
        List<ValidationIssue> issues = new ArrayList<>();
        EventDefinition d = EventParser.parse("winter", root, "winter.yml", Set.of(), issues);
        assertNotNull(d, issues.toString());
        return d;
    }

    @Test
    void windowControlsActivity() {
        EventDefinition d = ev("2026-12-01T00:00:00Z", "2026-12-31T00:00:00Z");
        assertFalse(EventSchedule.isActive(d, null, Instant.parse("2026-11-30T23:59:59Z")));
        assertTrue(EventSchedule.isActive(d, null, Instant.parse("2026-12-15T00:00:00Z")));
        assertFalse(EventSchedule.isActive(d, null, Instant.parse("2026-12-31T00:00:00Z")));
    }

    @Test
    void manualOverridesAndEnd() {
        EventDefinition d = ev("2026-12-01T00:00:00Z", "2026-12-31T00:00:00Z");
        assertTrue(EventSchedule.isActive(d, "on", Instant.parse("2026-11-01T00:00:00Z")));    // forced early
        assertFalse(EventSchedule.isActive(d, "on", Instant.parse("2027-01-01T00:00:00Z")));   // still ends
        assertFalse(EventSchedule.isActive(d, "off", Instant.parse("2026-12-15T00:00:00Z")));
        EventDefinition manual = ev(null, null);
        assertFalse(EventSchedule.isActive(manual, null, Instant.parse("2026-12-15T00:00:00Z")));
        assertTrue(EventSchedule.isActive(manual, "on", Instant.parse("2026-12-15T00:00:00Z")));
    }

    @Test
    void parserValidatesDatesAndQuests() {
        List<ValidationIssue> issues = new ArrayList<>();
        assertNull(EventParser.parse("e", Map.of("title", "t", "start", "tomorrow", "quests", List.of("ghost")), "e.yml", Set.of(), issues));
        assertEquals(2, issues.size());
        issues.clear();
        assertNull(EventParser.parse("e", Map.of("title", "t", "start", "2026-12-02T00:00:00Z", "end", "2026-12-01T00:00:00Z"), "e.yml", Set.of(), issues));
        assertEquals("end", issues.get(0).path());
    }
}
