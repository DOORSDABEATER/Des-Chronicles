package net.dragonempire.chronicles;

import net.dragonempire.chronicles.bosses.*;
import net.dragonempire.chronicles.cutscenes.*;
import net.dragonempire.chronicles.validation.ValidationIssue;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class CutsceneBossTest {
    private static final Map<String, Object> POINT = Map.of("world", "w", "x", 1, "y", 2, "z", 3);

    @Test
    void cutsceneParsesOrdersAndComputesDuration() {
        Map<String, Object> root = Map.of("shared", true, "radius", 20, "steps", List.of(
                Map.of("at", 40, "type", "spawn_boss", "boss", "g"),
                Map.of("at", 0, "type", "camera", "from", POINT, "to", POINT, "ticks", 60),
                Map.of("at", 10, "type", "title", "title", "Hi")));
        List<ValidationIssue> issues = new ArrayList<>();
        CutsceneDefinition d = CutsceneParser.parse("c", root, "c.yml", issues);
        assertNotNull(d, issues.toString());
        assertEquals("camera", d.steps().get(0).type());
        assertEquals(60 + 20, d.duration());
        assertTrue(d.steps().stream().filter(s -> s.type().equals("spawn_boss")).findFirst().get().essential());
        assertTrue(d.skippable());
    }

    @Test
    void cutsceneRejectsBadSteps() {
        List<ValidationIssue> issues = new ArrayList<>();
        assertNull(CutsceneParser.parse("c", Map.of("shared", true, "steps", List.of(
                Map.of("type", "explode"), Map.of("type", "camera", "ticks", 0), Map.of("type", "title"))), "c.yml", issues));
        assertTrue(issues.size() >= 4);
    }

    @Test
    void bossParsesPhasesDescending() {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("entity", "wither_skeleton");
        root.put("location", POINT);
        root.put("phases", List.of(
                Map.of("below", 0.25, "actions", List.of(Map.of("type", "message", "text", "rage"))),
                Map.of("below", 0.5, "actions", List.of())));
        List<ValidationIssue> issues = new ArrayList<>();
        BossDefinition b = BossParser.parse("g", root, "g.yml", Set.of("message"), issues);
        assertNotNull(b, issues.toString());
        assertEquals(0.5, b.phases().get(0).below());
        assertEquals("WITHER_SKELETON", b.entity());
        issues.clear();
        assertNull(BossParser.parse("g", Map.of("entity", "X", "location", POINT, "health", -1, "phases", List.of(Map.of("below", 2))),
                "g.yml", Set.of(), issues));
        assertEquals(2, issues.size());
    }

    @Test
    void onlyContributorsQualify() {
        ContributionTracker t = new ContributionTracker();
        UUID hitter = UUID.randomUUID(), tapper = UUID.randomUUID(), bystander = UUID.randomUUID();
        t.add(hitter, 50);
        t.add(tapper, 0.5);
        assertEquals(List.of(hitter), t.qualified(1));
        assertFalse(t.qualified(0).contains(bystander));
        assertEquals(50.0, t.of(hitter));
    }
}
