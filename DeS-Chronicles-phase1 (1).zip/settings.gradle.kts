rootProject.name = "DeS-Chronicles"
